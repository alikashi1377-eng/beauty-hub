import crypto from 'node:crypto';
import { Pool, PoolClient } from 'pg';
import {
  AppointmentItem,
  AppointmentStatus,
  ApprovalStatus,
  BusinessItem,
  BusinessType,
  CategoryItem,
  CustomerRecord,
  GalleryItem,
  MarketingCampaignItem,
  OnboardingDraft,
  ReviewItem,
  ServiceItem,
  SpecialistItem,
  SubscriptionPlanItem,
  SubscriptionStatus,
  WorkingHourItem,
} from '../../src/types';

export type VisualTheme = 'rose' | 'slate' | 'emerald' | 'violet';

export interface BootstrapPayload {
  categories: CategoryItem[];
  businesses: BusinessItem[];
  services: ServiceItem[];
  specialists: SpecialistItem[];
  appointments: AppointmentItem[];
  customers: CustomerRecord[];
  reviews: ReviewItem[];
  gallery: GalleryItem[];
  campaigns: MarketingCampaignItem[];
  plans: SubscriptionPlanItem[];
  favoriteBusinessIds: string[];
}

/**
 * تبدیل ارقام فارسی و عربی به انگلیسی
 */
export function toEnglishDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}

/**
 * تبدیل ارقام انگلیسی به فارسی برای نمایش در فرانت‌اند
 */
export function toPersianDigitsServer(input: string | number): string {
  return String(input).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

/**
 * ماسک کردن شماره موبایل (مثال: 09123456789 -> ۰۹۱۲***۶۷۸۹)
 */
export function maskPhoneDisplay(phone: string): string {
  const clean = toEnglishDigits(phone).replace(/\D/g, '');
  if (clean.length === 11 && clean.startsWith('09')) {
    return toPersianDigitsServer(`${clean.slice(0, 4)}***${clean.slice(7)}`);
  }
  return toPersianDigitsServer(phone);
}

/**
 * نرمال‌سازی اسلاگ مطابق قید دیتابیس: ^[a-z0-9]+(?:-[a-z0-9]+)*$
 */
export function normalizeValidSlug(raw: string, fallbackPrefix = 'item'): string {
  const cleaned = toEnglishDigits(raw || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');

  if (cleaned && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(cleaned)) {
    return cleaned.slice(0, 80);
  }
  const randomSuffix = crypto.randomBytes(3).toString('hex');
  return `${fallbackPrefix}-${randomSuffix}`;
}

/**
 * تبدیل تاریخ شمسی نمایشی (مثلاً ۱۴۰۵/۰۸/۰۳) و ساعت (مثلاً ۱۰:۳۰) به TIMESTAMPTZ معتبر
 * برای ذخیره‌سازی دقیق در PostgreSQL
 */
export function jalaliSlotToTimestamptz(
  dateJalali: string,
  timeSlotLabel: string
): Date {
  const normalizedDate = toEnglishDigits(dateJalali).trim();
  const normalizedTime = toEnglishDigits(timeSlotLabel).trim();

  const dateMatch = normalizedDate.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  const timeMatch = normalizedTime.match(/^(\d{1,2}):(\d{2})/);

  const hour = timeMatch ? Math.min(23, Math.max(0, Number(timeMatch[1]))) : 10;
  const minute = timeMatch
    ? Math.min(59, Math.max(0, Number(timeMatch[2])))
    : 0;

  if (dateMatch) {
    const jy = Number(dateMatch[1]);
    const jm = Number(dateMatch[2]);
    const jd = Number(dateMatch[3]);
    const gy = jy + 621;
    const dayOfYear = (jm - 1) * 30 + jd + 79;
    const baseUtc = Date.UTC(gy, 0, 1, hour - 3, minute - 30, 0, 0);
    return new Date(baseUtc + dayOfYear * 86400 * 1000);
  }

  const now = new Date();
  now.setUTCHours(hour, minute, 0, 0);
  return now;
}

/**
 * نرمال‌سازی ساعت شروع و پایان کاری برای ستون TIME در PostgreSQL
 */
export function normalizeWorkingTimePair(
  openRaw: string,
  closeRaw: string
): { openTimeSql: string; closeTimeSql: string } {
  const openEng = toEnglishDigits(openRaw || '09:30').trim();
  const closeEng = toEnglishDigits(closeRaw || '19:30').trim();
  const oMatch = openEng.match(/^(\d{1,2}):(\d{2})/);
  const cMatch = closeEng.match(/^(\d{1,2}):(\d{2})/);

  if (oMatch && cMatch) {
    const oH = Math.min(23, Math.max(0, Number(oMatch[1])));
    const oM = Math.min(59, Math.max(0, Number(oMatch[2])));
    const cH = Math.min(23, Math.max(0, Number(cMatch[1])));
    const cM = Math.min(59, Math.max(0, Number(cMatch[2])));
    if (cH * 60 + cM > oH * 60 + oM) {
      return {
        openTimeSql: `${String(oH).padStart(2, '0')}:${String(oM).padStart(2, '0')}:00`,
        closeTimeSql: `${String(cH).padStart(2, '0')}:${String(cM).padStart(2, '0')}:00`,
      };
    }
  }
  return { openTimeSql: '09:30:00', closeTimeSql: '19:30:00' };
}

/**
 * دریافت کامل داده‌های اولیه بازارچه، پنل کسب‌وکار و پنل ادمین از PostgreSQL
 */
export async function getBootstrapPayload(
  pool: Pool
): Promise<BootstrapPayload> {
  const client = await pool.connect();
  try {
    const [
      catRes,
      bizRes,
      whRes,
      srvRes,
      spcRes,
      aptRes,
      custRes,
      revRes,
      galRes,
      campRes,
      planRes,
      favRes,
    ] = await Promise.all([
      client.query(`
        SELECT
          COALESCE(legacy_demo_id, id::text) AS external_id,
          slug,
          title,
          subtitle,
          target_audience,
          icon_name,
          service_count
        FROM categories
        WHERE is_active = TRUE
        ORDER BY sort_order ASC, created_at ASC
      `),
      client.query(`
        SELECT
          b.id,
          COALESCE(b.legacy_demo_id, b.id::text) AS external_id,
          b.slug,
          b.name,
          b.type,
          b.type_label,
          b.city,
          b.neighborhood,
          b.address,
          b.map_lat,
          b.map_lng,
          b.phone_display,
          b.instagram_handle,
          b.short_description,
          b.about_text,
          b.visual_theme,
          b.rating_avg,
          b.review_count,
          b.starting_price_toman,
          b.verified_badge,
          b.approval_status,
          b.subscription_plan,
          b.subscription_status,
          b.is_featured,
          c.slug AS primary_category_slug
        FROM businesses b
        JOIN categories c ON c.id = b.primary_category_id
        ORDER BY b.is_featured DESC, b.created_at ASC
      `),
      client.query(`
        SELECT
          business_id,
          day_of_week,
          day_name,
          is_open,
          to_char(open_time, 'HH24:MI') AS open_str,
          to_char(close_time, 'HH24:MI') AS close_str
        FROM business_working_hours
        ORDER BY business_id, day_of_week ASC
      `),
      client.query(`
        SELECT
          COALESCE(s.legacy_demo_id, s.id::text) AS external_id,
          COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id,
          s.category_slug,
          s.category_label,
          s.title,
          s.description,
          s.duration_minutes,
          s.price_toman,
          s.is_popular,
          s.is_active
        FROM services s
        JOIN businesses b ON b.id = s.business_id
        WHERE s.is_active = TRUE
        ORDER BY s.is_popular DESC, s.created_at ASC
      `),
      client.query(`
        SELECT
          COALESCE(sp.legacy_demo_id, sp.id::text) AS external_id,
          COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id,
          sp.slug,
          sp.full_name,
          sp.role_title,
          sp.experience_years,
          sp.rating_avg,
          sp.review_count,
          sp.specialties,
          sp.bio,
          sp.is_independent,
          sp.is_active,
          COALESCE(sp.city, b.city) AS city,
          sp.starting_price_toman
        FROM specialists sp
        JOIN businesses b ON b.id = sp.business_id
        WHERE sp.is_active = TRUE
        ORDER BY sp.rating_avg DESC, sp.created_at ASC
      `),
      client.query(`
        SELECT
          COALESCE(a.legacy_demo_id, a.id::text) AS external_id,
          a.reference_code,
          COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id,
          b.slug AS business_slug,
          b.name AS business_name,
          COALESCE(s.legacy_demo_id, s.id::text) AS service_external_id,
          a.service_title_snapshot,
          COALESCE(sp.legacy_demo_id, sp.id::text) AS specialist_external_id,
          a.specialist_name_snapshot,
          a.customer_name,
          a.customer_phone_masked,
          a.date_jalali,
          a.time_slot_label,
          a.duration_minutes_snapshot,
          a.service_price_toman_snapshot,
          a.status,
          a.notes
        FROM appointments a
        JOIN businesses b ON b.id = a.business_id
        JOIN services s ON s.id = a.service_id
        JOIN specialists sp ON sp.id = a.specialist_id
        ORDER BY a.service_starts_at DESC, a.created_at DESC
      `),
      client.query(`
        SELECT
          COALESCE(legacy_demo_id, id::text) AS external_id,
          full_name,
          phone_masked,
          city,
          total_visits,
          COALESCE(last_visit_jalali, '۱۴۰۵/۰۷/۳۰') AS last_visit_jalali,
          total_spent_toman,
          favorite_service_title,
          notes
        FROM business_customers
        ORDER BY total_visits DESC, created_at DESC
      `),
      client.query(`
        SELECT
          COALESCE(r.legacy_demo_id, r.id::text) AS external_id,
          COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id,
          r.specialist_slug,
          r.author_name,
          r.service_title,
          r.rating,
          r.date_jalali,
          r.comment
        FROM reviews r
        JOIN businesses b ON b.id = r.business_id
        WHERE r.is_published = TRUE
        ORDER BY r.created_at DESC
      `),
      client.query(`
        SELECT
          COALESCE(g.legacy_demo_id, g.id::text) AS external_id,
          COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id,
          g.title,
          g.category_label,
          g.theme
        FROM gallery_items g
        JOIN businesses b ON b.id = g.business_id
        ORDER BY g.sort_order ASC, g.created_at DESC
      `),
      client.query(`
        SELECT
          COALESCE(mc.legacy_demo_id, mc.id::text) AS external_id,
          mc.title,
          mc.target_segment,
          mc.discount_percent,
          mc.channel,
          mc.status_label,
          mc.created_at_jalali
        FROM marketing_campaigns mc
        ORDER BY mc.created_at DESC
      `),
      client.query(`
        SELECT
          COALESCE(legacy_demo_id, code, id::text) AS external_id,
          name,
          audience,
          monthly_price_toman,
          staff_limit_label,
          sms_quota_monthly,
          features,
          is_recommended,
          comparison_meta
        FROM subscription_plans
        WHERE is_active = TRUE
        ORDER BY sort_order ASC, monthly_price_toman ASC
      `),
      client.query(`
        SELECT DISTINCT COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id
        FROM customer_favorites cf
        JOIN businesses b ON b.id = cf.business_id
      `),
    ]);

    const whByBusinessId = new Map<string, WorkingHourItem[]>();
    for (const row of whRes.rows) {
      const bizUuid = String(row.business_id);
      const list = whByBusinessId.get(bizUuid) ?? [];
      list.push({
        dayName: String(row.day_name),
        isOpen: Boolean(row.is_open),
        openTime: toPersianDigitsServer(String(row.open_str || '09:30')),
        closeTime: toPersianDigitsServer(String(row.close_str || '19:30')),
      });
      whByBusinessId.set(bizUuid, list);
    }

    const categories: CategoryItem[] = catRes.rows.map((r) => ({
      id: String(r.external_id),
      slug: String(r.slug),
      title: String(r.title),
      subtitle: String(r.subtitle),
      targetAudience: String(r.target_audience),
      iconName: String(r.icon_name),
      serviceCount: Number(r.service_count),
    }));

    const businesses: BusinessItem[] = bizRes.rows.map((r) => ({
      id: String(r.external_id),
      slug: String(r.slug),
      name: String(r.name),
      type: r.type as BusinessType,
      typeLabel: String(r.type_label),
      categorySlug: String(r.primary_category_slug),
      city: String(r.city),
      neighborhood: String(r.neighborhood),
      address: String(r.address),
      mapLat: r.map_lat !== null ? Number(r.map_lat) : undefined,
      mapLng: r.map_lng !== null ? Number(r.map_lng) : undefined,
      rating: Number(r.rating_avg),
      reviewCount: Number(r.review_count),
      startingPriceToman: Number(r.starting_price_toman),
      verifiedBadge: Boolean(r.verified_badge),
      shortDescription: String(r.short_description),
      aboutText: String(r.about_text),
      phoneDisplay: String(r.phone_display),
      instagramHandle: r.instagram_handle
        ? String(r.instagram_handle)
        : undefined,
      workingHours: whByBusinessId.get(String(r.id)) ?? [],
      visualTheme: (r.visual_theme as VisualTheme) || 'violet',
      approvalStatus: r.approval_status as ApprovalStatus,
      subscriptionPlan: String(r.subscription_plan),
      subscriptionStatus: r.subscription_status as SubscriptionStatus,
      featured: Boolean(r.is_featured),
    }));

    const services: ServiceItem[] = srvRes.rows.map((r) => ({
      id: String(r.external_id),
      businessId: String(r.business_external_id),
      title: String(r.title),
      categorySlug: String(r.category_slug),
      category: String(r.category_label),
      durationMinutes: Number(r.duration_minutes),
      priceToman: Number(r.price_toman),
      description: String(r.description),
      isPopular: Boolean(r.is_popular),
      isActive: Boolean(r.is_active),
    }));

    const specialists: SpecialistItem[] = spcRes.rows.map((r) => ({
      id: String(r.external_id),
      slug: String(r.slug),
      fullName: String(r.full_name),
      roleTitle: String(r.role_title),
      businessId: String(r.business_external_id),
      experienceYears: Number(r.experience_years),
      rating: Number(r.rating_avg),
      reviewCount: Number(r.review_count),
      specialties: Array.isArray(r.specialties)
        ? r.specialties.map(String)
        : [],
      bio: String(r.bio),
      isIndependent: Boolean(r.is_independent),
      isActive: Boolean(r.is_active),
      city: String(r.city),
      startingPriceToman: Number(r.starting_price_toman),
    }));

    const appointments: AppointmentItem[] = aptRes.rows.map((r) => ({
      id: String(r.external_id),
      referenceCode: String(r.reference_code),
      businessId: String(r.business_external_id),
      businessSlug: String(r.business_slug),
      businessName: String(r.business_name),
      serviceId: String(r.service_external_id),
      serviceTitle: String(r.service_title_snapshot),
      specialistId: String(r.specialist_external_id),
      specialistName: String(r.specialist_name_snapshot),
      customerName: String(r.customer_name),
      customerPhoneMasked: String(r.customer_phone_masked),
      dateJalali: String(r.date_jalali),
      timeSlot: String(r.time_slot_label),
      durationMinutes: Number(r.duration_minutes_snapshot),
      priceToman: Number(r.service_price_toman_snapshot),
      status: r.status as AppointmentStatus,
      notes: r.notes ? String(r.notes) : undefined,
    }));

    const customers: CustomerRecord[] = custRes.rows.map((r) => ({
      id: String(r.external_id),
      fullName: String(r.full_name),
      phoneMasked: String(r.phone_masked),
      city: String(r.city),
      totalVisits: Number(r.total_visits),
      lastVisitJalali: String(r.last_visit_jalali),
      totalSpentToman: Number(r.total_spent_toman),
      favoriteService: String(r.favorite_service_title),
      notes: String(r.notes),
    }));

    const reviews: ReviewItem[] = revRes.rows.map((r) => ({
      id: String(r.external_id),
      businessId: String(r.business_external_id),
      specialistSlug: r.specialist_slug ? String(r.specialist_slug) : undefined,
      authorName: String(r.author_name),
      serviceTitle: String(r.service_title),
      rating: Number(r.rating),
      dateJalali: String(r.date_jalali),
      comment: String(r.comment),
    }));

    const gallery: GalleryItem[] = galRes.rows.map((r) => ({
      id: String(r.external_id),
      businessId: String(r.business_external_id),
      title: String(r.title),
      categoryLabel: String(r.category_label),
      theme: (r.theme as VisualTheme) || 'violet',
    }));

    const campaigns: MarketingCampaignItem[] = campRes.rows.map((r) => ({
      id: String(r.external_id),
      title: String(r.title),
      targetSegment: String(r.target_segment),
      discountPercent: Number(r.discount_percent),
      channel: String(r.channel),
      statusLabel: String(r.status_label),
      createdAtJalali: String(r.created_at_jalali),
    }));

    const plans: SubscriptionPlanItem[] = planRes.rows.map((r) => {
      const comp =
        r.comparison_meta && typeof r.comparison_meta === 'object'
          ? (r.comparison_meta as Record<string, unknown>)
          : {};
      return {
        id: String(r.external_id),
        name: String(r.name),
        audience: String(r.audience),
        monthlyPriceToman: Number(r.monthly_price_toman),
        staffLimit: String(r.staff_limit_label),
        smsQuotaMonthly: Number(r.sms_quota_monthly),
        features: Array.isArray(r.features) ? r.features.map(String) : [],
        isRecommended: Boolean(r.is_recommended),
        comparison: {
          onlineBooking: String(comp.onlineBooking ?? 'نامحدود'),
          smsReminders: String(comp.smsReminders ?? 'فعال'),
          analyticsLevel: String(comp.analyticsLevel ?? 'پایه'),
          supportType: String(comp.supportType ?? 'تیکت پشتیبانی'),
        },
      };
    });

    const favoriteBusinessIds = favRes.rows.map((r) =>
      String(r.business_external_id)
    );

    return {
      categories,
      businesses,
      services,
      specialists,
      appointments,
      customers,
      reviews,
      gallery,
      campaigns,
      plans,
      favoriteBusinessIds,
    };
  } finally {
    client.release();
  }
}

async function resolveBusinessUuid(
  client: PoolClient,
  idOrSlugOrLegacy?: string
): Promise<{
  id: string;
  externalId: string;
  slug: string;
  name: string;
  city: string;
}> {
  if (idOrSlugOrLegacy) {
    const res = await client.query(
      `
      SELECT id, COALESCE(legacy_demo_id, id::text) AS external_id, slug, name, city
      FROM businesses
      WHERE id::text = $1 OR legacy_demo_id = $1 OR slug = $1
      LIMIT 1
      `,
      [idOrSlugOrLegacy]
    );
    if (res.rowCount && res.rows[0]) {
      return {
        id: String(res.rows[0].id),
        externalId: String(res.rows[0].external_id),
        slug: String(res.rows[0].slug),
        name: String(res.rows[0].name),
        city: String(res.rows[0].city),
      };
    }
  }

  const fallback = await client.query(`
    SELECT id, COALESCE(legacy_demo_id, id::text) AS external_id, slug, name, city
    FROM businesses
    ORDER BY is_featured DESC, created_at ASC
    LIMIT 1
  `);
  if (!fallback.rowCount || !fallback.rows[0]) {
    throw new Error('BUSINESS_NOT_FOUND');
  }
  return {
    id: String(fallback.rows[0].id),
    externalId: String(fallback.rows[0].external_id),
    slug: String(fallback.rows[0].slug),
    name: String(fallback.rows[0].name),
    city: String(fallback.rows[0].city),
  };
}

async function resolveCategoryBySlug(
  client: PoolClient,
  categorySlug?: string,
  categoryLabel?: string
): Promise<{ id: string; slug: string; title: string }> {
  if (categorySlug) {
    const res = await client.query(
      `SELECT id, slug, title FROM categories WHERE slug = $1 OR id::text = $1 OR legacy_demo_id = $1 LIMIT 1`,
      [categorySlug]
    );
    if (res.rowCount && res.rows[0]) {
      return {
        id: String(res.rows[0].id),
        slug: String(res.rows[0].slug),
        title: categoryLabel || String(res.rows[0].title),
      };
    }
  }

  const fallback = await client.query(
    `SELECT id, slug, title FROM categories ORDER BY sort_order ASC, created_at ASC LIMIT 1`
  );
  if (fallback.rowCount && fallback.rows[0]) {
    return {
      id: String(fallback.rows[0].id),
      slug: categorySlug || String(fallback.rows[0].slug),
      title: categoryLabel || String(fallback.rows[0].title),
    };
  }

  const inserted = await client.query(
    `
    INSERT INTO categories (slug, title, subtitle, target_audience, icon_name)
    VALUES ('hair-color', 'مو، رنگ و استایلینگ', 'خدمات تخصصی مو', 'سالن‌های زیبایی', 'Sparkles')
    RETURNING id, slug, title
    `
  );
  return {
    id: String(inserted.rows[0].id),
    slug: String(inserted.rows[0].slug),
    title: categoryLabel || String(inserted.rows[0].title),
  };
}

/**
 * ایجاد خدمت جدید در جدول services
 */
export async function createServiceInDb(
  pool: Pool,
  input: Omit<ServiceItem, 'id'>
): Promise<ServiceItem> {
  const client = await pool.connect();
  try {
    const biz = await resolveBusinessUuid(client, input.businessId);
    const cat = await resolveCategoryBySlug(
      client,
      input.categorySlug,
      input.category
    );

    const res = await client.query(
      `
      INSERT INTO services (
        business_id,
        category_id,
        category_slug,
        category_label,
        title,
        description,
        duration_minutes,
        price_toman,
        is_popular,
        is_active
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, TRUE)
      RETURNING
        COALESCE(legacy_demo_id, id::text) AS external_id,
        category_slug,
        category_label,
        title,
        description,
        duration_minutes,
        price_toman,
        is_popular,
        is_active
      `,
      [
        biz.id,
        cat.id,
        cat.slug,
        input.category || cat.title,
        input.title.trim(),
        (input.description || '').trim(),
        Math.max(5, Math.min(600, Number(input.durationMinutes) || 45)),
        Math.max(0, Math.min(100000000000, Number(input.priceToman) || 0)),
        Boolean(input.isPopular),
      ]
    );

    const row = res.rows[0];
    return {
      id: String(row.external_id),
      businessId: biz.externalId,
      title: String(row.title),
      categorySlug: String(row.category_slug),
      category: String(row.category_label),
      durationMinutes: Number(row.duration_minutes),
      priceToman: Number(row.price_toman),
      description: String(row.description),
      isPopular: Boolean(row.is_popular),
      isActive: Boolean(row.is_active),
    };
  } finally {
    client.release();
  }
}

/**
 * ویرایش خدمت موجود در جدول services
 */
export async function updateServiceInDb(
  pool: Pool,
  serviceIdOrLegacy: string,
  input: Partial<Omit<ServiceItem, 'id'>>
): Promise<ServiceItem> {
  const client = await pool.connect();
  try {
    const existingRes = await client.query(
      `
      SELECT s.*, COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id
      FROM services s
      JOIN businesses b ON b.id = s.business_id
      WHERE s.id::text = $1 OR s.legacy_demo_id = $1
      LIMIT 1
      `,
      [serviceIdOrLegacy]
    );

    if (!existingRes.rowCount || !existingRes.rows[0]) {
      throw new Error('SERVICE_NOT_FOUND');
    }

    const current = existingRes.rows[0];
    const cat = await resolveCategoryBySlug(
      client,
      input.categorySlug ?? String(current.category_slug),
      input.category ?? String(current.category_label)
    );

    const updatedRes = await client.query(
      `
      UPDATE services
      SET
        category_id = $2,
        category_slug = $3,
        category_label = $4,
        title = $5,
        description = $6,
        duration_minutes = $7,
        price_toman = $8,
        is_popular = $9
      WHERE id = $1
      RETURNING
        COALESCE(legacy_demo_id, id::text) AS external_id,
        category_slug,
        category_label,
        title,
        description,
        duration_minutes,
        price_toman,
        is_popular,
        is_active
      `,
      [
        current.id,
        cat.id,
        input.categorySlug ?? String(current.category_slug),
        input.category ?? String(current.category_label),
        (input.title ?? String(current.title)).trim(),
        (input.description ?? String(current.description)).trim(),
        Math.max(
          5,
          Math.min(
            600,
            Number(input.durationMinutes ?? current.duration_minutes) || 45
          )
        ),
        Math.max(
          0,
          Math.min(
            100000000000,
            Number(input.priceToman ?? current.price_toman) || 0
          )
        ),
        input.isPopular !== undefined
          ? Boolean(input.isPopular)
          : Boolean(current.is_popular),
      ]
    );

    const row = updatedRes.rows[0];
    return {
      id: String(row.external_id),
      businessId: String(current.business_external_id),
      title: String(row.title),
      categorySlug: String(row.category_slug),
      category: String(row.category_label),
      durationMinutes: Number(row.duration_minutes),
      priceToman: Number(row.price_toman),
      description: String(row.description),
      isPopular: Boolean(row.is_popular),
      isActive: Boolean(row.is_active),
    };
  } finally {
    client.release();
  }
}

/**
 * حذف منطقی خدمت (Soft Delete: is_active = FALSE) برای حفظ یکپارچگی رزروهای قبلی
 */
export async function softDeleteServiceInDb(
  pool: Pool,
  serviceIdOrLegacy: string
): Promise<void> {
  const res = await pool.query(
    `
    UPDATE services
    SET is_active = FALSE, updated_at = NOW()
    WHERE id::text = $1 OR legacy_demo_id = $1
    RETURNING id
    `,
    [serviceIdOrLegacy]
  );
  if (!res.rowCount) {
    throw new Error('SERVICE_NOT_FOUND');
  }
}

/**
 * افزودن متخصص جدید به کسب‌وکار
 */
export async function createSpecialistInDb(
  pool: Pool,
  input: Omit<SpecialistItem, 'id'>
): Promise<SpecialistItem> {
  const client = await pool.connect();
  try {
    const biz = await resolveBusinessUuid(client, input.businessId);
    const uniqueSlug = `${normalizeValidSlug(input.slug || input.fullName, 'spc')}-${crypto.randomBytes(2).toString('hex')}`;

    const res = await client.query(
      `
      INSERT INTO specialists (
        business_id,
        slug,
        full_name,
        role_title,
        experience_years,
        rating_avg,
        review_count,
        specialties,
        bio,
        is_independent,
        is_active,
        city,
        starting_price_toman
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, TRUE, $11, $12)
      RETURNING
        COALESCE(legacy_demo_id, id::text) AS external_id,
        slug,
        full_name,
        role_title,
        experience_years,
        rating_avg,
        review_count,
        specialties,
        bio,
        is_independent,
        is_active,
        city,
        starting_price_toman
      `,
      [
        biz.id,
        uniqueSlug,
        input.fullName.trim(),
        input.roleTitle.trim(),
        Math.max(0, Math.min(80, Number(input.experienceYears) || 1)),
        Math.max(0, Math.min(5, Number(input.rating) || 4.9)),
        Math.max(0, Number(input.reviewCount) || 0),
        Array.isArray(input.specialties) ? input.specialties : [],
        (input.bio || '').trim(),
        Boolean(input.isIndependent),
        input.city || biz.city,
        Math.max(0, Number(input.startingPriceToman) || 350000),
      ]
    );

    const row = res.rows[0];
    return {
      id: String(row.external_id),
      slug: String(row.slug),
      fullName: String(row.full_name),
      roleTitle: String(row.role_title),
      businessId: biz.externalId,
      experienceYears: Number(row.experience_years),
      rating: Number(row.rating_avg),
      reviewCount: Number(row.review_count),
      specialties: Array.isArray(row.specialties)
        ? row.specialties.map(String)
        : [],
      bio: String(row.bio),
      isIndependent: Boolean(row.is_independent),
      isActive: Boolean(row.is_active),
      city: String(row.city || biz.city),
      startingPriceToman: Number(row.starting_price_toman),
    };
  } finally {
    client.release();
  }
}

/**
 * ویرایش اطلاعات متخصص
 */
export async function updateSpecialistInDb(
  pool: Pool,
  specialistIdOrLegacy: string,
  patch: Partial<SpecialistItem>
): Promise<SpecialistItem> {
  const client = await pool.connect();
  try {
    const existingRes = await client.query(
      `
      SELECT sp.*, COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id, b.city AS business_city
      FROM specialists sp
      JOIN businesses b ON b.id = sp.business_id
      WHERE sp.id::text = $1 OR sp.legacy_demo_id = $1
      LIMIT 1
      `,
      [specialistIdOrLegacy]
    );
    if (!existingRes.rowCount || !existingRes.rows[0]) {
      throw new Error('SPECIALIST_NOT_FOUND');
    }

    const current = existingRes.rows[0];
    const updatedRes = await client.query(
      `
      UPDATE specialists
      SET
        full_name = $2,
        role_title = $3,
        experience_years = $4,
        specialties = $5,
        bio = $6,
        starting_price_toman = $7,
        is_active = $8
      WHERE id = $1
      RETURNING
        COALESCE(legacy_demo_id, id::text) AS external_id,
        slug,
        full_name,
        role_title,
        experience_years,
        rating_avg,
        review_count,
        specialties,
        bio,
        is_independent,
        is_active,
        city,
        starting_price_toman
      `,
      [
        current.id,
        (patch.fullName ?? String(current.full_name)).trim(),
        (patch.roleTitle ?? String(current.role_title)).trim(),
        Math.max(
          0,
          Math.min(
            80,
            Number(patch.experienceYears ?? current.experience_years) || 1
          )
        ),
        Array.isArray(patch.specialties)
          ? patch.specialties
          : current.specialties,
        (patch.bio ?? String(current.bio)).trim(),
        Math.max(
          0,
          Number(patch.startingPriceToman ?? current.starting_price_toman) || 0
        ),
        patch.isActive !== undefined
          ? Boolean(patch.isActive)
          : Boolean(current.is_active),
      ]
    );

    const row = updatedRes.rows[0];
    return {
      id: String(row.external_id),
      slug: String(row.slug),
      fullName: String(row.full_name),
      roleTitle: String(row.role_title),
      businessId: String(current.business_external_id),
      experienceYears: Number(row.experience_years),
      rating: Number(row.rating_avg),
      reviewCount: Number(row.review_count),
      specialties: Array.isArray(row.specialties)
        ? row.specialties.map(String)
        : [],
      bio: String(row.bio),
      isIndependent: Boolean(row.is_independent),
      isActive: Boolean(row.is_active),
      city: String(row.city || current.business_city),
      startingPriceToman: Number(row.starting_price_toman),
    };
  } finally {
    client.release();
  }
}

/**
 * بروزرسانی مشخصات پروفایل کسب‌وکار و مختصات نقشه
 */
export async function updateBusinessProfileInDb(
  pool: Pool,
  businessIdOrLegacy: string,
  patch: Partial<BusinessItem>
): Promise<void> {
  const client = await pool.connect();
  try {
    const biz = await resolveBusinessUuid(client, businessIdOrLegacy);
    const currentRes = await client.query(
      `SELECT * FROM businesses WHERE id = $1`,
      [biz.id]
    );
    const current = currentRes.rows[0];

    const nextLat =
      patch.mapLat !== undefined
        ? patch.mapLat
        : current.map_lat !== null
          ? Number(current.map_lat)
          : null;
    const nextLng =
      patch.mapLng !== undefined
        ? patch.mapLng
        : current.map_lng !== null
          ? Number(current.map_lng)
          : null;

    const validCoords =
      nextLat !== null &&
      nextLng !== null &&
      nextLat >= -90 &&
      nextLat <= 90 &&
      nextLng >= -180 &&
      nextLng <= 180;

    await client.query(
      `
      UPDATE businesses
      SET
        name = $2,
        city = $3,
        neighborhood = $4,
        address = $5,
        phone_display = $6,
        instagram_handle = $7,
        short_description = $8,
        about_text = $9,
        map_lat = $10,
        map_lng = $11,
        subscription_plan = $12,
        subscription_status = $13
      WHERE id = $1
      `,
      [
        biz.id,
        (patch.name ?? String(current.name)).trim(),
        (patch.city ?? String(current.city)).trim(),
        (patch.neighborhood ?? String(current.neighborhood)).trim(),
        (patch.address ?? String(current.address)).trim(),
        (patch.phoneDisplay ?? String(current.phone_display)).trim(),
        patch.instagramHandle !== undefined
          ? patch.instagramHandle
          : current.instagram_handle,
        (patch.shortDescription ?? String(current.short_description)).trim(),
        (patch.aboutText ?? String(current.about_text)).trim(),
        validCoords ? nextLat : null,
        validCoords ? nextLng : null,
        patch.subscriptionPlan ?? String(current.subscription_plan),
        patch.subscriptionStatus ?? String(current.subscription_status),
      ]
    );
  } finally {
    client.release();
  }
}

/**
 * بروزرسانی ساعات کاری هفتگی کسب‌وکار
 */
export async function updateBusinessWorkingHoursInDb(
  pool: Pool,
  businessIdOrLegacy: string,
  workingHours: WorkingHourItem[]
): Promise<WorkingHourItem[]> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const biz = await resolveBusinessUuid(client, businessIdOrLegacy);

    for (let idx = 0; idx < Math.min(7, workingHours.length); idx++) {
      const item = workingHours[idx];
      const { openTimeSql, closeTimeSql } = normalizeWorkingTimePair(
        item.openTime,
        item.closeTime
      );
      await client.query(
        `
        INSERT INTO business_working_hours (
          business_id,
          day_of_week,
          day_name,
          is_open,
          open_time,
          close_time
        )
        VALUES ($1, $2, $3, $4, $5::time, $6::time)
        ON CONFLICT (business_id, day_of_week) DO UPDATE
        SET
          day_name = EXCLUDED.day_name,
          is_open = EXCLUDED.is_open,
          open_time = EXCLUDED.open_time,
          close_time = EXCLUDED.close_time,
          updated_at = NOW()
        `,
        [
          biz.id,
          idx,
          item.dayName,
          Boolean(item.isOpen),
          openTimeSql,
          closeTimeSql,
        ]
      );
    }

    await client.query('COMMIT');
    return workingHours;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * تغییر وضعیت تایید کسب‌وکار توسط ادمین پلتفرم
 */
export async function updateBusinessApprovalInDb(
  pool: Pool,
  businessIdOrLegacy: string,
  status: ApprovalStatus
): Promise<void> {
  const res = await pool.query(
    `
    UPDATE businesses
    SET
      approval_status = $2,
      verified_badge = ($2 = 'APPROVED'),
      updated_at = NOW()
    WHERE id::text = $1 OR legacy_demo_id = $1
    RETURNING id
    `,
    [businessIdOrLegacy, status]
  );
  if (!res.rowCount) {
    throw new Error('BUSINESS_NOT_FOUND');
  }
}

/**
 * ثبت نوبت جدید در PostgreSQL با رعایت کامل:
 * - Snapshot نام خدمت، قیمت، مدت و فاصله استراحت (buffer_minutes_snapshot)
 * - محاسبه دقیق ریاضی service_ends_at و occupied_until_at در موتور SQL
 * - بررسی خودکار قید EXCLUDE USING gist (کد خطای 23P01 در صورت تداخل زمانی متخصص)
 * - ثبت لاگ تغییر وضعیت و بروزرسانی پرونده CRM مشتری
 */
export async function createAppointmentInDb(
  pool: Pool,
  input: {
    businessSlug?: string;
    businessId?: string;
    serviceId: string;
    specialistId: string;
    dateJalali: string;
    timeSlot: string;
    customerName: string;
    customerPhone: string;
    customerNotes?: string;
    serviceStartsAtIso?: string;
  }
): Promise<AppointmentItem> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const biz = await resolveBusinessUuid(
      client,
      input.businessSlug || input.businessId
    );

    const srvRes = await client.query(
      `
      SELECT id, COALESCE(legacy_demo_id, id::text) AS external_id, title, duration_minutes, price_toman
      FROM services
      WHERE business_id = $1 AND (id::text = $2 OR legacy_demo_id = $2)
      LIMIT 1
      `,
      [biz.id, input.serviceId]
    );
    const fallbackSrvRes =
      srvRes.rowCount && srvRes.rows[0]
        ? srvRes
        : await client.query(
            `
            SELECT id, COALESCE(legacy_demo_id, id::text) AS external_id, title, duration_minutes, price_toman
            FROM services
            WHERE business_id = $1 AND is_active = TRUE
            ORDER BY is_popular DESC, created_at ASC
            LIMIT 1
            `,
            [biz.id]
          );

    if (!fallbackSrvRes.rowCount || !fallbackSrvRes.rows[0]) {
      throw new Error('SERVICE_NOT_FOUND_FOR_BUSINESS');
    }
    const srv = fallbackSrvRes.rows[0];

    const spcRes = await client.query(
      `
      SELECT id, COALESCE(legacy_demo_id, id::text) AS external_id, full_name
      FROM specialists
      WHERE business_id = $1 AND (id::text = $2 OR legacy_demo_id = $2)
      LIMIT 1
      `,
      [biz.id, input.specialistId]
    );
    const fallbackSpcRes =
      spcRes.rowCount && spcRes.rows[0]
        ? spcRes
        : await client.query(
            `
            SELECT id, COALESCE(legacy_demo_id, id::text) AS external_id, full_name
            FROM specialists
            WHERE business_id = $1 AND is_active = TRUE
            ORDER BY rating_avg DESC, created_at ASC
            LIMIT 1
            `,
            [biz.id]
          );

    if (!fallbackSpcRes.rowCount || !fallbackSpcRes.rows[0]) {
      throw new Error('SPECIALIST_NOT_FOUND_FOR_BUSINESS');
    }
    const spc = fallbackSpcRes.rows[0];

    const settingsRes = await client.query(
      `SELECT buffer_minutes FROM business_settings WHERE business_id = $1`,
      [biz.id]
    );
    const bufferMinutes =
      settingsRes.rowCount && settingsRes.rows[0]
        ? Number(settingsRes.rows[0].buffer_minutes)
        : 15;

    const startsAtDate = input.serviceStartsAtIso
      ? new Date(input.serviceStartsAtIso)
      : jalaliSlotToTimestamptz(input.dateJalali, input.timeSlot);

    const cleanPhone = toEnglishDigits(input.customerPhone).replace(/\D/g, '');
    const normalizedPhone = /^09\d{9}$/.test(cleanPhone)
      ? cleanPhone
      : '09123456789';
    const maskedPhone = maskPhoneDisplay(normalizedPhone);
    const referenceCode = `BH-${Math.floor(100000 + Math.random() * 899999)}`;
    const durationMinutes = Number(srv.duration_minutes);
    const priceToman = Number(srv.price_toman);

    const insertRes = await client.query(
      `
      INSERT INTO appointments (
        reference_code,
        business_id,
        service_id,
        specialist_id,
        service_title_snapshot,
        service_price_toman_snapshot,
        duration_minutes_snapshot,
        buffer_minutes_snapshot,
        specialist_name_snapshot,
        customer_name,
        customer_phone,
        customer_phone_masked,
        date_jalali,
        time_slot_label,
        service_starts_at,
        service_ends_at,
        occupied_until_at,
        status,
        notes
      )
      VALUES (
        $1,
        $2,
        $3,
        $4,
        $5,
        $6,
        $7::smallint,
        $8::smallint,
        $9,
        $10,
        $11,
        $12,
        $13,
        $14,
        $15::timestamptz,
        $15::timestamptz + ($7::smallint * INTERVAL '1 minute'),
        $15::timestamptz + (($7::smallint + $8::smallint) * INTERVAL '1 minute'),
        'CONFIRMED',
        $16
      )
      RETURNING
        id,
        COALESCE(legacy_demo_id, id::text) AS external_id,
        reference_code,
        date_jalali,
        time_slot_label,
        status,
        notes
      `,
      [
        referenceCode,
        biz.id,
        srv.id,
        spc.id,
        String(srv.title),
        priceToman,
        durationMinutes,
        bufferMinutes,
        String(spc.full_name),
        input.customerName.trim(),
        normalizedPhone,
        maskedPhone,
        input.dateJalali,
        input.timeSlot,
        startsAtDate.toISOString(),
        input.customerNotes?.trim() || null,
      ]
    );

    const aptRow = insertRes.rows[0];

    await client.query(
      `
      INSERT INTO appointment_status_logs (
        appointment_id,
        previous_status,
        new_status,
        note
      )
      VALUES ($1, NULL, 'CONFIRMED', 'ثبت رزرو آنلاین توسط مشتری')
      `,
      [aptRow.id]
    );

    await client.query(
      `
      INSERT INTO business_customers (
        business_id,
        full_name,
        phone,
        phone_masked,
        city,
        total_visits,
        last_visit_jalali,
        total_spent_toman,
        favorite_service_title,
        notes
      )
      VALUES ($1, $2, $3, $4, $5, 1, $6, $7, $8, $9)
      ON CONFLICT (business_id, phone) DO UPDATE
      SET
        full_name = EXCLUDED.full_name,
        total_visits = business_customers.total_visits + 1,
        last_visit_jalali = EXCLUDED.last_visit_jalali,
        total_spent_toman = business_customers.total_spent_toman + EXCLUDED.total_spent_toman,
        favorite_service_title = EXCLUDED.favorite_service_title,
        updated_at = NOW()
      `,
      [
        biz.id,
        input.customerName.trim(),
        normalizedPhone,
        maskedPhone,
        biz.city,
        input.dateJalali,
        priceToman,
        String(srv.title),
        input.customerNotes?.trim() || '',
      ]
    );

    await client.query('COMMIT');

    return {
      id: String(aptRow.external_id),
      referenceCode: String(aptRow.reference_code),
      businessId: biz.externalId,
      businessSlug: biz.slug,
      businessName: biz.name,
      serviceId: String(srv.external_id),
      serviceTitle: String(srv.title),
      specialistId: String(spc.external_id),
      specialistName: String(spc.full_name),
      customerName: input.customerName.trim(),
      customerPhoneMasked: maskedPhone,
      dateJalali: String(aptRow.date_jalali),
      timeSlot: String(aptRow.time_slot_label),
      durationMinutes,
      priceToman,
      status: aptRow.status as AppointmentStatus,
      notes: aptRow.notes ? String(aptRow.notes) : undefined,
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * تغییر وضعیت نوبت با رعایت کامل قید chk_appointments_cancellation_consistency
 * و ثبت در جدول appointment_status_logs
 */
export async function updateAppointmentStatusInDb(
  pool: Pool,
  appointmentIdOrLegacy: string,
  newStatus: AppointmentStatus,
  cancelledReason?: string
): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const curRes = await client.query(
      `
      SELECT id, status
      FROM appointments
      WHERE id::text = $1 OR legacy_demo_id = $1
      FOR UPDATE
      `,
      [appointmentIdOrLegacy]
    );

    if (!curRes.rowCount || !curRes.rows[0]) {
      throw new Error('APPOINTMENT_NOT_FOUND');
    }

    const aptId = String(curRes.rows[0].id);
    const prevStatus = String(curRes.rows[0].status);

    await client.query(
      `
      UPDATE appointments
      SET
        status = $2::varchar,
        cancelled_at = CASE WHEN $2::varchar = 'CANCELLED' THEN NOW() ELSE NULL END,
        cancelled_reason = CASE WHEN $2::varchar = 'CANCELLED' THEN COALESCE($3, 'لغو توسط کاربر یا مدیر سالن') ELSE NULL END,
        updated_at = NOW()
      WHERE id = $1
      `,
      [aptId, newStatus, cancelledReason || null]
    );

    await client.query(
      `
      INSERT INTO appointment_status_logs (
        appointment_id,
        previous_status,
        new_status,
        note
      )
      VALUES ($1, $2, $3, $4)
      `,
      [
        aptId,
        prevStatus,
        newStatus,
        cancelledReason || `تغییر وضعیت از ${prevStatus} به ${newStatus}`,
      ]
    );

    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * ایجاد یا ویرایش دسته‌بندی خدمات توسط ادمین
 */
export async function createCategoryInDb(
  pool: Pool,
  input: Omit<CategoryItem, 'id'>
): Promise<CategoryItem> {
  const validSlug = normalizeValidSlug(input.slug || input.title, 'cat');
  const res = await pool.query(
    `
    INSERT INTO categories (
      slug,
      title,
      subtitle,
      target_audience,
      icon_name,
      service_count,
      is_active
    )
    VALUES ($1, $2, $3, $4, $5, $6, TRUE)
    RETURNING
      COALESCE(legacy_demo_id, id::text) AS external_id,
      slug,
      title,
      subtitle,
      target_audience,
      icon_name,
      service_count
    `,
    [
      validSlug,
      input.title.trim(),
      (input.subtitle || '').trim(),
      (input.targetAudience || '').trim(),
      input.iconName || 'Sparkles',
      Math.max(0, Number(input.serviceCount) || 0),
    ]
  );
  const r = res.rows[0];
  return {
    id: String(r.external_id),
    slug: String(r.slug),
    title: String(r.title),
    subtitle: String(r.subtitle),
    targetAudience: String(r.target_audience),
    iconName: String(r.icon_name),
    serviceCount: Number(r.service_count),
  };
}

export async function updateCategoryInDb(
  pool: Pool,
  categoryIdOrLegacy: string,
  input: Partial<Omit<CategoryItem, 'id'>>
): Promise<CategoryItem> {
  const existingRes = await pool.query(
    `SELECT * FROM categories WHERE id::text = $1 OR legacy_demo_id = $1 LIMIT 1`,
    [categoryIdOrLegacy]
  );
  if (!existingRes.rowCount || !existingRes.rows[0]) {
    throw new Error('CATEGORY_NOT_FOUND');
  }
  const cur = existingRes.rows[0];
  const nextSlug = input.slug
    ? normalizeValidSlug(input.slug, 'cat')
    : String(cur.slug);

  const res = await pool.query(
    `
    UPDATE categories
    SET
      slug = $2,
      title = $3,
      subtitle = $4,
      target_audience = $5,
      icon_name = $6,
      service_count = $7,
      updated_at = NOW()
    WHERE id = $1
    RETURNING
      COALESCE(legacy_demo_id, id::text) AS external_id,
      slug,
      title,
      subtitle,
      target_audience,
      icon_name,
      service_count
    `,
    [
      cur.id,
      nextSlug,
      (input.title ?? String(cur.title)).trim(),
      (input.subtitle ?? String(cur.subtitle)).trim(),
      (input.targetAudience ?? String(cur.target_audience)).trim(),
      input.iconName ?? String(cur.icon_name),
      Math.max(0, Number(input.serviceCount ?? cur.service_count) || 0),
    ]
  );
  const r = res.rows[0];
  return {
    id: String(r.external_id),
    slug: String(r.slug),
    title: String(r.title),
    subtitle: String(r.subtitle),
    targetAudience: String(r.target_audience),
    iconName: String(r.icon_name),
    serviceCount: Number(r.service_count),
  };
}

/**
 * افزودن و حذف آیتم گالری نمونه کارها
 */
export async function createGalleryItemInDb(
  pool: Pool,
  input: Omit<GalleryItem, 'id'>
): Promise<GalleryItem> {
  const client = await pool.connect();
  try {
    const biz = await resolveBusinessUuid(client, input.businessId);
    const validTheme: VisualTheme = ['rose', 'slate', 'emerald', 'violet'].includes(
      input.theme
    )
      ? input.theme
      : 'violet';

    const res = await client.query(
      `
      INSERT INTO gallery_items (business_id, title, category_label, theme)
      VALUES ($1, $2, $3, $4)
      RETURNING COALESCE(legacy_demo_id, id::text) AS external_id, title, category_label, theme
      `,
      [biz.id, input.title.trim(), input.categoryLabel.trim(), validTheme]
    );
    const r = res.rows[0];
    return {
      id: String(r.external_id),
      businessId: biz.externalId,
      title: String(r.title),
      categoryLabel: String(r.category_label),
      theme: r.theme as VisualTheme,
    };
  } finally {
    client.release();
  }
}

export async function deleteGalleryItemInDb(
  pool: Pool,
  galleryIdOrLegacy: string
): Promise<void> {
  const res = await pool.query(
    `DELETE FROM gallery_items WHERE id::text = $1 OR legacy_demo_id = $1 RETURNING id`,
    [galleryIdOrLegacy]
  );
  if (!res.rowCount) {
    throw new Error('GALLERY_ITEM_NOT_FOUND');
  }
}

/**
 * ایجاد کمپین بازاریابی جدید برای سالن
 */
export async function createCampaignInDb(
  pool: Pool,
  input: Omit<MarketingCampaignItem, 'id'> & { businessId?: string }
): Promise<MarketingCampaignItem> {
  const client = await pool.connect();
  try {
    const biz = await resolveBusinessUuid(client, input.businessId);
    const res = await client.query(
      `
      INSERT INTO marketing_campaigns (
        business_id,
        title,
        target_segment,
        discount_percent,
        channel,
        status_label,
        created_at_jalali
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING
        COALESCE(legacy_demo_id, id::text) AS external_id,
        title,
        target_segment,
        discount_percent,
        channel,
        status_label,
        created_at_jalali
      `,
      [
        biz.id,
        input.title.trim(),
        input.targetSegment.trim(),
        Math.max(1, Math.min(100, Number(input.discountPercent) || 15)),
        input.channel.trim(),
        input.statusLabel || 'زمان‌بندی‌شده',
        input.createdAtJalali || '۱۴۰۵/۰۸/۰۱',
      ]
    );
    const r = res.rows[0];
    return {
      id: String(r.external_id),
      title: String(r.title),
      targetSegment: String(r.target_segment),
      discountPercent: Number(r.discount_percent),
      channel: String(r.channel),
      statusLabel: String(r.status_label),
      createdAtJalali: String(r.created_at_jalali),
    };
  } finally {
    client.release();
  }
}

/**
 * تغییر وضعیت نشان‌شده (علاقه‌مندی) کسب‌وکار برای مشتری در دیتابیس
 */
export async function toggleFavoriteBusinessInDb(
  pool: Pool,
  businessIdOrLegacy: string,
  customerPhone = '09123456789'
): Promise<{ favorited: boolean; favoriteBusinessIds: string[] }> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const biz = await resolveBusinessUuid(client, businessIdOrLegacy);
    const cleanPhone = toEnglishDigits(customerPhone).replace(/\D/g, '');
    const validPhone = /^09\d{9}$/.test(cleanPhone) ? cleanPhone : '09123456789';

    const userRes = await client.query(
      `
      INSERT INTO users (phone, full_name, default_city)
      VALUES ($1, 'المیرا شمس', 'تهران')
      ON CONFLICT (phone) DO UPDATE SET updated_at = NOW()
      RETURNING id
      `,
      [validPhone]
    );
    const userId = String(userRes.rows[0].id);

    const existing = await client.query(
      `SELECT 1 FROM customer_favorites WHERE user_id = $1 AND business_id = $2`,
      [userId, biz.id]
    );

    let favorited = false;
    if (existing.rowCount && existing.rowCount > 0) {
      await client.query(
        `DELETE FROM customer_favorites WHERE user_id = $1 AND business_id = $2`,
        [userId, biz.id]
      );
      favorited = false;
    } else {
      await client.query(
        `INSERT INTO customer_favorites (user_id, business_id) VALUES ($1, $2)`,
        [userId, biz.id]
      );
      favorited = true;
    }

    const favListRes = await client.query(
      `
      SELECT COALESCE(b.legacy_demo_id, b.id::text) AS business_external_id
      FROM customer_favorites cf
      JOIN businesses b ON b.id = cf.business_id
      WHERE cf.user_id = $1
      `,
      [userId]
    );

    await client.query('COMMIT');
    return {
      favorited,
      favoriteBusinessIds: favListRes.rows.map((r) =>
        String(r.business_external_id)
      ),
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * ثبت کامل کسب‌وکار جدید از ویزارد ۵ مرحله‌ای راه‌اندازی (/business/register -> /business/ready)
 */
export async function onboardBusinessInDb(
  pool: Pool,
  draft: OnboardingDraft
): Promise<{ businessId: string; slug: string }> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const cleanPhone = toEnglishDigits(draft.phone || '').replace(/\D/g, '');
    const ownerPhone = /^09\d{9}$/.test(cleanPhone)
      ? cleanPhone
      : `0912${Math.floor(1000000 + Math.random() * 8999999)}`;

    const userRes = await client.query(
      `
      INSERT INTO users (phone, full_name, default_city)
      VALUES ($1, $2, $3)
      ON CONFLICT (phone) DO UPDATE
      SET full_name = EXCLUDED.full_name, updated_at = NOW()
      RETURNING id
      `,
      [
        ownerPhone,
        (draft.ownerName || 'مدیر سالن').trim(),
        draft.city || 'تهران',
      ]
    );
    const ownerUserId = String(userRes.rows[0].id);

    const cat = await resolveCategoryBySlug(
      client,
      draft.categorySlug || 'hair-color'
    );
    const slug = `${normalizeValidSlug(draft.slug || draft.businessName, 'salon')}-${crypto.randomBytes(2).toString('hex')}`;

    const typeLabelMap: Record<BusinessType, string> = {
      [BusinessType.WomenSalon]: 'سالن زیبایی بانوان',
      [BusinessType.MenBarbershop]: 'آرایشگاه و پیرایش مردانه',
      [BusinessType.IndependentSpecialist]: 'متخصص مستقل زیبایی',
    };

    const startingPrice =
      draft.services.length > 0
        ? Math.min(...draft.services.map((s) => Number(s.priceToman) || 350000))
        : 350000;

    const nationalIdHash = draft.nationalIdNumber
      ? crypto
          .createHash('sha256')
          .update(draft.nationalIdNumber.trim())
          .digest('hex')
      : null;

    const bizRes = await client.query(
      `
      INSERT INTO businesses (
        owner_user_id,
        primary_category_id,
        slug,
        name,
        type,
        type_label,
        city,
        neighborhood,
        address,
        map_lat,
        map_lng,
        phone_display,
        instagram_handle,
        short_description,
        about_text,
        visual_theme,
        starting_price_toman,
        verified_badge,
        approval_status,
        subscription_plan,
        subscription_status,
        license_code,
        national_id_hash
      )
      VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,
        $12, $13, $14, $15, 'rose', $16, FALSE, 'PENDING_REVIEW',
        'حرفه‌ای (رشد سالن)', 'TRIAL', $17, $18
      )
      RETURNING id, slug
      `,
      [
        ownerUserId,
        cat.id,
        slug,
        draft.businessName.trim(),
        draft.businessType || BusinessType.WomenSalon,
        typeLabelMap[draft.businessType] || 'سالن زیبایی بانوان',
        draft.city.trim(),
        draft.neighborhood.trim(),
        draft.address.trim(),
        draft.mapLat ?? null,
        draft.mapLng ?? null,
        draft.phone.trim(),
        draft.instagramHandle || null,
        draft.shortDescription.trim().slice(0, 290),
        draft.shortDescription.trim(),
        startingPrice,
        draft.licenseCode || null,
        nationalIdHash,
      ]
    );

    const newBizId = String(bizRes.rows[0].id);

    await client.query(
      `INSERT INTO business_settings (business_id) VALUES ($1) ON CONFLICT (business_id) DO NOTHING`,
      [newBizId]
    );

    for (let idx = 0; idx < Math.min(7, draft.workingHours.length); idx++) {
      const wh = draft.workingHours[idx];
      const { openTimeSql, closeTimeSql } = normalizeWorkingTimePair(
        wh.openTime,
        wh.closeTime
      );
      await client.query(
        `
        INSERT INTO business_working_hours (
          business_id, day_of_week, day_name, is_open, open_time, close_time
        )
        VALUES ($1, $2, $3, $4, $5::time, $6::time)
        `,
        [
          newBizId,
          idx,
          wh.dayName,
          Boolean(wh.isOpen),
          openTimeSql,
          closeTimeSql,
        ]
      );
    }

    for (const srv of draft.services) {
      await client.query(
        `
        INSERT INTO services (
          business_id, category_id, category_slug, category_label,
          title, description, duration_minutes, price_toman, is_popular, is_active
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, TRUE, TRUE)
        `,
        [
          newBizId,
          cat.id,
          cat.slug,
          srv.category || cat.title,
          srv.title.trim(),
          srv.title.trim(),
          Math.max(5, Math.min(600, Number(srv.durationMinutes) || 60)),
          Math.max(0, Number(srv.priceToman) || 350000),
        ]
      );
    }

    for (const stf of draft.staff) {
      const spcSlug = `${normalizeValidSlug(stf.fullName, 'spc')}-${crypto.randomBytes(2).toString('hex')}`;
      await client.query(
        `
        INSERT INTO specialists (
          business_id, slug, full_name, role_title, experience_years,
          specialties, bio, is_independent, is_active, city, starting_price_toman
        )
        VALUES ($1, $2, $3, $4, 3, $5, $6, FALSE, TRUE, $7, $8)
        `,
        [
          newBizId,
          spcSlug,
          stf.fullName.trim(),
          stf.roleTitle.trim(),
          [stf.roleTitle.trim()],
          `${stf.roleTitle.trim()} در ${draft.businessName.trim()}`,
          draft.city.trim(),
          startingPrice,
        ]
      );
    }

    await client.query('COMMIT');
    return {
      businessId: newBizId,
      slug: String(bizRes.rows[0].slug),
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * صدور اتمیک کد یک‌بارمصرف (OTP) با کنترل نرخ درخواست در PostgreSQL
 */
export async function requestOtpInDb(
  pool: Pool,
  rawPhone: string,
  requestIp: string
): Promise<{
  allowed: boolean;
  challengeId?: string;
  retryAfterSec?: number;
  reasonCode: string;
}> {
  const cleanPhone = toEnglishDigits(rawPhone).replace(/\D/g, '');
  if (!/^09\d{9}$/.test(cleanPhone)) {
    throw new Error('INVALID_IRAN_MOBILE_PHONE');
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const rlRes = await client.query(
      `SELECT * FROM check_and_increment_auth_rate_limit($1, 600, 5, 60)`,
      [`otp_send:${cleanPhone}`]
    );
    const rl = rlRes.rows[0];
    if (!rl.allowed) {
      await client.query('COMMIT');
      return {
        allowed: false,
        retryAfterSec: Number(rl.retry_after_sec),
        reasonCode: String(rl.reason_code),
      };
    }

    const otpSecret = process.env.OTP_HMAC_SECRET || 'beautyhub-otp-hmac-key';
    const generatedCode = String(Math.floor(100000 + Math.random() * 900000));
    const codeHmac = crypto
      .createHmac('sha256', otpSecret)
      .update(`${cleanPhone}:${generatedCode}`)
      .digest('hex');

    const issueRes = await client.query(
      `SELECT issue_otp_challenge_atomic($1, $2, $3, 120, 5::smallint) AS challenge_id`,
      [cleanPhone, codeHmac, requestIp || '127.0.0.1']
    );

    await client.query('COMMIT');
    return {
      allowed: true,
      challengeId: String(issueRes.rows[0].challenge_id),
      reasonCode: 'OTP_ISSUED',
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * بررسی اتمیک کد OTP و ایجاد نشست کاربری در صورت صحت کد
 * توجه مهم: در صورت عدم تطابق کد، تراکنش COMMIT می‌شود تا افزایش شمارنده تلاش‌های ناموفق
 * (attempts_count) و تغییر وضعیت به LOCKED در دیتابیس ماندگار شود.
 */
export async function verifyOtpInDb(
  pool: Pool,
  rawPhone: string,
  rawCode: string,
  requestIp: string,
  userAgent: string
): Promise<{
  verified: boolean;
  outcomeCode: string;
  remainingAttempts: number;
  userId?: string;
}> {
  const cleanPhone = toEnglishDigits(rawPhone).replace(/\D/g, '');
  const cleanCode = toEnglishDigits(rawCode).trim();
  if (!/^09\d{9}$/.test(cleanPhone)) {
    throw new Error('INVALID_IRAN_MOBILE_PHONE');
  }

  const otpSecret = process.env.OTP_HMAC_SECRET || 'beautyhub-otp-hmac-key';
  const candidateHmac = crypto
    .createHmac('sha256', otpSecret)
    .update(`${cleanPhone}:${cleanCode}`)
    .digest('hex');

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const verifyRes = await client.query(
      `SELECT * FROM verify_otp_challenge_atomic($1, $2)`,
      [cleanPhone, candidateHmac]
    );
    const row = verifyRes.rows[0];

    if (!row.verified) {
      // COMMIT الزامی است تا افزایش attempts_count یا وضعیت LOCKED/EXPIRED در دیتابیس ذخیره شود
      await client.query('COMMIT');
      return {
        verified: false,
        outcomeCode: String(row.outcome_code),
        remainingAttempts: Number(row.remaining_attempts),
      };
    }

    const userRes = await client.query(
      `
      INSERT INTO users (phone, full_name, default_city)
      VALUES ($1, 'کاربر BeautyHub', 'تهران')
      ON CONFLICT (phone) DO UPDATE SET updated_at = NOW()
      RETURNING id
      `,
      [cleanPhone]
    );
    const userId = String(userRes.rows[0].id);

    const rawRefreshToken = crypto.randomBytes(32).toString('hex');
    const refreshTokenHash = crypto
      .createHash('sha256')
      .update(rawRefreshToken)
      .digest('hex');

    await client.query(
      `
      INSERT INTO user_sessions (
        user_id,
        refresh_token_hash,
        ip_address,
        user_agent,
        expires_at
      )
      VALUES ($1, $2, $3, $4, NOW() + INTERVAL '30 days')
      `,
      [userId, refreshTokenHash, requestIp || '127.0.0.1', userAgent || 'web']
    );

    await client.query('COMMIT');
    return {
      verified: true,
      outcomeCode: 'VERIFIED',
      remainingAttempts: Number(row.remaining_attempts),
      userId,
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
