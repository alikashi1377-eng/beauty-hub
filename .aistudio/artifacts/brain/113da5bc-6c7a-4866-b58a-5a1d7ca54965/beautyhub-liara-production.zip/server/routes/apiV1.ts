import { Router, Request, Response } from 'express';
import { loadServerEnv, ServerEnvConfig } from '../config/env';
import {
  checkDatabaseHealth,
  getOrCreatePool,
  sanitizeDatabaseError,
} from '../db/pool';
import {
  createAppointmentInDb,
  createCampaignInDb,
  createCategoryInDb,
  createGalleryItemInDb,
  createServiceInDb,
  createSpecialistInDb,
  deleteGalleryItemInDb,
  getBootstrapPayload,
  onboardBusinessInDb,
  requestOtpInDb,
  softDeleteServiceInDb,
  toggleFavoriteBusinessInDb,
  updateAppointmentStatusInDb,
  updateBusinessApprovalInDb,
  updateBusinessProfileInDb,
  updateBusinessWorkingHoursInDb,
  updateCategoryInDb,
  updateServiceInDb,
  updateSpecialistInDb,
  verifyOtpInDb,
} from '../repositories/beautyhubRepository';
import { AppointmentStatus, ApprovalStatus } from '../../src/types';

function handleRealModeRouteError(res: Response, err: unknown): void {
  const pgCode =
    err && typeof err === 'object' && 'code' in err
      ? String((err as { code?: unknown }).code ?? '')
      : '';
  const errMsg = err instanceof Error ? err.message : String(err);

  if (pgCode === '23P01') {
    res.status(409).json({
      ok: false,
      mode: 'real',
      errorCode: 'APPOINTMENT_OVERLAP_CONFLICT',
      message:
        'این بازه زمانی (با احتساب فاصله استراحت بین دو نوبت) برای این متخصص قبلاً رزرو شده است. لطفاً ساعت یا متخصص دیگری را انتخاب کنید.',
    });
    return;
  }

  if (pgCode === '42P01') {
    res.status(503).json({
      ok: false,
      mode: 'real',
      errorCode: 'DATABASE_SCHEMA_NOT_MIGRATED',
      message:
        'جداول دیتابیس PostgreSQL هنوز ایجاد نشده‌اند. لطفاً ابتدا دستور npm run db:migrate را اجرا کنید.',
    });
    return;
  }

  if (
    errMsg === 'BUSINESS_NOT_FOUND' ||
    errMsg === 'SERVICE_NOT_FOUND' ||
    errMsg === 'SPECIALIST_NOT_FOUND' ||
    errMsg === 'APPOINTMENT_NOT_FOUND' ||
    errMsg === 'CATEGORY_NOT_FOUND' ||
    errMsg === 'GALLERY_ITEM_NOT_FOUND'
  ) {
    res.status(404).json({
      ok: false,
      mode: 'real',
      errorCode: errMsg,
      message: 'رکورد درخواستی در پایگاه داده یافت نشد.',
    });
    return;
  }

  if (errMsg === 'INVALID_IRAN_MOBILE_PHONE') {
    res.status(400).json({
      ok: false,
      mode: 'real',
      errorCode: 'INVALID_IRAN_MOBILE_PHONE',
      message: 'شماره موبایل واردشده معتبر نیست (فرمت صحیح: 09123456789).',
    });
    return;
  }

  const safe = sanitizeDatabaseError(err);
  res.status(500).json({
    ok: false,
    mode: 'real',
    errorCode: safe.errorCode || 'DATABASE_OPERATION_ERROR',
    message:
      safe.safeMessage ||
      'خطا در اجرای عملیات روی پایگاه داده PostgreSQL. به داده‌های آزمایشی بازگشت داده نمی‌شود.',
  });
}

export function createApiV1Router(customEnv?: ServerEnvConfig): Router {
  const router = Router();

  const resolvePoolOrFail = async (res: Response) => {
    const config = customEnv ?? loadServerEnv();
    if (config.dataMode === 'mock') {
      return { mode: 'mock' as const, pool: null };
    }

    const health = await checkDatabaseHealth(config);
    const pool = getOrCreatePool(config);
    if (!health.connected || !pool) {
      res.status(503).json({
        ok: false,
        mode: 'real',
        errorCode: health.errorCode ?? 'REAL_MODE_DATABASE_UNAVAILABLE',
        message:
          'اتصال به دیتابیس PostgreSQL برقرار نیست؛ سامانه به صورت خاموش به داده‌های آزمایشی (Mock) برنمی‌گردد.',
      });
      return { mode: 'real' as const, pool: null };
    }

    return { mode: 'real' as const, pool };
  };

  /**
   * ۱. دریافت یکپارچه داده‌های اولیه بازارچه، پنل کسب‌وکار و پنل ادمین
   * GET /api/v1/bootstrap
   */
  router.get('/bootstrap', async (_req: Request, res: Response) => {
    const { mode, pool } = await resolvePoolOrFail(res);
    if (mode === 'mock') {
      res.status(200).json({
        ok: true,
        mode: 'mock',
        data: null,
        message: 'سرور در حالت نمایشی (mock) فعال است.',
      });
      return;
    }
    if (!pool) return;

    try {
      const data = await getBootstrapPayload(pool);
      res.status(200).json({
        ok: true,
        mode: 'real',
        data,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۲. فهرست سالن‌ها و مراکز زیبایی
   * GET /api/v1/businesses
   */
  router.get('/businesses', async (req: Request, res: Response) => {
    const { mode, pool } = await resolvePoolOrFail(res);
    if (mode === 'mock') {
      res.status(200).json({ ok: true, mode: 'mock', items: null });
      return;
    }
    if (!pool) return;

    try {
      const payload = await getBootstrapPayload(pool);
      const city = typeof req.query.city === 'string' ? req.query.city.trim() : '';
      const category =
        typeof req.query.category === 'string' ? req.query.category.trim() : '';
      const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';

      const filtered = payload.businesses.filter((b) => {
        if (city && city !== 'ALL' && b.city !== city) return false;
        if (
          category &&
          category !== 'ALL' &&
          b.categorySlug !== category
        )
          return false;
        if (
          q &&
          !b.name.includes(q) &&
          !b.neighborhood.includes(q) &&
          !b.shortDescription.includes(q)
        )
          return false;
        return true;
      });

      res.status(200).json({
        ok: true,
        mode: 'real',
        items: filtered,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۳. جزئیات یک سالن بر اساس اسلاگ یا شناسه
   * GET /api/v1/businesses/:slug
   */
  router.get('/businesses/:slug', async (req: Request, res: Response) => {
    const { mode, pool } = await resolvePoolOrFail(res);
    if (mode === 'mock') {
      res.status(200).json({ ok: true, mode: 'mock', item: null });
      return;
    }
    if (!pool) return;

    try {
      const payload = await getBootstrapPayload(pool);
      const slug = req.params.slug;
      const business = payload.businesses.find(
        (b) => b.slug === slug || b.id === slug
      );
      if (!business) {
        res.status(404).json({
          ok: false,
          mode: 'real',
          errorCode: 'BUSINESS_NOT_FOUND',
          message: 'مرکز زیبایی مورد نظر یافت نشد.',
        });
        return;
      }

      res.status(200).json({
        ok: true,
        mode: 'real',
        item: business,
        services: payload.services.filter((s) => s.businessId === business.id),
        specialists: payload.specialists.filter(
          (sp) => sp.businessId === business.id
        ),
        reviews: payload.reviews.filter((r) => r.businessId === business.id),
        gallery: payload.gallery.filter((g) => g.businessId === business.id),
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۴. فهرست متخصصان
   * GET /api/v1/specialists
   */
  router.get('/specialists', async (_req: Request, res: Response) => {
    const { mode, pool } = await resolvePoolOrFail(res);
    if (mode === 'mock') {
      res.status(200).json({ ok: true, mode: 'mock', items: null });
      return;
    }
    if (!pool) return;

    try {
      const payload = await getBootstrapPayload(pool);
      res.status(200).json({
        ok: true,
        mode: 'real',
        items: payload.specialists,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۵. فهرست دسته‌بندی‌ها و پلن‌ها
   * GET /api/v1/categories
   * GET /api/v1/plans
   */
  router.get('/categories', async (_req: Request, res: Response) => {
    const { mode, pool } = await resolvePoolOrFail(res);
    if (mode === 'mock') {
      res.status(200).json({ ok: true, mode: 'mock', items: null });
      return;
    }
    if (!pool) return;

    try {
      const payload = await getBootstrapPayload(pool);
      res.status(200).json({
        ok: true,
        mode: 'real',
        items: payload.categories,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.get('/plans', async (_req: Request, res: Response) => {
    const { mode, pool } = await resolvePoolOrFail(res);
    if (mode === 'mock') {
      res.status(200).json({ ok: true, mode: 'mock', items: null });
      return;
    }
    if (!pool) return;

    try {
      const payload = await getBootstrapPayload(pool);
      res.status(200).json({
        ok: true,
        mode: 'real',
        items: payload.plans,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۶. راه‌اندازی و ثبت کسب‌وکار جدید
   * POST /api/v1/businesses/onboard
   */
  router.post('/businesses/onboard', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const created = await onboardBusinessInDb(pool, req.body);
      const data = await getBootstrapPayload(pool);
      res.status(201).json({
        ok: true,
        mode: 'real',
        businessId: created.businessId,
        slug: created.slug,
        data,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۷. بروزرسانی پروفایل و ساعات کاری کسب‌وکار در پنل مدیریت سالن (/app/profile, /app/hours)
   */
  router.put('/businesses/:id/profile', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      await updateBusinessProfileInDb(pool, req.params.id, req.body);
      res.status(200).json({
        ok: true,
        mode: 'real',
        message: 'مشخصات پروفایل کسب‌وکار در دیتابیس بروزرسانی شد.',
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.put(
    '/businesses/:id/working-hours',
    async (req: Request, res: Response) => {
      const { pool } = await resolvePoolOrFail(res);
      if (!pool) return;

      try {
        const workingHours = Array.isArray(req.body?.workingHours)
          ? req.body.workingHours
          : [];
        const updated = await updateBusinessWorkingHoursInDb(
          pool,
          req.params.id,
          workingHours
        );
        res.status(200).json({
          ok: true,
          mode: 'real',
          workingHours: updated,
        });
      } catch (err) {
        handleRealModeRouteError(res, err);
      }
    }
  );

  /**
   * ۸. مدیریت خدمات سالن (/app/services) با سیاست Soft Delete
   */
  router.post('/services', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await createServiceInDb(pool, req.body);
      res.status(201).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.put('/services/:id', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await updateServiceInDb(pool, req.params.id, req.body);
      res.status(200).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.delete('/services/:id', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      await softDeleteServiceInDb(pool, req.params.id);
      res.status(200).json({
        ok: true,
        mode: 'real',
        message: 'خدمت به صورت منطقی (Soft Delete) غیرفعال شد.',
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۹. مدیریت متخصصان و پرسنل (/app/staff)
   */
  router.post('/specialists', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await createSpecialistInDb(pool, req.body);
      res.status(201).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.patch('/specialists/:id', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await updateSpecialistInDb(pool, req.params.id, req.body);
      res.status(200).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۱۰. ثبت نوبت جدید و تغییر وضعیت نوبت (/booking/*, /me/appointments, /app/appointments)
   */
  router.post('/appointments', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await createAppointmentInDb(pool, req.body);
      res.status(201).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.patch(
    '/appointments/:id/status',
    async (req: Request, res: Response) => {
      const { pool } = await resolvePoolOrFail(res);
      if (!pool) return;

      try {
        const status = req.body?.status as AppointmentStatus;
        const cancelledReason =
          typeof req.body?.cancelledReason === 'string'
            ? req.body.cancelledReason
            : undefined;
        await updateAppointmentStatusInDb(
          pool,
          req.params.id,
          status,
          cancelledReason
        );
        res.status(200).json({
          ok: true,
          mode: 'real',
          status,
        });
      } catch (err) {
        handleRealModeRouteError(res, err);
      }
    }
  );

  /**
   * ۱۱. گالری نمونه کارها و کمپین‌های بازاریابی (/app/gallery, /app/marketing)
   */
  router.post('/gallery', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await createGalleryItemInDb(pool, req.body);
      res.status(201).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.delete('/gallery/:id', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      await deleteGalleryItemInDb(pool, req.params.id);
      res.status(200).json({
        ok: true,
        mode: 'real',
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.post('/campaigns', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await createCampaignInDb(pool, req.body);
      res.status(201).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۱۲. علاقه‌مندی‌های مشتری (/me/favorites)
   */
  router.post(
    '/customers/favorites/toggle',
    async (req: Request, res: Response) => {
      const { pool } = await resolvePoolOrFail(res);
      if (!pool) return;

      try {
        const businessId = String(req.body?.businessId || '');
        const phone =
          typeof req.body?.phone === 'string' ? req.body.phone : '09123456789';
        const result = await toggleFavoriteBusinessInDb(
          pool,
          businessId,
          phone
        );
        res.status(200).json({
          ok: true,
          mode: 'real',
          ...result,
        });
      } catch (err) {
        handleRealModeRouteError(res, err);
      }
    }
  );

  /**
   * ۱۳. عملیات پنل مدیریت کلان پلتفرم (/admin/*)
   */
  router.patch(
    '/admin/businesses/:id/approval',
    async (req: Request, res: Response) => {
      const { pool } = await resolvePoolOrFail(res);
      if (!pool) return;

      try {
        const status = req.body?.status as ApprovalStatus;
        await updateBusinessApprovalInDb(pool, req.params.id, status);
        res.status(200).json({
          ok: true,
          mode: 'real',
          status,
        });
      } catch (err) {
        handleRealModeRouteError(res, err);
      }
    }
  );

  router.post('/admin/categories', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await createCategoryInDb(pool, req.body);
      res.status(201).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.put('/admin/categories/:id', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const item = await updateCategoryInDb(pool, req.params.id, req.body);
      res.status(200).json({
        ok: true,
        mode: 'real',
        item,
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  /**
   * ۱۴. احراز هویت اتمیک پیامکی (OTP) با کنترل نرخ درخواست در سطح PostgreSQL
   */
  router.post('/auth/otp/request', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const phone = String(req.body?.phone || '');
      const ip = String(req.ip || req.socket.remoteAddress || '127.0.0.1');
      const result = await requestOtpInDb(pool, phone, ip);
      if (!result.allowed) {
        res.status(429).json({
          ok: false,
          mode: 'real',
          errorCode: result.reasonCode,
          retryAfterSec: result.retryAfterSec,
          message: `تعداد درخواست‌های ارسال کد بیش از حد مجاز است. لطفاً ${result.retryAfterSec} ثانیه دیگر تلاش کنید.`,
        });
        return;
      }

      res.status(200).json({
        ok: true,
        mode: 'real',
        challengeId: result.challengeId,
        message: 'کد تایید یک‌بارمصرف صادر شد.',
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  router.post('/auth/otp/verify', async (req: Request, res: Response) => {
    const { pool } = await resolvePoolOrFail(res);
    if (!pool) return;

    try {
      const phone = String(req.body?.phone || '');
      const code = String(req.body?.code || '');
      const ip = String(req.ip || req.socket.remoteAddress || '127.0.0.1');
      const ua = String(req.headers['user-agent'] || 'web');
      const result = await verifyOtpInDb(pool, phone, code, ip, ua);
      if (!result.verified) {
        res.status(401).json({
          ok: false,
          mode: 'real',
          errorCode: result.outcomeCode,
          remainingAttempts: result.remainingAttempts,
          message:
            result.outcomeCode === 'OTP_LOCKED'
              ? 'کد تایید به دلیل تلاش‌های ناموفق متوالی قفل شد. لطفاً کد جدید درخواست کنید.'
              : result.outcomeCode === 'OTP_EXPIRED'
                ? 'مهلت زمانی کد تایید به پایان رسیده است.'
                : 'کد واردشده صحیح نیست.',
        });
        return;
      }

      res.status(200).json({
        ok: true,
        mode: 'real',
        userId: result.userId,
        message: 'احراز هویت با موفقیت انجام شد.',
      });
    } catch (err) {
      handleRealModeRouteError(res, err);
    }
  });

  return router;
}
