import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  SAMPLE_APPOINTMENTS,
  SAMPLE_BUSINESSES,
  SAMPLE_CAMPAIGNS,
  SAMPLE_CATEGORIES,
  SAMPLE_CUSTOMERS,
  SAMPLE_GALLERY,
  SAMPLE_REVIEWS,
  SAMPLE_SERVICES,
  SAMPLE_SPECIALISTS,
  SAMPLE_SUBSCRIPTION_PLANS,
} from '../mocks/sampleData';
import { ApiClientError, realApiClient } from '../services/apiClient';
import {
  AppointmentItem,
  AppointmentStatus,
  ApprovalStatus,
  BookingDraft,
  BusinessItem,
  BusinessType,
  CategoryItem,
  CustomerRecord,
  GalleryItem,
  MarketingCampaignItem,
  OnboardingDraft,
  ReviewItem,
  ServiceItem,
  SpecialistItem,
  SubscriptionPlanItem,
  WorkingHourItem,
} from '../types';

export interface ToastNotice {
  id: number;
  message: string;
  tone: 'success' | 'info' | 'warning' | 'danger';
}

interface PrototypeDataContextValue {
  dataMode: 'mock' | 'real';
  databaseError: string | null;
  isLoadingInitialData: boolean;
  refreshRealData: () => Promise<void>;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  favoriteBusinessIds: string[];
  toggleFavoriteBusiness: (businessId: string) => void;
  businesses: BusinessItem[];
  updateBusinessProfile: (
    businessId: string,
    patch: Partial<BusinessItem>
  ) => void;
  updateBusinessWorkingHours: (
    businessId: string,
    hours: WorkingHourItem[]
  ) => void;
  updateBusinessApproval: (businessId: string, status: ApprovalStatus) => void;
  services: ServiceItem[];
  addService: (item: Omit<ServiceItem, 'id'>) => void;
  updateService: (id: string, patch: Partial<ServiceItem>) => void;
  deleteService: (id: string) => void;
  specialists: SpecialistItem[];
  addSpecialist: (item: Omit<SpecialistItem, 'id'>) => void;
  updateSpecialist: (id: string, patch: Partial<SpecialistItem>) => void;
  appointments: AppointmentItem[];
  updateAppointmentStatus: (id: string, status: AppointmentStatus) => void;
  categories: CategoryItem[];
  addCategory: (item: Omit<CategoryItem, 'id'>) => void;
  updateCategory: (id: string, patch: Partial<CategoryItem>) => void;
  gallery: GalleryItem[];
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => void;
  removeGalleryItem: (id: string) => void;
  campaigns: MarketingCampaignItem[];
  addCampaign: (item: Omit<MarketingCampaignItem, 'id'>) => void;
  customers: CustomerRecord[];
  reviews: ReviewItem[];
  plans: SubscriptionPlanItem[];
  activePlanId: string;
  setActivePlanId: (planId: string) => void;
  onboardingDraft: OnboardingDraft;
  updateOnboardingDraft: (patch: Partial<OnboardingDraft>) => void;
  submitBusinessOnboarding: () => Promise<boolean>;
  bookingDraft: BookingDraft;
  updateBookingDraft: (patch: Partial<BookingDraft>) => void;
  completeSimulatedBooking: () => AppointmentItem;
  toast: ToastNotice | null;
  showToast: (
    message: string,
    tone?: 'success' | 'info' | 'warning' | 'danger'
  ) => void;
  dismissToast: () => void;
}

const INITIAL_ONBOARDING_DRAFT: OnboardingDraft = {
  businessType: BusinessType.WomenSalon,
  businessName: 'سالن زیبایی ارکیده نقره‌ای (نمونه)',
  categorySlug: 'hair-color',
  slug: 'orkideh-salon',
  ownerName: 'مریم فرهادی',
  phone: '09123456789',
  instagramHandle: '@orkideh.beauty',
  city: 'تهران',
  neighborhood: 'ولنجک',
  address: 'تهران، ولنجک، خیابان سیزدهم، پلاک ۲۴، طبقه دوم (آدرس آزمایشی)',
  mapLat: 35.8058,
  mapLng: 51.4018,
  shortDescription:
    'مرکز تخصصی رنگ و مش، احیای مو و طراحی ناخن با کادر مجرب و نوبت‌دهی آنلاین.',
  services: [
    {
      id: 'onb-srv-1',
      title: 'کوتاهی ژورنالی و براشینگ',
      category: 'مو و رنگ',
      durationMinutes: 60,
      priceToman: 580000,
    },
    {
      id: 'onb-srv-2',
      title: 'مانیکور روسی و ژلیش ناخن',
      category: 'ناخن',
      durationMinutes: 60,
      priceToman: 420000,
    },
  ],
  staff: [
    {
      id: 'onb-stf-1',
      fullName: 'مریم فرهادی',
      roleTitle: 'مدیر و متخصص ارشد مو',
    },
    {
      id: 'onb-stf-2',
      fullName: 'سحر کاظمی',
      roleTitle: 'متخصص طراحی و سلامت ناخن',
    },
  ],
  workingHours: [
    { dayName: 'شنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'یکشنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'دوشنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'سه‌شنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'چهارشنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'پنج‌شنبه', isOpen: true, openTime: '۱۰:۰۰', closeTime: '۱۸:۰۰' },
    { dayName: 'جمعه', isOpen: false, openTime: '۱۰:۰۰', closeTime: '۱۶:۰۰' },
  ],
  licenseCode: 'SNF-1405-88412',
  nationalIdNumber: '0012345678',
};

const INITIAL_BOOKING_DRAFT: BookingDraft = {
  businessSlug: 'royal-golzar',
  serviceId: 'srv-101',
  specialistId: 'spc-1',
  dateJalali: '۱۴۰۵/۰۸/۰۵',
  timeSlot: '۱۱:۰۰',
  customerName: 'المیرا شمس',
  customerPhone: '09123456789',
  customerNotes: '',
  lastReferenceCode: 'BH-403990',
};

const PrototypeDataContext = createContext<PrototypeDataContextValue | null>(
  null
);

export const PrototypeDataProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [dataMode, setDataMode] = useState<'mock' | 'real'>('mock');
  const [databaseError, setDatabaseError] = useState<string | null>(null);
  const [isLoadingInitialData, setIsLoadingInitialData] =
    useState<boolean>(false);

  const [selectedCity, setSelectedCity] = useState<string>('ALL');
  const [favoriteBusinessIds, setFavoriteBusinessIds] = useState<string[]>([
    'biz-1',
    'biz-3',
  ]);
  const [businesses, setBusinesses] =
    useState<BusinessItem[]>(SAMPLE_BUSINESSES);
  const [services, setServices] = useState<ServiceItem[]>(SAMPLE_SERVICES);
  const [specialists, setSpecialists] =
    useState<SpecialistItem[]>(SAMPLE_SPECIALISTS);
  const [appointments, setAppointments] =
    useState<AppointmentItem[]>(SAMPLE_APPOINTMENTS);
  const [categories, setCategories] =
    useState<CategoryItem[]>(SAMPLE_CATEGORIES);
  const [gallery, setGallery] = useState<GalleryItem[]>(SAMPLE_GALLERY);
  const [campaigns, setCampaigns] =
    useState<MarketingCampaignItem[]>(SAMPLE_CAMPAIGNS);
  const [customers, setCustomers] =
    useState<CustomerRecord[]>(SAMPLE_CUSTOMERS);
  const [reviews, setReviews] = useState<ReviewItem[]>(SAMPLE_REVIEWS);
  const [plans, setPlans] = useState<SubscriptionPlanItem[]>(
    SAMPLE_SUBSCRIPTION_PLANS
  );
  const [activePlanId, setActivePlanId] = useState<string>('plan-professional');
  const [onboardingDraft, setOnboardingDraft] = useState<OnboardingDraft>(
    INITIAL_ONBOARDING_DRAFT
  );
  const [bookingDraft, setBookingDraft] = useState<BookingDraft>(
    INITIAL_BOOKING_DRAFT
  );
  const [toast, setToast] = useState<ToastNotice | null>(null);

  const showToast = (
    message: string,
    tone: 'success' | 'info' | 'warning' | 'danger' = 'success'
  ) => {
    setToast({ id: Date.now(), message, tone });
  };

  const dismissToast = () => setToast(null);

  const refreshRealData = async () => {
    setIsLoadingInitialData(true);
    try {
      const response = await realApiClient.fetchBootstrap();
      if (response.mode === 'real' && response.data) {
        setDataMode('real');
        setDatabaseError(null);
        setCategories(response.data.categories);
        setBusinesses(response.data.businesses);
        setServices(response.data.services);
        setSpecialists(response.data.specialists);
        setAppointments(response.data.appointments);
        setCustomers(response.data.customers);
        setReviews(response.data.reviews);
        setGallery(response.data.gallery);
        setCampaigns(response.data.campaigns);
        if (response.data.plans.length > 0) {
          setPlans(response.data.plans);
        }
        setFavoriteBusinessIds(response.data.favoriteBusinessIds);
      } else {
        setDataMode('mock');
        setDatabaseError(null);
      }
    } catch (err) {
      if (
        err instanceof ApiClientError &&
        (err.mode === 'real' || err.status === 503 || err.status === 500)
      ) {
        // عدم بازگشت خاموش به داده‌های آزمایشی در صورتی که سرور روی حالت دیتابیس واقعی تنظیم شده باشد
        setDataMode('real');
        setDatabaseError(err.message);
        setBusinesses([]);
        setServices([]);
        setSpecialists([]);
        setAppointments([]);
        setCustomers([]);
        setReviews([]);
        setGallery([]);
        setCampaigns([]);
        setFavoriteBusinessIds([]);
        showToast(err.message, 'danger');
      }
    } finally {
      setIsLoadingInitialData(false);
    }
  };

  useEffect(() => {
    void refreshRealData();
  }, []);

  const toggleFavoriteBusiness = (businessId: string) => {
    if (dataMode === 'real') {
      void realApiClient
        .toggleFavoriteBusiness(businessId, bookingDraft.customerPhone)
        .then((res) => {
          setFavoriteBusinessIds(res.favoriteBusinessIds);
          showToast(
            res.favorited
              ? 'به فهرست سالن‌های منتخب شما در دیتابیس اضافه شد.'
              : 'از فهرست سالن‌های منتخب شما در دیتابیس حذف شد.',
            'info'
          );
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ثبت علاقه‌مندی در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setFavoriteBusinessIds((prev) => {
      const exists = prev.includes(businessId);
      const next = exists
        ? prev.filter((id) => id !== businessId)
        : [...prev, businessId];
      showToast(
        exists
          ? 'از فهرست سالن‌های منتخب شما حذف شد.'
          : 'به فهرست سالن‌های منتخب شما اضافه شد.',
        'info'
      );
      return next;
    });
  };

  const updateBusinessProfile = (
    businessId: string,
    patch: Partial<BusinessItem>
  ) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateBusinessProfile(businessId, patch)
        .then(() => {
          setBusinesses((prev) =>
            prev.map((b) => (b.id === businessId ? { ...b, ...patch } : b))
          );
          showToast('اطلاعات پروفایل کسب‌وکار در پایگاه داده ذخیره شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در بروزرسانی پروفایل کسب‌وکار در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setBusinesses((prev) =>
      prev.map((b) => (b.id === businessId ? { ...b, ...patch } : b))
    );
    showToast('اطلاعات پروفایل کسب‌وکار بروزرسانی شد.');
  };

  const updateBusinessWorkingHours = (
    businessId: string,
    hours: WorkingHourItem[]
  ) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateBusinessWorkingHours(businessId, hours)
        .then((res) => {
          setBusinesses((prev) =>
            prev.map((b) =>
              b.id === businessId
                ? { ...b, workingHours: res.workingHours }
                : b
            )
          );
          showToast('ساعات کاری هفتگی در پایگاه داده ذخیره شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ذخیره ساعات کاری در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === businessId ? { ...b, workingHours: hours } : b
      )
    );
    showToast('ساعات کاری هفتگی ذخیره شد.');
  };

  const updateBusinessApproval = (
    businessId: string,
    status: ApprovalStatus
  ) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateBusinessApproval(businessId, status)
        .then(() => {
          setBusinesses((prev) =>
            prev.map((b) =>
              b.id === businessId
                ? {
                    ...b,
                    approvalStatus: status,
                    verifiedBadge: status === 'APPROVED',
                  }
                : b
            )
          );
          showToast(
            status === 'APPROVED'
              ? 'وضعیت کسب‌وکار در دیتابیس به «تاییدشده» تغییر یافت.'
              : 'وضعیت کسب‌وکار در دیتابیس به «ردشده» تغییر یافت.',
            status === 'APPROVED' ? 'success' : 'warning'
          );
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در تغییر وضعیت تایید کسب‌وکار در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === businessId
          ? {
              ...b,
              approvalStatus: status,
              verifiedBadge: status === 'APPROVED',
            }
          : b
      )
    );
    showToast(
      status === 'APPROVED'
        ? 'وضعیت کسب‌وکار به «تاییدشده» تغییر یافت.'
        : 'وضعیت کسب‌وکار به «ردشده / نیازمند اصلاح» تغییر یافت.',
      status === 'APPROVED' ? 'success' : 'warning'
    );
  };

  const addService = (item: Omit<ServiceItem, 'id'>) => {
    if (dataMode === 'real') {
      void realApiClient
        .createService(item)
        .then((res) => {
          setServices((prev) => [res.item, ...prev]);
          showToast(`خدمت «${res.item.title}» در پایگاه داده ثبت شد.`);
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error ? err.message : 'خطا در ثبت خدمت در دیتابیس',
            'danger'
          );
        });
      return;
    }

    const newItem: ServiceItem = {
      ...item,
      id: `srv-${Date.now()}`,
    };
    setServices((prev) => [newItem, ...prev]);
    showToast(`خدمت «${item.title}» به فهرست اضافه شد.`);
  };

  const updateService = (id: string, patch: Partial<ServiceItem>) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateService(id, patch)
        .then((res) => {
          setServices((prev) =>
            prev.map((s) => (s.id === id ? res.item : s))
          );
          showToast('ویرایش خدمت در پایگاه داده ذخیره شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ویرایش خدمت در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setServices((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...patch } : s))
    );
    showToast('ویرایش خدمت ذخیره شد.');
  };

  const deleteService = (id: string) => {
    if (dataMode === 'real') {
      void realApiClient
        .deleteService(id)
        .then(() => {
          setServices((prev) => prev.filter((s) => s.id !== id));
          showToast('خدمت انتخاب‌شده در پایگاه داده غیرفعال شد.', 'warning');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error ? err.message : 'خطا در حذف خدمت از دیتابیس',
            'danger'
          );
        });
      return;
    }

    setServices((prev) => prev.filter((s) => s.id !== id));
    showToast('خدمت انتخاب‌شده از فهرست حذف شد.', 'warning');
  };

  const addSpecialist = (item: Omit<SpecialistItem, 'id'>) => {
    if (dataMode === 'real') {
      void realApiClient
        .createSpecialist(item)
        .then((res) => {
          setSpecialists((prev) => [res.item, ...prev]);
          showToast(`متخصص «${res.item.fullName}» در پایگاه داده ثبت شد.`);
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ثبت متخصص در دیتابیس',
            'danger'
          );
        });
      return;
    }

    const newItem: SpecialistItem = {
      ...item,
      id: `spc-${Date.now()}`,
    };
    setSpecialists((prev) => [newItem, ...prev]);
    showToast(`متخصص «${item.fullName}» به تیم اضافه شد.`);
  };

  const updateSpecialist = (id: string, patch: Partial<SpecialistItem>) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateSpecialist(id, patch)
        .then((res) => {
          setSpecialists((prev) =>
            prev.map((sp) => (sp.id === id ? res.item : sp))
          );
          showToast('اطلاعات متخصص در پایگاه داده بروزرسانی شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در بروزرسانی متخصص در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setSpecialists((prev) =>
      prev.map((sp) => (sp.id === id ? { ...sp, ...patch } : sp))
    );
    showToast('اطلاعات متخصص بروزرسانی شد.');
  };

  const updateAppointmentStatus = (id: string, status: AppointmentStatus) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateAppointmentStatus(id, status)
        .then(() => {
          setAppointments((prev) =>
            prev.map((a) => (a.id === id ? { ...a, status } : a))
          );
          showToast('وضعیت نوبت در پایگاه داده بروزرسانی شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در تغییر وضعیت نوبت در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status } : a))
    );
    showToast('وضعیت نوبت بروزرسانی شد.');
  };

  const addCategory = (item: Omit<CategoryItem, 'id'>) => {
    if (dataMode === 'real') {
      void realApiClient
        .createCategory(item)
        .then((res) => {
          setCategories((prev) => [res.item, ...prev]);
          showToast(`دسته‌بندی «${res.item.title}» در پایگاه داده ثبت شد.`);
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ثبت دسته‌بندی در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setCategories((prev) => [{ ...item, id: `cat-${Date.now()}` }, ...prev]);
    showToast(`دسته‌بندی «${item.title}» به فهرست اضافه شد.`);
  };

  const updateCategory = (id: string, patch: Partial<CategoryItem>) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateCategory(id, patch)
        .then((res) => {
          setCategories((prev) =>
            prev.map((c) => (c.id === id ? res.item : c))
          );
          showToast('دسته‌بندی در پایگاه داده ویرایش شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ویرایش دسته‌بندی در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...patch } : c))
    );
    showToast('دسته‌بندی ویرایش شد.');
  };

  const addGalleryItem = (item: Omit<GalleryItem, 'id'>) => {
    if (dataMode === 'real') {
      void realApiClient
        .createGalleryItem(item)
        .then((res) => {
          setGallery((prev) => [res.item, ...prev]);
          showToast('آیتم جدید در گالری پایگاه داده ثبت شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ثبت آیتم گالری در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setGallery((prev) => [{ ...item, id: `gal-${Date.now()}` }, ...prev]);
    showToast('آیتم جدید به گالری سالن اضافه شد.');
  };

  const removeGalleryItem = (id: string) => {
    if (dataMode === 'real') {
      void realApiClient
        .deleteGalleryItem(id)
        .then(() => {
          setGallery((prev) => prev.filter((g) => g.id !== id));
          showToast('تصویر نمونه از گالری پایگاه داده حذف شد.', 'info');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در حذف تصویر از دیتابیس',
            'danger'
          );
        });
      return;
    }

    setGallery((prev) => prev.filter((g) => g.id !== id));
    showToast('تصویر نمونه از گالری حذف شد.', 'info');
  };

  const addCampaign = (item: Omit<MarketingCampaignItem, 'id'>) => {
    if (dataMode === 'real') {
      void realApiClient
        .createCampaign(item)
        .then((res) => {
          setCampaigns((prev) => [res.item, ...prev]);
          showToast('کمپین تبلیغاتی در پایگاه داده ثبت شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ثبت کمپین در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setCampaigns((prev) => [{ ...item, id: `cmp-${Date.now()}` }, ...prev]);
    showToast('کمپین تبلیغاتی ایجاد شد.');
  };

  const updateOnboardingDraft = (patch: Partial<OnboardingDraft>) => {
    setOnboardingDraft((prev) => ({ ...prev, ...patch }));
  };

  const submitBusinessOnboarding = async (): Promise<boolean> => {
    if (dataMode === 'real') {
      try {
        const res = await realApiClient.onboardBusiness(onboardingDraft);
        setCategories(res.data.categories);
        setBusinesses(res.data.businesses);
        setServices(res.data.services);
        setSpecialists(res.data.specialists);
        showToast(
          `کسب‌وکار «${onboardingDraft.businessName}» با موفقیت در پایگاه داده ثبت شد.`
        );
        return true;
      } catch (err) {
        showToast(
          err instanceof Error
            ? err.message
            : 'خطا در ثبت کسب‌وکار جدید در دیتابیس',
          'danger'
        );
        return false;
      }
    }

    showToast(`راه‌اندازی «${onboardingDraft.businessName}» تکمیل شد.`);
    return true;
  };

  const updateBookingDraft = (patch: Partial<BookingDraft>) => {
    setBookingDraft((prev) => ({ ...prev, ...patch }));
  };

  const completeSimulatedBooking = (): AppointmentItem => {
    const biz =
      businesses.find((b) => b.slug === bookingDraft.businessSlug) ??
      businesses[0];
    const srv =
      services.find((s) => s.id === bookingDraft.serviceId) ?? services[0];
    const spc =
      specialists.find((sp) => sp.id === bookingDraft.specialistId) ??
      specialists[0];
    const refCode = `BH-${Math.floor(404000 + Math.random() * 9000)}`;

    const optimisticApt: AppointmentItem = {
      id: `apt-${Date.now()}`,
      referenceCode: refCode,
      businessId: biz?.id ?? 'biz-1',
      businessSlug: biz?.slug ?? bookingDraft.businessSlug,
      businessName: biz?.name ?? 'سالن زیبایی',
      customerName: bookingDraft.customerName || 'المیرا شمس',
      customerPhoneMasked: bookingDraft.customerPhone || '۰۹۱۲***۴۵۸۱',
      serviceId: srv?.id ?? bookingDraft.serviceId,
      serviceTitle: srv?.title ?? 'خدمت زیبایی',
      specialistId: spc?.id ?? bookingDraft.specialistId,
      specialistName: spc?.fullName ?? 'متخصص سالن',
      dateJalali: bookingDraft.dateJalali,
      timeSlot: bookingDraft.timeSlot,
      durationMinutes: srv?.durationMinutes ?? 60,
      priceToman: srv?.priceToman ?? 450000,
      status: AppointmentStatus.Confirmed,
      notes: bookingDraft.customerNotes || undefined,
    };

    if (dataMode === 'real') {
      void realApiClient
        .createAppointment({
          businessSlug: bookingDraft.businessSlug,
          serviceId: bookingDraft.serviceId,
          specialistId: bookingDraft.specialistId,
          dateJalali: bookingDraft.dateJalali,
          timeSlot: bookingDraft.timeSlot,
          customerName: bookingDraft.customerName,
          customerPhone: bookingDraft.customerPhone,
          customerNotes: bookingDraft.customerNotes,
        })
        .then((res) => {
          setAppointments((prev) => [res.item, ...prev]);
          setBookingDraft((prev) => ({
            ...prev,
            lastReferenceCode: res.item.referenceCode,
          }));
          showToast(
            `نوبت شما با کد رهگیری ${res.item.referenceCode} در پایگاه داده ثبت شد.`
          );
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ثبت نوبت در دیتابیس PostgreSQL',
            'danger'
          );
        });
      return optimisticApt;
    }

    setAppointments((prev) => [optimisticApt, ...prev]);
    setBookingDraft((prev) => ({ ...prev, lastReferenceCode: refCode }));
    showToast(`نوبت با کد ${refCode} در لیست نوبت‌های من ثبت شد.`);
    return optimisticApt;
  };

  return (
    <PrototypeDataContext.Provider
      value={{
        dataMode,
        databaseError,
        isLoadingInitialData,
        refreshRealData,
        selectedCity,
        setSelectedCity,
        favoriteBusinessIds,
        toggleFavoriteBusiness,
        businesses,
        updateBusinessProfile,
        updateBusinessWorkingHours,
        updateBusinessApproval,
        services,
        addService,
        updateService,
        deleteService,
        specialists,
        addSpecialist,
        updateSpecialist,
        appointments,
        updateAppointmentStatus,
        categories,
        addCategory,
        updateCategory,
        gallery,
        addGalleryItem,
        removeGalleryItem,
        campaigns,
        addCampaign,
        customers,
        reviews,
        plans,
        activePlanId,
        setActivePlanId,
        onboardingDraft,
        updateOnboardingDraft,
        submitBusinessOnboarding,
        bookingDraft,
        updateBookingDraft,
        completeSimulatedBooking,
        toast,
        showToast,
        dismissToast,
      }}
    >
      {children}
    </PrototypeDataContext.Provider>
  );
};

export function usePrototypeData(): PrototypeDataContextValue {
  const ctx = useContext(PrototypeDataContext);
  if (!ctx) {
    throw new Error(
      'usePrototypeData must be used inside a PrototypeDataProvider'
    );
  }
  return ctx;
}
