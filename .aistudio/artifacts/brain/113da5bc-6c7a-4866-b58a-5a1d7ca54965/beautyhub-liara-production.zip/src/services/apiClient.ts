import {
  SAMPLE_APPOINTMENTS,
  SAMPLE_BUSINESSES,
  SAMPLE_CATEGORIES,
  SAMPLE_SERVICES,
  SAMPLE_SPECIALISTS,
  SAMPLE_SUBSCRIPTION_PLANS,
} from '../mocks/sampleData';
import {
  AppointmentItem,
  AppointmentStatus,
  ApprovalStatus,
  BusinessItem,
  CategoryItem,
  CustomerRecord,
  GalleryItem,
  MarketingCampaignItem,
  OnboardingDraft,
  ReviewItem,
  ServiceItem,
  SpecialistItem,
  SubscriptionPlanItem,
  WorkingHourItem,
} from '../types';

export interface ApiBootstrapResponse {
  ok: boolean;
  mode: 'mock' | 'real';
  errorCode?: string;
  message?: string;
  data: {
    categories: CategoryItem[];
    businesses: BusinessItem[];
    services: ServiceItem[];
    specialists: SpecialistItem[];
    appointments: AppointmentItem[];
    customers: CustomerRecord[];
    reviews: ReviewItem[];
    gallery: GalleryItem[];
    campaigns: MarketingCampaignItem[];
    plans: SubscriptionPlanItem[];
    favoriteBusinessIds: string[];
  } | null;
}

export class ApiClientError extends Error {
  status: number;
  errorCode: string;
  mode?: 'mock' | 'real';

  constructor(
    message: string,
    status: number,
    errorCode = 'API_ERROR',
    mode?: 'mock' | 'real'
  ) {
    super(message);
    this.name = 'ApiClientError';
    this.status = status;
    this.errorCode = errorCode;
    this.mode = mode;
  }
}

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok || body?.ok === false) {
    throw new ApiClientError(
      body?.message || 'خطا در برقراری ارتباط با سرور',
      response.status,
      body?.errorCode || 'HTTP_ERROR',
      body?.mode
    );
  }
  return body as T;
}

/**
 * کلاینت واقعی متصل به بک‌اند Express و دیتابیس PostgreSQL (/api/v1/*)
 * در حالت real هیچ‌گاه به صورت خاموش به داده‌های آزمایشی برنمی‌گردد.
 */
export const realApiClient = {
  async fetchBootstrap(): Promise<ApiBootstrapResponse> {
    const res = await fetch('/api/v1/bootstrap', {
      headers: { Accept: 'application/json' },
    });
    const body = (await res.json().catch(() => ({}))) as ApiBootstrapResponse;
    if (!res.ok || body.ok === false) {
      throw new ApiClientError(
        body.message || 'خطا در دریافت اطلاعات از دیتابیس PostgreSQL.',
        res.status,
        body.errorCode || 'BOOTSTRAP_FAILED',
        body.mode || 'real'
      );
    }
    return body;
  },

  async createService(
    item: Omit<ServiceItem, 'id'>
  ): Promise<{ item: ServiceItem }> {
    return requestJson<{ ok: boolean; item: ServiceItem }>('/api/v1/services', {
      method: 'POST',
      body: JSON.stringify(item),
    });
  },

  async updateService(
    id: string,
    patch: Partial<ServiceItem>
  ): Promise<{ item: ServiceItem }> {
    return requestJson<{ ok: boolean; item: ServiceItem }>(
      `/api/v1/services/${encodeURIComponent(id)}`,
      {
        method: 'PUT',
        body: JSON.stringify(patch),
      }
    );
  },

  async deleteService(id: string): Promise<void> {
    await requestJson(`/api/v1/services/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
  },

  async createSpecialist(
    item: Omit<SpecialistItem, 'id'>
  ): Promise<{ item: SpecialistItem }> {
    return requestJson<{ ok: boolean; item: SpecialistItem }>(
      '/api/v1/specialists',
      {
        method: 'POST',
        body: JSON.stringify(item),
      }
    );
  },

  async updateSpecialist(
    id: string,
    patch: Partial<SpecialistItem>
  ): Promise<{ item: SpecialistItem }> {
    return requestJson<{ ok: boolean; item: SpecialistItem }>(
      `/api/v1/specialists/${encodeURIComponent(id)}`,
      {
        method: 'PATCH',
        body: JSON.stringify(patch),
      }
    );
  },

  async updateBusinessProfile(
    businessId: string,
    patch: Partial<BusinessItem>
  ): Promise<void> {
    await requestJson(
      `/api/v1/businesses/${encodeURIComponent(businessId)}/profile`,
      {
        method: 'PUT',
        body: JSON.stringify(patch),
      }
    );
  },

  async updateBusinessWorkingHours(
    businessId: string,
    workingHours: WorkingHourItem[]
  ): Promise<{ workingHours: WorkingHourItem[] }> {
    return requestJson<{ ok: boolean; workingHours: WorkingHourItem[] }>(
      `/api/v1/businesses/${encodeURIComponent(businessId)}/working-hours`,
      {
        method: 'PUT',
        body: JSON.stringify({ workingHours }),
      }
    );
  },

  async updateBusinessApproval(
    businessId: string,
    status: ApprovalStatus
  ): Promise<void> {
    await requestJson(
      `/api/v1/admin/businesses/${encodeURIComponent(businessId)}/approval`,
      {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }
    );
  },

  async createAppointment(input: {
    businessSlug: string;
    serviceId: string;
    specialistId: string;
    dateJalali: string;
    timeSlot: string;
    customerName: string;
    customerPhone: string;
    customerNotes?: string;
  }): Promise<{ item: AppointmentItem }> {
    return requestJson<{ ok: boolean; item: AppointmentItem }>(
      '/api/v1/appointments',
      {
        method: 'POST',
        body: JSON.stringify(input),
      }
    );
  },

  async updateAppointmentStatus(
    id: string,
    status: AppointmentStatus,
    cancelledReason?: string
  ): Promise<void> {
    await requestJson(`/api/v1/appointments/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, cancelledReason }),
    });
  },

  async createCategory(
    item: Omit<CategoryItem, 'id'>
  ): Promise<{ item: CategoryItem }> {
    return requestJson<{ ok: boolean; item: CategoryItem }>(
      '/api/v1/admin/categories',
      {
        method: 'POST',
        body: JSON.stringify(item),
      }
    );
  },

  async updateCategory(
    id: string,
    patch: Partial<CategoryItem>
  ): Promise<{ item: CategoryItem }> {
    return requestJson<{ ok: boolean; item: CategoryItem }>(
      `/api/v1/admin/categories/${encodeURIComponent(id)}`,
      {
        method: 'PUT',
        body: JSON.stringify(patch),
      }
    );
  },

  async createGalleryItem(
    item: Omit<GalleryItem, 'id'>
  ): Promise<{ item: GalleryItem }> {
    return requestJson<{ ok: boolean; item: GalleryItem }>('/api/v1/gallery', {
      method: 'POST',
      body: JSON.stringify(item),
    });
  },

  async deleteGalleryItem(id: string): Promise<void> {
    await requestJson(`/api/v1/gallery/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
  },

  async createCampaign(
    item: Omit<MarketingCampaignItem, 'id'>
  ): Promise<{ item: MarketingCampaignItem }> {
    return requestJson<{ ok: boolean; item: MarketingCampaignItem }>(
      '/api/v1/campaigns',
      {
        method: 'POST',
        body: JSON.stringify(item),
      }
    );
  },

  async toggleFavoriteBusiness(
    businessId: string,
    phone?: string
  ): Promise<{ favorited: boolean; favoriteBusinessIds: string[] }> {
    return requestJson<{
      ok: boolean;
      favorited: boolean;
      favoriteBusinessIds: string[];
    }>('/api/v1/customers/favorites/toggle', {
      method: 'POST',
      body: JSON.stringify({ businessId, phone }),
    });
  },

  async onboardBusiness(
    draft: OnboardingDraft
  ): Promise<{
    businessId: string;
    slug: string;
    data: NonNullable<ApiBootstrapResponse['data']>;
  }> {
    return requestJson('/api/v1/businesses/onboard', {
      method: 'POST',
      body: JSON.stringify(draft),
    });
  },
};

export interface BeautyHubDataService {
  getBusinesses(): Promise<BusinessItem[]>;
  getBusinessBySlug(slug: string): Promise<BusinessItem | undefined>;
  getServicesByBusinessId(businessId: string): Promise<ServiceItem[]>;
  getSpecialistsByBusinessId(businessId: string): Promise<SpecialistItem[]>;
  getSpecialistBySlug(slug: string): Promise<SpecialistItem | undefined>;
  getAppointments(): Promise<AppointmentItem[]>;
  getCategories(): Promise<CategoryItem[]>;
  getSubscriptionPlans(): Promise<SubscriptionPlanItem[]>;
}

export const mockDataService: BeautyHubDataService = {
  async getBusinesses() {
    return SAMPLE_BUSINESSES;
  },
  async getBusinessBySlug(slug: string) {
    return SAMPLE_BUSINESSES.find((b) => b.slug === slug);
  },
  async getServicesByBusinessId(businessId: string) {
    return SAMPLE_SERVICES.filter((s) => s.businessId === businessId);
  },
  async getSpecialistsByBusinessId(businessId: string) {
    return SAMPLE_SPECIALISTS.filter((sp) => sp.businessId === businessId);
  },
  async getSpecialistBySlug(slug: string) {
    return SAMPLE_SPECIALISTS.find((sp) => sp.slug === slug);
  },
  async getAppointments() {
    return SAMPLE_APPOINTMENTS;
  },
  async getCategories() {
    return SAMPLE_CATEGORIES;
  },
  async getSubscriptionPlans() {
    return SAMPLE_SUBSCRIPTION_PLANS;
  },
};
