import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Check,
  Clock,
  CreditCard,
  Lock,
  MapPin,
  Scissors,
  Sparkles,
  Users,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import {
  BusinessItem,
  GalleryItem,
  ServiceItem,
  SpecialistItem,
  SubscriptionPlanItem,
} from '../../types';
import { toPersianDigits } from '../../utils/formatters';

export interface ProfileCompletionStep {
  id:
    | 'basic_location'
    | 'services'
    | 'working_hours'
    | 'specialists'
    | 'financial_info'
    | 'media_bio';
  stepNumber: number;
  routePath: string;
  title: string;
  shortLabel: string;
  weightPercent: number;
  completed: boolean;
  href: string;
  statusHint: string;
}

export interface BusinessProfileCompletionSummary {
  totalPercent: number;
  completedStepsCount: number;
  totalStepsCount: number;
  isReadyForPublicShowcase: boolean;
  contractAccepted: boolean;
  hasBankInfo: boolean;
  planName: string;
  planStaffLimitCount: number;
  recommendedServicesMin: number;
  activeServicesCount: number;
  activeSpecialistsCount: number;
  openDaysCount: number;
  steps: ProfileCompletionStep[];
  incompleteSteps: ProfileCompletionStep[];
  nextIncompleteStep: ProfileCompletionStep | null;
}

/** مسیرهایی که در حین ویزارد ۵ مرحله‌ای باز هستند تا کسب‌وکار مراحل را بدون سردرگمی تکمیل کند */
export const ONBOARDING_SETUP_ALLOWED_PATHS = [
  '/app',
  '/app/profile',
  '/app/services',
  '/app/working-hours',
  '/app/staff',
  '/app/subscription',
  '/app/settings',
];

export function isBusinessOnboardingRouteAllowed(pathname: string): boolean {
  return ONBOARDING_SETUP_ALLOWED_PATHS.includes(pathname);
}

export function computeBusinessProfileCompletion(params: {
  business: BusinessItem | null | undefined;
  services: ServiceItem[];
  specialists: SpecialistItem[];
  gallery?: GalleryItem[];
  plans?: SubscriptionPlanItem[];
}): BusinessProfileCompletionSummary {
  const { business, services, specialists, plans = [] } = params;

  const planName = business?.subscriptionPlan || 'پلن جامع و رایگان (کارمزدی)';
  const matchedPlan = plans.find((p) => p.name === planName);

  const isVipPlan =
    planName.includes('ویژه') ||
    planName.toLowerCase().includes('vip') ||
    matchedPlan?.id.includes('vip');
  const isProPlan =
    !isVipPlan &&
    (planName.includes('حرفه‌ای') ||
      planName.includes('حرفه ای') ||
      matchedPlan?.id.includes('pro'));

  const planStaffLimitCount = isVipPlan ? 15 : isProPlan ? 8 : 10;
  const recommendedServicesMin = 1;

  if (!business) {
    return {
      totalPercent: 0,
      completedStepsCount: 0,
      totalStepsCount: 5,
      isReadyForPublicShowcase: false,
      contractAccepted: false,
      hasBankInfo: false,
      planName,
      planStaffLimitCount,
      recommendedServicesMin,
      activeServicesCount: 0,
      activeSpecialistsCount: 0,
      openDaysCount: 0,
      steps: [],
      incompleteSteps: [],
      nextIncompleteStep: null,
    };
  }

  const bizServices = services.filter(
    (s) =>
      (s.businessId === business.id || s.businessId === business.slug) &&
      s.isActive !== false
  );
  const bizSpecialists = specialists.filter(
    (sp) =>
      (sp.businessId === business.id || sp.businessId === business.slug) &&
      sp.isActive !== false
  );
  const openDays = (business.workingHours || []).filter((h) => h.isOpen);

  // ۱. مشخصات پایه، آدرس، بیوگرافی کوتاه و لوکیشن نقشه (۲۰٪ - الزامی)
  const hasBasicAndLocation = Boolean(
    business.name?.trim() &&
      business.address?.trim() &&
      business.address.trim().length >= 4 &&
      Boolean(business.mapLat) &&
      Boolean(business.mapLng)
  );

  // ۲. تعریف خدمات قابل رزرو و تعرفه‌ها (۲۵٪ - الزامی)
  const hasServices = bizServices.length >= 1;

  // ۳. تنظیم دقیق روزها و ساعات کاری هفتگی (۲۰٪ - الزامی)
  const hasWorkingHours =
    openDays.length > 0 && Boolean(business.workingHoursConfigured);

  // ۴. معرفی متخصص سالن (۱۵٪ - الزامی)
  const hasSpecialists = bizSpecialists.length >= 1;

  // ۵. اطلاعات مالی (شماره کارت/شبا) + مطالعه و تیک تایید مفاد قرارداد همکاری (۲۰٪ - الزامی)
  const cleanCard = (business.bankCardNumber || '').replace(/\D/g, '');
  const cleanSheba = (business.bankShebaNumber || '')
    .replace(/^IR/i, '')
    .replace(/\D/g, '');
  const hasBankInfo = cleanCard.length >= 16 || cleanSheba.length >= 24;
  const contractAccepted = Boolean(business.contractAccepted);
  const hasFinancialInfo = hasBankInfo && contractAccepted;

  const steps: ProfileCompletionStep[] = [
    {
      id: 'basic_location',
      stepNumber: 1,
      routePath: '/app/profile',
      title: 'گام ۱: مشخصات سالن، عکس پروفایل و نشانی دقیق',
      shortLabel: '۱. مشخصات و نشانی',
      weightPercent: 20,
      completed: hasBasicAndLocation,
      href: '/app/profile?setup=1',
      statusHint:
        'انتخاب عکس پروفایل و بنر، نام کسب‌وکار، معرفی کوتاه و ثبت آدرس دقیق',
    },
    {
      id: 'services',
      stepNumber: 2,
      routePath: '/app/services',
      title: 'گام ۲: تعریف خدمات و تعرفه‌ها (حداقل ۱ خدمت فعال)',
      shortLabel: '۲. خدمات و تعرفه‌ها',
      weightPercent: 25,
      completed: hasServices,
      href: '/app/services?setup=1',
      statusHint:
        'تعریف حداقل یک خدمت یا پکیج فعال با قیمت و زمان انجام جهت رزرو آنلاین',
    },
    {
      id: 'working_hours',
      stepNumber: 3,
      routePath: '/app/working-hours',
      title: 'گام ۳: تنظیم روزها و ساعات کاری هفتگی',
      shortLabel: '۳. ساعات کاری',
      weightPercent: 20,
      completed: hasWorkingHours,
      href: '/app/working-hours?setup=1',
      statusHint:
        'تعیین روزهای باز بودن سالن و ساعات پذیرش (تک‌شیفت یا دو شیفته)',
    },
    {
      id: 'specialists',
      stepNumber: 4,
      routePath: '/app/staff',
      title: 'گام ۴: معرفی متخصص سالن (حداقل ۱ متخصص فعال)',
      shortLabel: '۴. معرفی متخصص',
      weightPercent: 15,
      completed: hasSpecialists,
      href: '/app/staff?setup=1',
      statusHint:
        'ثبت خودتان یا اعضای تیم به عنوان متخصص فعال جهت انتخاب در نوبت‌دهی',
    },
    {
      id: 'financial_info',
      stepNumber: 5,
      routePath: '/app/subscription',
      title: 'گام ۵: ثبت شبا/کارت، درصد بیعانه و تایید قرارداد همکاری',
      shortLabel: '۵. شبا و تایید قرارداد',
      weightPercent: 20,
      completed: hasFinancialInfo,
      href: '/app/subscription?setup=1',
      statusHint:
        'ثبت شماره شبا/کارت جهت تسویه، انتخاب درصد بیعانه و تیک تایید مفاد قرارداد همکاری',
    },
  ];

  const totalPercent = steps.reduce(
    (sum, step) => sum + (step.completed ? step.weightPercent : 0),
    0
  );
  const completedStepsCount = steps.filter((s) => s.completed).length;

  const incompleteSteps = steps.filter((s) => !s.completed);
  const nextIncompleteStep = incompleteSteps[0] ?? null;
  const isReadyForPublicShowcase = incompleteSteps.length === 0;

  return {
    totalPercent,
    completedStepsCount,
    totalStepsCount: steps.length,
    isReadyForPublicShowcase,
    contractAccepted,
    hasBankInfo,
    planName,
    planStaffLimitCount,
    recommendedServicesMin,
    activeServicesCount: bizServices.length,
    activeSpecialistsCount: bizSpecialists.length,
    openDaysCount: openDays.length,
    steps,
    incompleteSteps,
    nextIncompleteStep,
  };
}

/**
 * بررسی اینکه آیا کسب‌وکار شرایط نمایش عمومی در ویترین مشتریان را دارد یا خیر.
 */
export function isBusinessReadyForPublicDisplay(params: {
  business: BusinessItem;
  services: ServiceItem[];
  specialists?: SpecialistItem[];
}): boolean {
  const { business, services, specialists = [] } = params;
  if (business.approvalStatus !== 'APPROVED') return false;
  if (business.isSampleShowcase || /^biz-[1-8]$/.test(business.id))
    return false;
  if (business.contractAccepted === false) return false;

  const summary = computeBusinessProfileCompletion({
    business,
    services,
    specialists,
  });
  if (summary.isReadyForPublicShowcase) return true;

  const bizServices = services.filter(
    (s) =>
      (s.businessId === business.id || s.businessId === business.slug) &&
      s.isActive !== false
  );
  if (
    bizServices.length >= 1 &&
    Boolean(business.address?.trim()) &&
    (Boolean(business.contractAccepted) ||
      Boolean(business.verifiedBadge) ||
      Boolean(business.isVipPartner) ||
      Boolean(business.isSponsored))
  ) {
    return true;
  }

  return false;
}

const getStepIcon = (id: ProfileCompletionStep['id']) => {
  switch (id) {
    case 'basic_location':
      return <MapPin className="h-4 w-4" />;
    case 'services':
      return <Scissors className="h-4 w-4" />;
    case 'working_hours':
      return <Clock className="h-4 w-4" />;
    case 'specialists':
      return <Users className="h-4 w-4" />;
    case 'financial_info':
      return <CreditCard className="h-4 w-4" />;
    case 'media_bio':
      return <Sparkles className="h-4 w-4" />;
  }
};

/**
 * ویجت دایره‌ای پیشرفت در بالای سایدبار پنل کسب‌وکار
 */
export const SidebarProfileCompletionRing: React.FC<{
  summary: BusinessProfileCompletionSummary;
}> = ({ summary }) => {
  if (summary.totalPercent >= 100 || summary.incompleteSteps.length === 0) {
    return null;
  }

  const size = 36;
  const strokeWidth = 3.5;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset =
    circumference - (summary.totalPercent / 100) * circumference;

  return (
    <div className="mt-2.5 rounded-xl border border-amber-400/30 bg-amber-500/15 p-2.5">
      <div className="flex items-center gap-2">
        <div className="relative flex h-9 w-9 shrink-0 items-center justify-center">
          <svg
            className="h-9 w-9 -rotate-90 transform"
            viewBox={`0 0 ${size} ${size}`}
          >
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke="currentColor"
              strokeWidth={strokeWidth}
              className="text-white/20"
            />
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke="currentColor"
              strokeWidth={strokeWidth}
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="text-amber-300 transition-all duration-500"
            />
          </svg>
          <span className="absolute text-[9px] font-black text-white tabular-nums">
            {toPersianDigits(summary.totalPercent)}٪
          </span>
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-1">
            <span className="truncate text-[10px] font-bold text-amber-200">
              ویزارد ۵ مرحله‌ای راه‌اندازی
            </span>
            <span className="shrink-0 text-[9px] font-bold text-white">
              {toPersianDigits(summary.completedStepsCount)} از{' '}
              {toPersianDigits(summary.totalStepsCount)} گام
            </span>
          </div>

          <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-white/20">
            <div
              className="h-full rounded-full bg-amber-300 transition-all duration-500"
              style={{ width: `${summary.totalPercent}%` }}
            />
          </div>

          {summary.nextIncompleteStep ? (
            <Link
              to={summary.nextIncompleteStep.href}
              className="mt-1 flex items-center justify-between text-[10px] font-bold text-white hover:text-amber-200"
            >
              <span className="truncate">
                ادامه: {summary.nextIncompleteStep.shortLabel}
              </span>
              <ChevronLeft className="h-3 w-3 shrink-0" />
            </Link>
          ) : null}
        </div>
      </div>
    </div>
  );
};

/**
 * استپر افقی ۵ مرحله‌ای بالای صفحات راه‌اندازی کسب‌وکار
 * هر مرحله پس از تکمیل تیک سبز (✓) می‌خورد و دکمه «رفتن به گام بعدی» را نمایش می‌دهد.
 */
export const BusinessProfileCompletionBanner: React.FC<{
  summary: BusinessProfileCompletionSummary;
}> = ({ summary }) => {
  const location = useLocation();
  const pathname = location.pathname;

  if (summary.totalPercent >= 100 || summary.incompleteSteps.length === 0) {
    return null;
  }

  const currentStepOnRoute =
    summary.steps.find((s) => s.routePath === pathname) ?? null;
  const currentStepIndex = currentStepOnRoute
    ? summary.steps.findIndex((s) => s.id === currentStepOnRoute.id)
    : -1;
  const prevStep =
    currentStepIndex > 0 ? summary.steps[currentStepIndex - 1] : null;
  const nextSequentialStep =
    currentStepIndex >= 0 && currentStepIndex < summary.steps.length - 1
      ? summary.steps[currentStepIndex + 1]
      : summary.nextIncompleteStep;

  return (
    <div
      data-testid="business-onboarding-stepper-banner"
      className="rounded-3xl border-2 border-[#0057FF]/35 bg-white p-4 sm:p-5 shadow-sm space-y-4"
    >
      {/* ردیف بالایی: عنوان ویزارد و نوار درصد پیشرفت */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E2E8F0]">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#E0ECFF] px-3 py-1 text-[11px] font-black text-[#0057FF]">
              <span>ویزارد راه‌اندازی کسب‌وکار</span>
              <span>·</span>
              <span>
                {toPersianDigits(summary.completedStepsCount)} از{' '}
                {toPersianDigits(summary.totalStepsCount)} مرحله تکمیل شده
              </span>
            </span>
            <span className="rounded-full bg-[#ECFDF5] border border-[#A7F3D0] px-2.5 py-0.5 text-[10px] font-extrabold text-[#059669]">
              پیشرفت: {toPersianDigits(summary.totalPercent)}٪
            </span>
          </div>
          <p className="text-xs sm:text-sm font-extrabold text-[#061138]">
            مراحل زیر را به ترتیب تکمیل کنید تا تیک سبز (✓) بخورند؛ پس از پایان گام ۵، پیشخوان کامل و تمام منوها باز می‌شوند.
          </p>
        </div>

        {summary.nextIncompleteStep &&
        pathname !== summary.nextIncompleteStep.routePath ? (
          <Link
            to={summary.nextIncompleteStep.href}
            className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-2xl bg-[#0057FF] px-4 py-2.5 text-xs font-black text-white shadow-xs transition hover:bg-[#0046CC]"
          >
            <span>رفتن به {summary.nextIncompleteStep.shortLabel}</span>
            <ChevronLeft className="h-4 w-4" />
          </Link>
        ) : null}
      </div>

      {/* استپر ۵ مرحله‌ای افقی با تیک سبز برای مراحل انجام‌شده */}
      <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
        {summary.steps.map((step) => {
          const isCurrentRoute = pathname === step.routePath;
          const isNextTarget =
            !isCurrentRoute && summary.nextIncompleteStep?.id === step.id;

          return (
            <Link
              key={step.id}
              to={step.href}
              title={step.statusHint}
              className={`group relative flex sm:flex-col justify-between gap-2 rounded-2xl border p-3 transition-all ${
                step.completed
                  ? isCurrentRoute
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/25'
                    : 'border-emerald-300 bg-emerald-50/75 text-emerald-950 hover:bg-emerald-100/70'
                  : isCurrentRoute
                    ? 'border-[#0057FF] bg-[#0057FF] text-white shadow-sm ring-2 ring-[#0057FF]/25'
                    : isNextTarget
                      ? 'border-[#0057FF] bg-[#EFF6FF] text-[#061138] hover:bg-[#E0ECFF]'
                      : 'border-[#CBD5E1] bg-[#F8FAFC] text-[#475569] hover:border-[#0057FF]'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span
                  className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-xl text-xs font-black ${
                    step.completed
                      ? 'bg-emerald-600 text-white'
                      : isCurrentRoute
                        ? 'bg-white text-[#0057FF]'
                        : isNextTarget
                          ? 'bg-[#0057FF] text-white'
                          : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {step.completed ? (
                    <Check className="h-4 w-4 stroke-[3]" />
                  ) : (
                    toPersianDigits(step.stepNumber)
                  )}
                </span>

                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-black ${
                    step.completed
                      ? 'bg-emerald-600 text-white'
                      : isCurrentRoute
                        ? 'bg-white/20 text-white'
                        : isNextTarget
                          ? 'bg-[#0057FF] text-white'
                          : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {step.completed
                    ? 'تکمیل ✓'
                    : isCurrentRoute
                      ? 'در حال تکمیل'
                      : `گام ${toPersianDigits(step.stepNumber)}`}
                </span>
              </div>

              <div className="min-w-0 flex-1 sm:mt-1">
                <p
                  className={`text-xs font-extrabold leading-snug ${
                    step.completed
                      ? 'text-emerald-950'
                      : isCurrentRoute
                        ? 'text-white'
                        : 'text-[#061138]'
                  }`}
                >
                  {step.shortLabel}
                </p>
              </div>
            </Link>
          );
        })}
      </div>

      {/* نوار راهنمای مرحله فعلی و دکمه رفتن به گام بعد */}
      {currentStepOnRoute ? (
        <div
          className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border p-3 text-xs ${
            currentStepOnRoute.completed
              ? 'border-emerald-300 bg-emerald-50 text-emerald-950'
              : 'border-[#CBD5E1] bg-[#F8FAFC] text-[#061138]'
          }`}
        >
          <div className="flex items-start sm:items-center gap-2.5">
            <span
              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-xl font-black ${
                currentStepOnRoute.completed
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#0057FF] text-white'
              }`}
            >
              {currentStepOnRoute.completed ? (
                <Check className="h-4 w-4 stroke-[3]" />
              ) : (
                getStepIcon(currentStepOnRoute.id)
              )}
            </span>
            <div>
              <p className="font-extrabold">
                {currentStepOnRoute.completed
                  ? `✓ ${currentStepOnRoute.title} با موفقیت تکمیل شد!`
                  : `در حال تکمیل ${currentStepOnRoute.title}`}
              </p>
              <p className="text-[11px] opacity-85 mt-0.5">
                {currentStepOnRoute.statusHint}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {prevStep ? (
              <Link
                to={prevStep.href}
                className="inline-flex items-center gap-1 rounded-xl border border-[#CBD5E1] bg-white px-3 py-1.5 text-[11px] font-extrabold text-[#334155] hover:bg-slate-100"
              >
                <ChevronRight className="h-3.5 w-3.5" />
                <span>گام قبلی</span>
              </Link>
            ) : null}

            {currentStepOnRoute.completed && nextSequentialStep ? (
              <Link
                to={nextSequentialStep.href}
                className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-black text-white shadow-xs hover:bg-emerald-700"
              >
                <span>ادامه به {nextSequentialStep.shortLabel}</span>
                <ChevronLeft className="h-4 w-4" />
              </Link>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
};

/**
 * محیط اختصاصی و خلوت ویزارد ۵ مرحله‌ای در صفحه اصلی پیشخوان (/app) یا صفحات قفل‌شده
 * تا زمانی که کسب‌وکار هر ۵ مرحله و تایید قرارداد را تکمیل نکرده باشد، به جای پیشخوان شلوغ این ویزارد نمایش داده می‌شود.
 */
export const BusinessOnboardingWizardWorkspace: React.FC<{
  summary: BusinessProfileCompletionSummary;
  businessName?: string;
  lockedFeatureTitle?: string;
}> = ({ summary, businessName, lockedFeatureTitle }) => {
  const size = 68;
  const strokeWidth = 6;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset =
    circumference - (summary.totalPercent / 100) * circumference;

  return (
    <div
      data-testid="business-onboarding-wizard-workspace"
      className="max-w-4xl mx-auto space-y-5"
    >
      {lockedFeatureTitle ? (
        <div className="rounded-3xl border-2 border-amber-400 bg-amber-50 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-amber-500 text-white">
              <Lock className="h-5 w-5" />
            </span>
            <div className="space-y-1">
              <p className="text-xs sm:text-sm font-black text-amber-950">
                بخش «{lockedFeatureTitle}» تا پایان ۵ گام راه‌اندازی و تایید قرارداد قفل است
              </p>
              <p className="text-xs text-amber-900 leading-relaxed">
                برای جلوگیری از سردرگمی، ابتدا ۵ گام راه‌اندازی پروفایل و قرارداد همکاری را تکمیل کنید تا پیشخوان، تقویم نوبت‌ها و گزارش‌های مالی برای شما فعال شوند.
              </p>
            </div>
          </div>
          {summary.nextIncompleteStep ? (
            <Link
              to={summary.nextIncompleteStep.href}
              className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-2xl bg-[#0057FF] px-4 py-2.5 text-xs font-black text-white shadow-xs hover:bg-[#0046CC]"
            >
              <span>تکمیل {summary.nextIncompleteStep.shortLabel}</span>
              <ChevronLeft className="h-4 w-4" />
            </Link>
          ) : null}
        </div>
      ) : null}

      {/* هدر اصلی ویزارد ۵ مرحله‌ای */}
      <div className="rounded-3xl bg-gradient-to-l from-[#061138] via-[#0B1E5B] to-[#0057FF] text-white p-5 sm:p-7 shadow-md border border-[#0057FF]/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-start sm:items-center gap-4">
            <div className="relative flex h-16 w-16 shrink-0 items-center justify-center">
              <svg
                className="h-16 w-16 -rotate-90 transform"
                viewBox={`0 0 ${size} ${size}`}
              >
                <circle
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth={strokeWidth}
                  className="text-white/20"
                />
                <circle
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth={strokeWidth}
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className="text-[#00E5FF] transition-all duration-500"
                />
              </svg>
              <span className="absolute text-sm font-black text-white tabular-nums">
                {toPersianDigits(summary.totalPercent)}٪
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-[#00E5FF] px-3 py-0.5 text-[11px] font-black text-[#061138]">
                  راه‌اندازی گام‌به‌گام کسب‌وکار
                </span>
                <span className="rounded-full bg-white/15 px-2.5 py-0.5 text-[11px] font-bold text-white">
                  {toPersianDigits(summary.completedStepsCount)} از{' '}
                  {toPersianDigits(summary.totalStepsCount)} مرحله انجام شده
                </span>
              </div>
              <h1 className="text-base sm:text-xl font-black text-white">
                {businessName
                  ? `تکمیل پروفایل و فعال‌سازی پنل «${businessName}»`
                  : 'تکمیل پروفایل و فعال‌سازی پیشخوان کسب‌وکار'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-2xl">
                لطفاً ۵ مرحله زیر را به ترتیب تکمیل کنید. هر مرحله پس از ذخیره تیک سبز (✓) می‌خورد و پس از تایید قرارداد در گام ۵، پیشخوان کامل، تقویم نوبت‌ها و تمامی ابزارهای پنل برای شما باز خواهد شد.
              </p>
            </div>
          </div>

          {summary.nextIncompleteStep ? (
            <Link
              to={summary.nextIncompleteStep.href}
              className="inline-flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-[#10B981] hover:bg-[#059669] px-5 py-3.5 text-xs sm:text-sm font-black text-white shadow-md transition"
            >
              <span>شروع {summary.nextIncompleteStep.shortLabel}</span>
              <ChevronLeft className="h-4 w-4" />
            </Link>
          ) : null}
        </div>
      </div>

      {/* فهرست ۵ گام به ترتیب با وضعیت تیک سبز یا دکمه اقدام */}
      <div className="space-y-3">
        {summary.steps.map((step) => {
          const isCurrentNext = summary.nextIncompleteStep?.id === step.id;

          return (
            <div
              key={step.id}
              className={`rounded-3xl border-2 p-4 sm:p-5 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                step.completed
                  ? 'border-emerald-300 bg-emerald-50/70'
                  : isCurrentNext
                    ? 'border-[#0057FF] bg-white shadow-md ring-4 ring-[#0057FF]/10'
                    : 'border-[#CBD5E1] bg-white/90'
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-sm font-black ${
                    step.completed
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : isCurrentNext
                        ? 'bg-[#0057FF] text-white shadow-xs'
                        : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {step.completed ? (
                    <Check className="h-6 w-6 stroke-[3]" />
                  ) : (
                    toPersianDigits(step.stepNumber)
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2
                      className={`text-sm sm:text-base font-black ${
                        step.completed ? 'text-emerald-950' : 'text-[#061138]'
                      }`}
                    >
                      {step.title}
                    </h2>
                    {step.completed ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-2.5 py-0.5 text-[10px] font-black text-white">
                        <Check className="h-3 w-3 stroke-[3]" />
                        <span>انجام شد</span>
                      </span>
                    ) : isCurrentNext ? (
                      <span className="rounded-full bg-[#E0ECFF] px-2.5 py-0.5 text-[10px] font-black text-[#0057FF]">
                        نوبت این گام است
                      </span>
                    ) : (
                      <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-bold text-slate-600">
                        گام {toPersianDigits(step.stepNumber)} از ۵
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#475569] leading-relaxed">
                    {step.statusHint}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end shrink-0">
                <Link
                  to={step.href}
                  className={`inline-flex items-center justify-center gap-1.5 rounded-2xl px-4 py-2.5 text-xs font-black transition ${
                    step.completed
                      ? 'border border-emerald-400 bg-white text-emerald-800 hover:bg-emerald-100'
                      : isCurrentNext
                        ? 'bg-[#0057FF] text-white shadow-sm hover:bg-[#0046CC]'
                        : 'border border-[#CBD5E1] bg-[#F8FAFC] text-[#334155] hover:border-[#0057FF] hover:text-[#0057FF]'
                  }`}
                >
                  <span>
                    {step.completed
                      ? 'مشاهده / ویرایش ✓'
                      : isCurrentNext
                        ? `شروع و تکمیل گام ${toPersianDigits(step.stepNumber)}`
                        : `ورود به گام ${toPersianDigits(step.stepNumber)}`}
                  </span>
                  <ChevronLeft className="h-4 w-4" />
                </Link>
              </div>
            </div>
          );
        })}
      </div>

      {/* راهنمای باز شدن پیشخوان پس از پایان ۵ مرحله */}
      <div className="rounded-3xl border border-[#CBD5E1] bg-white p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-[#ECFDF5] text-[#059669]">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <div className="space-y-0.5">
            <p className="text-xs sm:text-sm font-black text-[#061138]">
              پس از تیک خوردن هر ۵ مرحله چه اتفاقی می‌افتد؟
            </p>
            <p className="text-xs text-[#64748B] leading-relaxed">
              بلافاصله پیشخوان عملیاتی روزانه، تقویم نوبت‌ها، پرونده مشتریان، باشگاه وفاداری، گزارش‌های مالی و لینک اختصاصی بایو اینستاگرام شما فعال و باز می‌شود.
            </p>
          </div>
        </div>
        <span className="shrink-0 rounded-full bg-slate-100 px-3 py-1 text-[11px] font-extrabold text-slate-600">
          گالری نمونه‌کار اختیاری است ✓
        </span>
      </div>
    </div>
  );
};
