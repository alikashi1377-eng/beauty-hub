import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  DEFAULT_PAYMENT_GATEWAY_CONFIG,
  SAMPLE_AD_PACKAGES,
  SAMPLE_APPOINTMENTS,
  SAMPLE_BUSINESSES,
  SAMPLE_CAMPAIGNS,
  SAMPLE_CATEGORIES,
  SAMPLE_CUSTOMERS,
  SAMPLE_GALLERY,
  SAMPLE_PAYMENT_ORDERS,
  SAMPLE_REVIEWS,
  SAMPLE_SERVICES,
  SAMPLE_SPECIALISTS,
  SAMPLE_SUBSCRIPTION_PLANS,
} from '../mocks/sampleData';
import {
  ApiClientError,
  AuthenticatedSessionUser,
  realApiClient,
} from '../services/apiClient';
import {
  AdPackageItem,
  AdminNotificationItem,
  AdminNotificationSettings,
  AdminUserRecord,
  AppointmentItem,
  AppointmentStatus,
  ApprovalStatus,
  BookingDraft,
  BusinessItem,
  BusinessStoryItem,
  BusinessType,
  CategoryItem,
  CustomerRecord,
  CustomerWalletTransactionItem,
  DailyIncomeLogItem,
  GalleryItem,
  MarketingCampaignItem,
  OnboardingDraft,
  PaymentGatewayConfig,
  PaymentOrderItem,
  PlatformBusinessNoticeItem,
  ReviewItem,
  ServiceItem,
  SettlementRequestItem,
  SmsMessageLogItem,
  SpecialistItem,
  SponsoredPlacementSlot,
  SubscriptionPlanItem,
  SubscriptionStatus,
  SupportTicketItem,
  WorkingHourItem,
} from '../types';
import { getBeautyPhotoUrl } from '../components/ui/VisualMediaIllustration';
import {
  computeSelectedServicesSummary,
  formatPriceToman,
  getUpcomingJalaliDays,
  toEnglishDigitsClient,
  toPersianDigits,
} from '../utils/formatters';
import { validateReviewContent } from '../utils/reviewModeration';
import {
  calculateBookingFinancialBreakdown,
  isAppointmentEligibleForSettlement,
  normalizeDepositPercent,
  resolveAppointmentFinancialBreakdown,
  resolveBusinessCommissionMeta,
  validateServiceAntiFraud,
} from '../utils/financialEngine';
import {
  AccountRoleChoice,
  AuthFlowScreen,
  getSavedMemoryAccounts,
  PERSISTED_SESSION_USER_KEY,
  removeMemoryAccount,
  saveMemoryAccount,
  updateMemoryAccountPhoneOrProfile,
} from '../components/auth/timetoAuthFlow';
import { saveVisitorRole } from '../components/home/timetoHomeData';

let uniqueIdCounter = 0;
function makeUniqueId(prefix: string): string {
  uniqueIdCounter += 1;
  const rand = Math.random().toString(36).slice(2, 7);
  return `${prefix}-${Date.now()}-${uniqueIdCounter}-${rand}`;
}

export interface AuthModalOpenOptions {
  initialScreen?: AuthFlowScreen;
  defaultRole?: AccountRoleChoice;
  redirectTo?: string;
  promptReason?: string;
}

export interface ToastNotice {
  id: number;
  message: string;
  tone: 'success' | 'info' | 'warning' | 'danger';
}

interface PrototypeDataContextValue {
  dataMode: 'mock' | 'real';
  databaseError: string | null;
  isLoadingInitialData: boolean;
  authUser: AuthenticatedSessionUser | null;
  ownedBusinessId: string | null;
  isAuthModalOpen: boolean;
  authModalOptions: AuthModalOpenOptions;
  openAuthModal: (options?: AuthModalOpenOptions) => void;
  closeAuthModal: () => void;
  completeUnifiedAuthSession: (payload: {
    phone: string;
    password?: string;
    firstName?: string;
    lastName?: string;
    fullName: string;
    gender?: 'FEMALE' | 'MALE';
    role: AccountRoleChoice;
    avatarUrl?: string;
    salonInfo?: {
      businessName: string;
      businessType: BusinessType;
      categorySlug?: string;
      typeLabel?: string;
      city: string;
      neighborhood: string;
    };
  }) => Promise<AuthenticatedSessionUser>;
  requestOtpLogin: (phone: string) => Promise<{ challengeId?: string }>;
  verifyOtpLogin: (
    phone: string,
    code: string
  ) => Promise<AuthenticatedSessionUser>;
  loginWithPassword: (
    phone: string,
    password: string
  ) => Promise<AuthenticatedSessionUser>;
  setAccountPassword: (password: string) => Promise<boolean>;
  resetPasswordWithOtp: (
    phone: string,
    code: string,
    newPassword: string
  ) => Promise<boolean>;
  logoutUser: () => Promise<void>;
  updateCustomerProfile: (patch: {
    fullName?: string;
    phone?: string;
    defaultCity?: string;
  }) => Promise<boolean>;
  updateAdminUserRecord: (
    phone: string,
    patch: {
      fullName?: string;
      newPhone?: string;
      city?: string;
      role?: 'CUSTOMER' | 'BUSINESS_OWNER';
    }
  ) => boolean;
  deleteAdminUserRecord: (phone: string) => void;
  refreshRealData: () => Promise<void>;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  favoriteBusinessIds: string[];
  toggleFavoriteBusiness: (businessId: string) => void;
  favoriteSpecialistIds: string[];
  toggleFavoriteSpecialist: (specialistId: string) => void;
  businesses: BusinessItem[];
  currentBusiness: BusinessItem | null;
  updateBusinessProfile: (
    businessId: string,
    patch: Partial<BusinessItem>
  ) => void;
  updateBusinessWorkingHours: (
    businessId: string,
    hours: WorkingHourItem[]
  ) => void;
  updateBusinessApproval: (businessId: string, status: ApprovalStatus) => void;
  adminReviewedBizIds: string[];
  grantBusinessPlanOrAdByAdmin: (input: {
    businessId: string;
    grantType: 'PLAN' | 'SPONSORED_AD' | 'BOTH' | 'VIP_AMBASSADOR';
    planId?: string;
    durationDays: number;
    isTrialGift?: boolean;
    sponsoredPlacement?: SponsoredPlacementSlot;
    sponsoredLabel?: string;
    bonusSmsCount?: number;
    isVipPartner?: boolean;
    vipCommissionPercent?: number;
  }) => void;
  permanentlyDeleteBusiness: (businessId: string) => void;
  platformBusinessNotices: PlatformBusinessNoticeItem[];
  sendPlatformBusinessNotice: (input: {
    targetBusinessId: 'ALL' | string;
    targetBusinessName?: string;
    title: string;
    message: string;
  }) => PlatformBusinessNoticeItem;
  markPlatformBusinessNoticeRead: (noticeId: string, businessId?: string) => void;
  services: ServiceItem[];
  addService: (item: Omit<ServiceItem, 'id'>) => void;
  updateService: (id: string, patch: Partial<ServiceItem>) => void;
  deleteService: (id: string) => void;
  reorderBusinessServices: (
    businessId: string,
    orderedServiceIds: string[]
  ) => void;
  specialists: SpecialistItem[];
  addSpecialist: (item: Omit<SpecialistItem, 'id'>) => void;
  updateSpecialist: (id: string, patch: Partial<SpecialistItem>) => void;
  appointments: AppointmentItem[];
  updateAppointmentStatus: (
    id: string,
    status: AppointmentStatus,
    cancelledByRole?: 'CUSTOMER' | 'BUSINESS_OWNER',
    customRefundAmountToman?: number
  ) => void;
  customerWalletBalanceToman: number;
  customerWalletTransactions: CustomerWalletTransactionItem[];
  topUpCustomerWallet: (
    amountToman: number,
    trackingCode?: string,
    targetPhone?: string,
    targetName?: string
  ) => CustomerWalletTransactionItem;
  payFromCustomerWallet: (
    amountToman: number,
    title: string,
    description: string
  ) => { ok: boolean; trackingCode: string };
  requestCustomerWalletWithdrawal: (
    amountToman: number,
    bankCardOrSheba: string
  ) => CustomerWalletTransactionItem | null;
  settleAppointmentInPerson: (
    appointmentId: string,
    customAmountToman?: number
  ) => void;
  dailyIncomeLogs: DailyIncomeLogItem[];
  addDailyIncomeLog: (
    input: Omit<DailyIncomeLogItem, 'id' | 'createdAtJalali'>
  ) => DailyIncomeLogItem;
  deleteDailyIncomeLog: (id: string) => void;
  categories: CategoryItem[];
  addCategory: (item: Omit<CategoryItem, 'id'>) => void;
  updateCategory: (id: string, patch: Partial<CategoryItem>) => void;
  deleteCategory: (id: string) => void;
  reorderCategory: (id: string, direction: 'UP' | 'DOWN') => void;
  gallery: GalleryItem[];
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => void;
  removeGalleryItem: (id: string) => void;
  businessStories: BusinessStoryItem[];
  addBusinessStory: (
    item: Omit<BusinessStoryItem, 'id' | 'createdAtJalali' | 'createdAtMs'>
  ) => BusinessStoryItem;
  deleteBusinessStory: (id: string) => void;
  campaigns: MarketingCampaignItem[];
  addCampaign: (item: Omit<MarketingCampaignItem, 'id'>) => void;
  customers: CustomerRecord[];
  addCustomer: (input: {
    fullName: string;
    phone: string;
    city?: string;
    favoriteService?: string;
    totalVisits?: number;
    totalSpentToman?: number;
    lastVisitJalali?: string;
    notes?: string;
    businessId?: string;
  }) => CustomerRecord | null;
  addCustomersBulk: (
    items: Array<{
      fullName: string;
      phone: string;
      favoriteService?: string;
      notes?: string;
      totalVisits?: number;
      totalSpentToman?: number;
    }>,
    businessId?: string
  ) => { addedCount: number; updatedCount: number };
  updateCustomer: (id: string, patch: Partial<CustomerRecord>) => void;
  deleteCustomer: (id: string) => void;
  adminUsers: AdminUserRecord[];
  reviews: ReviewItem[];
  addReview: (input: {
    businessId: string;
    specialistSlug?: string;
    serviceTitle: string;
    rating: number;
    comment: string;
  }) => Promise<boolean>;
  replyToReview: (reviewId: string, replyText: string) => Promise<boolean>;
  reportReviewAbuse: (reviewId: string, reason: string) => Promise<boolean>;
  deleteReviewByAdmin: (reviewId: string) => Promise<boolean>;
  plans: SubscriptionPlanItem[];
  updatePlan: (planId: string, patch: Partial<SubscriptionPlanItem>) => void;
  adPackages: AdPackageItem[];
  updateAdPackage: (pkgId: string, patch: Partial<AdPackageItem>) => void;
  paymentConfig: PaymentGatewayConfig;
  updatePaymentConfig: (patch: Partial<PaymentGatewayConfig>) => void;
  paymentOrders: PaymentOrderItem[];
  submitPaymentOrder: (
    input: Omit<PaymentOrderItem, 'id' | 'createdAtJalali' | 'status'>,
    autoApprove?: boolean
  ) => PaymentOrderItem;
  reviewPaymentOrder: (
    orderId: string,
    decision: 'APPROVED' | 'REJECTED'
  ) => void;
  settlementRequests: SettlementRequestItem[];
  requestWalletSettlement: (businessId?: string) => SettlementRequestItem | null;
  markSettlementPaid: (settlementId: string, trackingCode?: string) => void;
  settleBusinessDossierByAdmin: (
    businessId: string,
    trackingCode?: string
  ) => SettlementRequestItem | null;
  runNightlyBatchSettlement: () => number;
  recordSponsoredClick: (businessId: string) => void;
  sendAppointmentReminders: (businessId?: string) => Promise<number>;
  smsLogs: SmsMessageLogItem[];
  sendBusinessCustomerSms: (input: {
    businessId?: string;
    recipientPhones: string[];
    messageText: string;
    templateTitle?: string;
  }) => Promise<boolean>;
  adminNotifications: AdminNotificationItem[];
  markAdminNotificationRead: (id: string) => void;
  clearAllAdminNotifications: () => void;
  adminNotificationSettings: AdminNotificationSettings;
  updateAdminNotificationSettings: (
    patch: Partial<AdminNotificationSettings>
  ) => void;
  supportTickets: SupportTicketItem[];
  submitSupportTicket: (input: {
    senderName?: string;
    senderPhone?: string;
    categoryLabel: string;
    subject: string;
    message: string;
    senderRole?: 'CUSTOMER' | 'BUSINESS_OWNER';
    businessId?: string;
    businessName?: string;
  }) => SupportTicketItem;
  replySupportTicket: (
    ticketId: string,
    replyText: string,
    status?: 'ANSWERED' | 'CLOSED'
  ) => void;
  activePlanId: string;
  setActivePlanId: (planId: string) => void;
  onboardingDraft: OnboardingDraft;
  updateOnboardingDraft: (patch: Partial<OnboardingDraft>) => void;
  submitBusinessOnboarding: () => Promise<boolean>;
  bookingDraft: BookingDraft;
  updateBookingDraft: (patch: Partial<BookingDraft>) => void;
  completeSimulatedBooking: (
    paymentMeta?: {
      depositPaidToman: number;
      paymentMethod: 'GATEWAY' | 'WALLET';
      paymentTrackingCode: string;
    },
    overrideDraft?: Partial<BookingDraft> & {
      businessId?: string;
      businessName?: string;
    }
  ) => AppointmentItem;
  submitBooking: (
    paymentMeta?: {
      depositPaidToman: number;
      paymentMethod: 'GATEWAY' | 'WALLET';
      paymentTrackingCode: string;
    },
    overrideDraft?: Partial<BookingDraft> & {
      businessId?: string;
      businessName?: string;
    }
  ) => Promise<AppointmentItem>;
  toast: ToastNotice | null;
  showToast: (
    message: string,
    tone?: 'success' | 'info' | 'warning' | 'danger'
  ) => void;
  dismissToast: () => void;
}

const INITIAL_ONBOARDING_DRAFT: OnboardingDraft = {
  businessType: BusinessType.WomenSalon,
  businessName: '',
  categorySlug: 'hair-color',
  slug: '',
  ownerName: '',
  phone: '',
  instagramHandle: '',
  avatarUrl: '',
  city: 'اصفهان',
  neighborhood: 'چهارباغ بالا',
  address: 'اصفهان، چهارباغ بالا',
  mapLat: 32.6288,
  mapLng: 51.6621,
  shortDescription: '',
  services: [],
  staff: [],
  workingHours: [
    { dayName: 'شنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'یکشنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'دوشنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'سه‌شنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'چهارشنبه', isOpen: true, openTime: '۰۹:۳۰', closeTime: '۱۹:۳۰' },
    { dayName: 'پنج‌شنبه', isOpen: true, openTime: '۱۰:۰۰', closeTime: '۱۸:۰۰' },
    { dayName: 'جمعه', isOpen: false, openTime: '۱۰:۰۰', closeTime: '۱۶:۰۰' },
  ],
  licenseCode: '',
  nationalIdNumber: '',
  selectedPlanId: 'plan-free-start',
};

const INITIAL_BOOKING_DRAFT: BookingDraft = {
  businessSlug: '',
  serviceId: '',
  serviceIds: [],
  specialistId: '',
  dateJalali: getUpcomingJalaliDays(1)[0]?.dateJalali || '۱۴۰۳/۰۸/۲۱',
  timeSlot: '۱۱:۰۰',
  customerName: '',
  customerPhone: '',
  customerNotes: '',
  lastReferenceCode: undefined,
};

const PrototypeDataContext = createContext<PrototypeDataContextValue | null>(
  null
);

const TIMETO_SERVER_TRUTH_EPOCH_KEY = 'timeto_server_truth_epoch_v20';
const STALE_ENTITY_CACHE_KEYS = [
  'timeto_registered_accounts_v2',
  'timeto_saved_appointments_v1',
  'timeto_local_services_v1',
  'timeto_local_specialists_v1',
  'timeto_biz_overrides_v2',
  'timeto_local_onboarded_businesses_v1',
  'timeto_cached_registered_users_v1',
  'timeto_settlement_requests_v1',
  'timeto_daily_income_logs_v1',
];

function ensureCleanServerTruthCacheEpoch(): void {
  if (typeof window === 'undefined') return;
  try {
    const currentEpoch = window.localStorage.getItem(TIMETO_SERVER_TRUTH_EPOCH_KEY);
    if (currentEpoch !== '1') {
      for (const key of STALE_ENTITY_CACHE_KEYS) {
        window.localStorage.removeItem(key);
      }
      window.localStorage.setItem(TIMETO_SERVER_TRUTH_EPOCH_KEY, '1');
    }
  } catch {
    // ignore storage errors
  }
}

ensureCleanServerTruthCacheEpoch();

export const PrototypeDataProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  ensureCleanServerTruthCacheEpoch();
  const [dataMode, setDataMode] = useState<'mock' | 'real'>('mock');
  const [databaseError, setDatabaseError] = useState<string | null>(null);
  const [isLoadingInitialData, setIsLoadingInitialData] =
    useState<boolean>(true);
  const [authUser, setAuthUserState] =
    useState<AuthenticatedSessionUser | null>(() => {
      try {
        const saved = window.localStorage.getItem(PERSISTED_SESSION_USER_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed && parsed.phone && Array.isArray(parsed.roles)) {
            return parsed as AuthenticatedSessionUser;
          }
        }
      } catch {
        // ignore
      }
      return null;
    });

  const setAuthUser = (next: AuthenticatedSessionUser | null) => {
    setAuthUserState(next);
    try {
      if (next) {
        window.localStorage.setItem(
          PERSISTED_SESSION_USER_KEY,
          JSON.stringify(next)
        );
      } else {
        window.localStorage.removeItem(PERSISTED_SESSION_USER_KEY);
      }
    } catch {
      // ignore
    }
  };

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalOptions, setAuthModalOptions] =
    useState<AuthModalOpenOptions>({
      initialScreen: 'LOGIN',
      defaultRole: 'CUSTOMER',
    });

  const openAuthModal = (options?: AuthModalOpenOptions) => {
    setAuthModalOptions({
      initialScreen: options?.initialScreen ?? 'LOGIN',
      defaultRole: options?.defaultRole ?? 'CUSTOMER',
      redirectTo: options?.redirectTo,
      promptReason: options?.promptReason,
    });
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const [selectedCity, setSelectedCity] = useState<string>('ALL');
  const [favoriteBusinessIds, setFavoriteBusinessIds] = useState<string[]>(() => {
    try {
      const sessRaw = window.localStorage.getItem(PERSISTED_SESSION_USER_KEY);
      const sessUser = sessRaw ? JSON.parse(sessRaw) : null;
      const phoneKey = sessUser?.phone
        ? `timeto_fav_biz_${sessUser.phone}`
        : 'timeto_fav_biz_guest';
      const saved = window.localStorage.getItem(phoneKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return [];
  });
  const [favoriteSpecialistIds, setFavoriteSpecialistIds] = useState<string[]>(() => {
    try {
      const sessRaw = window.localStorage.getItem(PERSISTED_SESSION_USER_KEY);
      const sessUser = sessRaw ? JSON.parse(sessRaw) : null;
      const phoneKey = sessUser?.phone
        ? `timeto_fav_spc_${sessUser.phone}`
        : 'timeto_fav_spc_guest';
      const saved = window.localStorage.getItem(phoneKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return [];
  });

  useEffect(() => {
    try {
      const bizKey = authUser?.phone
        ? `timeto_fav_biz_${authUser.phone}`
        : 'timeto_fav_biz_guest';
      const spcKey = authUser?.phone
        ? `timeto_fav_spc_${authUser.phone}`
        : 'timeto_fav_spc_guest';
      const savedBiz = window.localStorage.getItem(bizKey);
      const savedSpc = window.localStorage.getItem(spcKey);
      setFavoriteBusinessIds(savedBiz ? JSON.parse(savedBiz) : []);
      setFavoriteSpecialistIds(savedSpc ? JSON.parse(savedSpc) : []);
    } catch {
      setFavoriteBusinessIds([]);
      setFavoriteSpecialistIds([]);
    }
  }, [authUser?.phone]);
  const mergeBusinessOverrides = (
    list: BusinessItem[],
    extraRegisteredUsers?: AdminUserRecord[],
    authoritativeFromServer = false
  ): BusinessItem[] => {
    try {
      const excludedSampleIds = new Set([
        'biz-1',
        'biz-2',
        'biz-3',
        'biz-4',
        'biz-5',
        'biz-6',
        'biz-7',
        'biz-8',
      ]);
      const permDeletedRaw = window.localStorage.getItem(
        'timeto_permanently_deleted_biz_ids_v1'
      );
      const permDeletedIds = new Set<string>(
        permDeletedRaw ? JSON.parse(permDeletedRaw) : []
      );
      const overridesRaw = authoritativeFromServer
        ? null
        : window.localStorage.getItem('timeto_biz_overrides_v2');
      const overrides = overridesRaw ? JSON.parse(overridesRaw) : {};
      const localOnbRaw = authoritativeFromServer
        ? null
        : window.localStorage.getItem('timeto_local_onboarded_businesses_v1');
      const localOnbList: BusinessItem[] = localOnbRaw
        ? JSON.parse(localOnbRaw)
        : [];

      let resolvedRegisteredUsers: AdminUserRecord[] = [];
      if (Array.isArray(extraRegisteredUsers) && extraRegisteredUsers.length > 0) {
        resolvedRegisteredUsers = extraRegisteredUsers;
        try {
          window.localStorage.setItem(
            'timeto_cached_registered_users_v1',
            JSON.stringify(extraRegisteredUsers)
          );
        } catch {
          // ignore
        }
      } else {
        try {
          const cachedUsersRaw = window.localStorage.getItem(
            'timeto_cached_registered_users_v1'
          );
          if (cachedUsersRaw) {
            resolvedRegisteredUsers = JSON.parse(cachedUsersRaw);
          }
        } catch {
          // ignore
        }
      }

      const usedSlugs = new Set<string>();
      const ensureUniqueSlug = (rawSlug: string, fallbackId: string): string => {
        const base = (rawSlug || fallbackId || 'salon')
          .trim()
          .replace(/\s+/g, '-');
        if (!usedSlugs.has(base)) {
          usedSlugs.add(base);
          return base;
        }
        const unique = `${base}-${fallbackId.slice(-4)}`;
        usedSlugs.add(unique);
        return unique;
      };

      const applyLiveDayCounters = (item: BusinessItem): BusinessItem => {
        const nowMs = Date.now();
        let next = {
          ...item,
          trialDaysRemaining: undefined,
        };
        if (next.sponsoredExpiresAtMs && next.sponsoredExpiresAtMs > 0) {
          const remSponDays = Math.max(
            0,
            Math.ceil((next.sponsoredExpiresAtMs - nowMs) / (24 * 60 * 60 * 1000))
          );
          next.sponsoredDaysRemaining = remSponDays;
          if (remSponDays === 0) {
            next.isSponsored = false;
          }
        }
        return next;
      };

      const isBlockedTestOrDeletedSalon = (
        nameRaw?: string,
        slugRaw?: string,
        idRaw?: string
      ): boolean => {
        const idStr = String(idRaw || '').trim();
        if (
          excludedSampleIds.has(idStr) ||
          permDeletedIds.has(idStr) ||
          /^biz-[1-8]$/.test(idStr)
        ) {
          return true;
        }
        const slugStr = String(slugRaw || '').trim().toLowerCase();
        if (
          slugStr === 'royal-golzar' ||
          slugStr === 'royal-golzar-isfahan' ||
          slugStr === 'atelier-soren-tehran' ||
          permDeletedIds.has(slugStr)
        ) {
          return true;
        }
        const nameStr = String(nameRaw || '').trim();
        if (!nameStr) return true;
        if (
          permDeletedIds.has(nameStr) ||
          nameStr.includes('سالن شیر') ||
          nameStr.includes('سالن زیبایی شیر') ||
          nameStr.includes('سالن ارکیده') ||
          nameStr.includes('سالن زیبایی ارکیده') ||
          nameStr.includes('رویال گلزار') ||
          nameStr.includes('مریم فرهادی') ||
          nameStr === 'شیر' ||
          nameStr === 'ارکیده'
        ) {
          return true;
        }
        return false;
      };

      const byIdOrSlug = new Map<string, BusinessItem>();
      const hasServerList = list.length > 0;
      const todayJalaliStr = getUpcomingJalaliDays(1)[0]?.dateJalali || '۱۴۰۵/۰۸/۲۷';

      for (const b of list) {
        if (
          !b ||
          b.isSampleShowcase ||
          isBlockedTestOrDeletedSalon(b.name, b.slug, b.id)
        ) {
          continue;
        }
        const rawOv = overrides[b.id] || overrides[b.slug] || {};
        const {
          walletBalanceToman: _ignoredWalletOv,
          ...safeOv
        } = rawOv as Partial<BusinessItem>;
        const isJaziniSalon =
          !String(b.name || '').includes('مهتاب') &&
          !String(b.ownerName || '').includes('مهتاب') &&
          (String(b.name || '').includes('امیرحسین') ||
            String(b.name || '').includes('امیر حسین') ||
            String(b.ownerName || '').includes('امیرحسین') ||
            String(b.ownerName || '').includes('امیر حسین') ||
            String(b.name || '').includes('جزینی') ||
            String(b.slug || '').toLowerCase().includes('jazini'));
        const isMahtabRejected =
          String(b.name || '').includes('مهتاب جزینی') ||
          String(b.ownerName || '').includes('مهتاب جزینی') ||
          String(b.name || '').includes('مهتاب');

        const rawMerged: BusinessItem = {
          ...safeOv,
          ...b,
          name: b.name || safeOv.name || 'سالن زیبایی',
          city: b.city || safeOv.city || 'اصفهان',
          neighborhood: b.neighborhood || safeOv.neighborhood || 'چهارباغ بالا',
          address: b.address || safeOv.address || 'اصفهان',
          ownerName: b.ownerName || safeOv.ownerName,
          ownerPhone: b.ownerPhone || safeOv.ownerPhone || b.phoneDisplay,
          depositEnabled: isJaziniSalon
            ? true
            : typeof b.depositEnabled === 'boolean'
              ? b.depositEnabled
              : safeOv.depositEnabled,
          depositPercent: isJaziniSalon
            ? 30
            : typeof b.depositPercent === 'number' &&
                b.depositPercent >= 1 &&
                b.depositPercent <= 100
              ? normalizeDepositPercent(b.depositPercent)
              : safeOv.depositPercent !== undefined
                ? normalizeDepositPercent(safeOv.depositPercent)
                : undefined,
          isVipPartner:
            typeof b.isVipPartner === 'boolean'
              ? b.isVipPartner
              : safeOv.isVipPartner,
          vipCommissionPercent:
            typeof b.vipCommissionPercent === 'number'
              ? b.vipCommissionPercent
              : safeOv.vipCommissionPercent,
          bankShebaNumber: b.bankShebaNumber || safeOv.bankShebaNumber,
          bankCardNumber: b.bankCardNumber || safeOv.bankCardNumber,
          bankAccountHolder: b.bankAccountHolder || safeOv.bankAccountHolder,
          contractAccepted:
            typeof b.contractAccepted === 'boolean'
              ? b.contractAccepted
              : safeOv.contractAccepted,
          contractAcceptedAtJalali:
            b.contractAcceptedAtJalali || safeOv.contractAcceptedAtJalali,
          trialDaysRemaining: undefined,
          isSampleShowcase: false,
        };
        if (
          isBlockedTestOrDeletedSalon(
            rawMerged.name,
            rawMerged.slug,
            rawMerged.id
          )
        ) {
          continue;
        }

        const cleanOwnerPhone = toEnglishDigitsClient(
          String(rawMerged.ownerPhone || rawMerged.phoneDisplay || '')
        ).replace(/\D/g, '');
        const matchedRegUser = resolvedRegisteredUsers.find((u) => {
          const uPhone = toEnglishDigitsClient(
            String(u.phone || u.phoneMasked || '')
          ).replace(/\D/g, '');
          return (
            (cleanOwnerPhone && uPhone === cleanOwnerPhone) ||
            (u.fullName && rawMerged.ownerName && u.fullName.trim() === rawMerged.ownerName.trim())
          );
        });

        const candidateDateStr = String(
          b.createdAtJalali ||
            matchedRegUser?.joinedJalali ||
            safeOv.createdAtJalali ||
            rawMerged.createdAtJalali ||
            ''
        ).trim();
        const rawCreatedEng = toEnglishDigitsClient(candidateDateStr);
        const isFakeDate =
          !rawCreatedEng ||
          rawCreatedEng === 'امروز' ||
          rawCreatedEng === 'جدید' ||
          rawCreatedEng === 'ثبت جدید' ||
          rawCreatedEng.startsWith('1405/08/05') ||
          rawCreatedEng.startsWith('1405/08/01') ||
          rawCreatedEng.startsWith('1405/07/') ||
          rawCreatedEng.startsWith('202');
        const fixedCreatedJalali = isFakeDate
          ? matchedRegUser?.joinedJalali &&
            !toEnglishDigitsClient(matchedRegUser.joinedJalali).startsWith('1405/08/05')
            ? matchedRegUser.joinedJalali
            : todayJalaliStr
          : candidateDateStr;

        const merged: BusinessItem = applyLiveDayCounters({
          ...rawMerged,
          createdAtJalali: fixedCreatedJalali,
          slug: ensureUniqueSlug(rawMerged.slug, b.id),
          approvalStatus: isMahtabRejected
            ? 'REJECTED'
            : b.approvalStatus === 'REJECTED' || safeOv.approvalStatus === 'REJECTED'
              ? 'REJECTED'
              : b.approvalStatus === 'APPROVED'
                ? 'APPROVED'
                : b.approvalStatus === 'PENDING_REVIEW'
                  ? 'PENDING_REVIEW'
                  : 'APPROVED',
        });
        byIdOrSlug.set(b.id, merged);
      }

      // وقتی لیست سرور از دیتابیس دریافت شده، حافظه محلی را با لیست سرور همگام می‌کنیم تا موبایل و دسکتاپ صددرصد یکسان باشند
      if (hasServerList) {
        try {
          window.localStorage.setItem(
            'timeto_local_onboarded_businesses_v1',
            JSON.stringify(
              Array.from(byIdOrSlug.values()).filter(
                (x) => x.approvalStatus !== 'REJECTED'
              )
            )
          );
        } catch {
          // ignore
        }
      } else {
        // فقط قبل از دریافت پاسخ سرور، از کش محلی استفاده کن (بدون سالن‌های رد صلاحیت‌شده مثل مهتاب جزینی)
        for (const lb of localOnbList) {
          if (
            !lb ||
            lb.isSampleShowcase ||
            isBlockedTestOrDeletedSalon(lb.name, lb.slug, lb.id) ||
            String(lb.name || '').includes('مهتاب') ||
            String(lb.ownerName || '').includes('مهتاب') ||
            lb.approvalStatus === 'REJECTED'
          ) {
            continue;
          }
          const alreadyExists = Array.from(byIdOrSlug.values()).some(
            (x) =>
              x.id === lb.id ||
              x.slug === lb.slug ||
              (x.name.trim() === lb.name.trim() && !x.isSampleShowcase)
          );
          if (!alreadyExists) {
            const rawMergedLb = overrides[lb.id]
              ? { ...lb, ...overrides[lb.id] }
              : lb;
            if (
              isBlockedTestOrDeletedSalon(
                rawMergedLb.name,
                rawMergedLb.slug,
                rawMergedLb.id
              ) ||
              rawMergedLb.approvalStatus === 'REJECTED'
            ) {
              continue;
            }
            const mergedLb: BusinessItem = applyLiveDayCounters({
              ...rawMergedLb,
              city: rawMergedLb.city || 'اصفهان',
              neighborhood: rawMergedLb.neighborhood || 'چهارباغ بالا',
              rating: Number(rawMergedLb.rating) || 5.0,
              startingPriceToman: Number(rawMergedLb.startingPriceToman) || 0,
              approvalStatus:
                rawMergedLb.approvalStatus === 'PENDING_REVIEW'
                  ? 'PENDING_REVIEW'
                  : 'APPROVED',
            });
            byIdOrSlug.set(lb.id, mergedLb);
          }
        }
      }

      return Array.from(byIdOrSlug.values());
    } catch {
      return list.filter(
        (b) =>
          b &&
          !b.isSampleShowcase &&
          !/^biz-[1-8]$/.test(b.id) &&
          !String(b.name || '').includes('سالن شیر') &&
          !String(b.name || '').includes('سالن ارکیده')
      );
    }
  };

  const [businesses, setBusinesses] = useState<BusinessItem[]>(() =>
    mergeBusinessOverrides([])
  );
  const applySavedServiceSortOrder = (list: ServiceItem[]): ServiceItem[] => {
    try {
      const rawOrder = window.localStorage.getItem('timeto_service_sort_order_v1');
      if (!rawOrder) return list;
      const orderMap = JSON.parse(rawOrder) as Record<string, number>;
      if (!orderMap || typeof orderMap !== 'object') return list;
      const withOrder = list.map((srv, idx) => ({
        ...srv,
        sortOrder:
          typeof orderMap[srv.id] === 'number'
            ? orderMap[srv.id]
            : typeof srv.sortOrder === 'number'
              ? srv.sortOrder
              : 10000 + idx,
      }));
      return [...withOrder].sort(
        (a, b) => (a.sortOrder ?? 10000) - (b.sortOrder ?? 10000)
      );
    } catch {
      return list;
    }
  };

  const [services, setServices] = useState<ServiceItem[]>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_local_services_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return applySavedServiceSortOrder(parsed);
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [specialists, setSpecialists] = useState<SpecialistItem[]>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_local_specialists_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter(
            (sp: SpecialistItem) =>
              sp &&
              sp.id &&
              !/^spc-[1-8]$/.test(sp.id) &&
              sp.fullName?.trim() !== 'مریم فرهادی'
          );
        }
      }
    } catch {
      // ignore
    }
    return SAMPLE_SPECIALISTS;
  });
  const syncStartingPricesWithServices = (
    bizList: BusinessItem[],
    srvList: ServiceItem[]
  ): BusinessItem[] => {
    return bizList.map((b) => {
      const bizPrices = srvList
        .filter(
          (s) =>
            s &&
            s.isActive !== false &&
            s.priceToman > 0 &&
            (s.businessId === b.id || s.businessId === b.slug)
        )
        .map((s) => Number(s.priceToman));
      if (bizPrices.length === 0) return b;
      const minPrice = Math.min(...bizPrices);
      if (b.startingPriceToman === minPrice) return b;
      return { ...b, startingPriceToman: minPrice };
    });
  };

  const mergeSavedAppointments = (
    incoming: AppointmentItem[],
    bizLookup?: BusinessItem[],
    authoritativeFromServer?: boolean
  ): AppointmentItem[] => {
    try {
      const bizPool = bizLookup && bizLookup.length > 0 ? bizLookup : businesses;
      const savedRaw = window.localStorage.getItem('timeto_saved_appointments_v1');
      const savedList: AppointmentItem[] = savedRaw ? JSON.parse(savedRaw) : [];
      const map = new Map<string, AppointmentItem>();
      const isInvalidOrRejectedApt = (item: AppointmentItem) => {
        if (
          !item ||
          !item.id ||
          /^biz-[1-8]$/.test(item.businessId) ||
          /^apt-100[1-9]$/.test(item.id) ||
          item.businessSlug === 'royal-golzar' ||
          String(item.businessName || '').includes('مهتاب')
        ) {
          return true;
        }
        const matchedBiz = bizPool.find(
          (b) =>
            b.id === item.businessId ||
            b.slug === item.businessSlug ||
            b.name === item.businessName
        );
        if (
          matchedBiz &&
          (matchedBiz.approvalStatus === 'REJECTED' ||
            String(matchedBiz.name || '').includes('مهتاب') ||
            String(matchedBiz.ownerName || '').includes('مهتاب'))
        ) {
          return true;
        }
        return false;
      };
      const normalizeAptFinancials = (item: AppointmentItem): AppointmentItem => {
        const matchedBiz = bizPool.find(
          (b) =>
            b.id === item.businessId ||
            b.slug === item.businessSlug ||
            b.name === item.businessName
        );
        const isAmirJaziniApt =
          !String(item.businessName || '').includes('مهتاب') &&
          !String(matchedBiz?.name || '').includes('مهتاب') &&
          (String(item.businessName || '').includes('امیرحسین') ||
            String(item.businessName || '').includes('امیر حسین') ||
            String(item.businessName || '').includes('جزینی') ||
            String(matchedBiz?.name || '').includes('امیرحسین') ||
            String(matchedBiz?.name || '').includes('امیر حسین') ||
            String(matchedBiz?.name || '').includes('جزینی') ||
            String(matchedBiz?.ownerName || '').includes('امیرحسین') ||
            String(matchedBiz?.ownerName || '').includes('امیر حسین'));

        const normalizedInputApt: AppointmentItem = isAmirJaziniApt
          ? {
              ...item,
              priceToman: 400_000,
              depositPaidToman: 120_000,
            }
          : item;
        const normalizedBizForApt: BusinessItem | undefined =
          isAmirJaziniApt && matchedBiz
            ? {
                ...matchedBiz,
                depositEnabled: true,
                depositPercent: 30,
              }
            : matchedBiz;

        const resolved = resolveAppointmentFinancialBreakdown({
          appointment: normalizedInputApt,
          business: normalizedBizForApt,
        });
        const fixedItem: AppointmentItem = {
          ...normalizedInputApt,
          priceToman: resolved.totalServicePriceToman,
          depositPaidToman: resolved.baseDepositToman,
          platformCommissionToman: resolved.platformCommissionToman,
          customerGatewayAndTaxFeeToman: resolved.customerGatewayAndTaxFeeToman,
          salonNetDepositCreditedToman: resolved.salonNetDepositCreditedToman,
        };
        if (
          fixedItem.specialistName === 'مریم فرهادی' ||
          fixedItem.specialistId === 'spc-1'
        ) {
          const cleanOwner =
            matchedBiz?.ownerName &&
            matchedBiz.ownerName.trim() !== 'مریم فرهادی'
              ? matchedBiz.ownerName.trim()
              : matchedBiz?.name || fixedItem.businessName || 'متخصص مرکز';
          return {
            ...fixedItem,
            specialistName: cleanOwner,
          };
        }
        return fixedItem;
      };
      for (const item of incoming) {
        if (!isInvalidOrRejectedApt(item)) {
          map.set(item.id, normalizeAptFinancials(item));
        }
      }
      if (!authoritativeFromServer) {
        for (const item of savedList) {
          if (!isInvalidOrRejectedApt(item)) {
            const existing = map.get(item.id);
            const merged: AppointmentItem = existing
              ? {
                  ...item,
                  ...existing,
                  depositPaidToman:
                    existing.depositPaidToman && existing.depositPaidToman > 0
                      ? existing.depositPaidToman
                      : item.depositPaidToman,
                  paymentMethod: existing.paymentMethod || item.paymentMethod,
                  paymentTrackingCode:
                    existing.paymentTrackingCode || item.paymentTrackingCode,
                  inPersonSettled:
                    existing.inPersonSettled ?? item.inPersonSettled,
                  inPersonSettledAmountToman:
                    existing.inPersonSettledAmountToman ??
                    item.inPersonSettledAmountToman,
                  inPersonSettledAtJalali:
                    existing.inPersonSettledAtJalali ??
                    item.inPersonSettledAtJalali,
                }
              : item;
            map.set(item.id, normalizeAptFinancials(merged));
          }
        }
      }
      return Array.from(map.values());
    } catch {
      return incoming;
    }
  };

  const persistSavedAppointments = (list: AppointmentItem[]) => {
    try {
      window.localStorage.setItem(
        'timeto_saved_appointments_v1',
        JSON.stringify(list)
      );
    } catch {
      // ignore
    }
  };

  const [appointments, setAppointments] = useState<AppointmentItem[]>(() =>
    mergeSavedAppointments([])
  );
  const mergeCategoriesWithDefaults = (
    incoming: CategoryItem[]
  ): CategoryItem[] => {
    let baseList: CategoryItem[] = [...SAMPLE_CATEGORIES];
    try {
      const savedRaw = window.localStorage.getItem('timeto_custom_categories_v2');
      if (savedRaw) {
        const savedList: CategoryItem[] = JSON.parse(savedRaw);
        if (Array.isArray(savedList) && savedList.length > 0) {
          const bySlug = new Set(savedList.map((c) => c.slug));
          const missingDefaults = SAMPLE_CATEGORIES.filter(
            (c) => !bySlug.has(c.slug)
          );
          baseList = [...savedList, ...missingDefaults];
        }
      }
    } catch {
      // ignore
    }

    const result: CategoryItem[] = [...baseList];
    for (const dbCat of incoming) {
      const idx = result.findIndex(
        (c) => c.slug === dbCat.slug || c.title === dbCat.title
      );
      if (idx >= 0) {
        result[idx] = {
          ...result[idx],
          ...dbCat,
          iconName: dbCat.iconName || result[idx].iconName || 'Sparkles',
        };
      } else {
        result.push(dbCat);
      }
    }
    return result;
  };

  const [categories, setCategories] = useState<CategoryItem[]>(() =>
    mergeCategoriesWithDefaults(SAMPLE_CATEGORIES)
  );
  const mergeSavedGallery = (baseList: GalleryItem[]): GalleryItem[] => {
    try {
      const savedRaw = window.localStorage.getItem('timeto_saved_gallery_v1');
      const deletedRaw = window.localStorage.getItem(
        'timeto_deleted_gallery_ids_v1'
      );
      const savedList: GalleryItem[] = savedRaw ? JSON.parse(savedRaw) : [];
      const deletedSet = new Set<string>(
        deletedRaw ? JSON.parse(deletedRaw) : []
      );
      const map = new Map<string, GalleryItem>();
      for (const g of baseList) {
        if (g && g.id && !deletedSet.has(g.id) && !/^biz-[1-8]$/.test(g.businessId)) {
          map.set(g.id, g);
        }
      }
      if (Array.isArray(savedList)) {
        for (const sg of savedList) {
          if (sg && sg.id && !deletedSet.has(sg.id)) {
            const existing = map.get(sg.id);
            map.set(sg.id, existing ? { ...existing, ...sg } : sg);
          }
        }
      }
      return Array.from(map.values());
    } catch {
      return baseList;
    }
  };

  const [gallery, setGallery] = useState<GalleryItem[]>(() =>
    mergeSavedGallery(SAMPLE_GALLERY)
  );
  const [campaigns, setCampaigns] = useState<MarketingCampaignItem[]>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_saved_campaigns_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });

  const mergeManualCustomers = (baseList: CustomerRecord[]): CustomerRecord[] => {
    try {
      const savedRaw = window.localStorage.getItem('timeto_manual_customers_v1');
      const deletedRaw = window.localStorage.getItem(
        'timeto_deleted_customer_ids_v1'
      );
      const savedList: CustomerRecord[] = savedRaw ? JSON.parse(savedRaw) : [];
      const deletedIds = new Set<string>(
        deletedRaw ? JSON.parse(deletedRaw) : []
      );
      const map = new Map<string, CustomerRecord>();
      for (const item of baseList) {
        if (!deletedIds.has(item.id)) {
          map.set(item.id, item);
        }
      }
      for (const item of savedList) {
        if (item && item.id && !deletedIds.has(item.id)) {
          map.set(item.id, item);
        }
      }
      return Array.from(map.values());
    } catch {
      return baseList;
    }
  };

  const [customers, setCustomers] = useState<CustomerRecord[]>(() =>
    mergeManualCustomers([])
  );
  const [rawAdminUsers, setAdminUsers] = useState<AdminUserRecord[]>([]);
  const [accountsRevision, setAccountsRevision] = useState<number>(0);
  const [ownedBusinessId, setOwnedBusinessId] = useState<string | null>(() => {
    try {
      return window.localStorage.getItem('timeto_owned_business_id_v1');
    } catch {
      return null;
    }
  });
  const [reviews, setReviews] = useState<ReviewItem[]>(SAMPLE_REVIEWS);
  const [plans, setPlans] = useState<SubscriptionPlanItem[]>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_custom_plans_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return SAMPLE_SUBSCRIPTION_PLANS;
  });
  const [adPackages, setAdPackages] = useState<AdPackageItem[]>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_custom_ad_packages_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return SAMPLE_AD_PACKAGES;
  });
  const [paymentConfig, setPaymentConfig] = useState<PaymentGatewayConfig>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_payment_config_v2');
      if (saved) {
        return { ...DEFAULT_PAYMENT_GATEWAY_CONFIG, ...JSON.parse(saved) };
      }
    } catch {
      // ignore storage errors
    }
    return DEFAULT_PAYMENT_GATEWAY_CONFIG;
  });
  const [paymentOrders, setPaymentOrders] = useState<PaymentOrderItem[]>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_payment_orders_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore storage errors
    }
    return [];
  });
  const [smsLogs, setSmsLogs] = useState<SmsMessageLogItem[]>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_sms_logs_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [adminNotifications, setAdminNotifications] = useState<
    AdminNotificationItem[]
  >(() => {
    try {
      const saved = window.localStorage.getItem('timeto_admin_notifications_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [adminNotificationSettings, setAdminNotificationSettings] =
    useState<AdminNotificationSettings>(() => {
      const defaults: AdminNotificationSettings = {
        adminPhone: '09138201042',
        adminUsername: 'admin',
        adminDisplayName: 'مدیر کل تایم تو',
        smsOnNewBusiness: true,
        smsOnNewPaymentOrder: true,
        smsOnNewBooking: true,
        inAppNotificationsEnabled: true,
      };
      try {
        const saved = window.localStorage.getItem(
          'timeto_admin_notify_settings_v1'
        );
        if (saved) {
          return { ...defaults, ...JSON.parse(saved) };
        }
      } catch {
        // ignore
      }
      return defaults;
    });
  const [supportTickets, setSupportTickets] = useState<SupportTicketItem[]>(
    () => {
      try {
        const saved = window.localStorage.getItem('timeto_support_tickets_v1');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {
        // ignore
      }
      return [];
    }
  );
  const [platformBusinessNotices, setPlatformBusinessNotices] = useState<
    PlatformBusinessNoticeItem[]
  >(() => {
    try {
      const saved = window.localStorage.getItem(
        'timeto_platform_business_notices_v1'
      );
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [settlementRequests, setSettlementRequests] = useState<
    SettlementRequestItem[]
  >(() => {
    try {
      const saved = window.localStorage.getItem(
        'timeto_settlement_requests_v1'
      );
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });
  const [dailyIncomeLogs, setDailyIncomeLogs] = useState<DailyIncomeLogItem[]>(
    () => {
      try {
        const saved = window.localStorage.getItem(
          'timeto_daily_income_logs_v1'
        );
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {
        // ignore
      }
      return [];
    }
  );
  const [adminReviewedBizIds, setAdminReviewedBizIds] = useState<string[]>(
    () => {
      try {
        const saved = window.localStorage.getItem(
          'timeto_admin_reviewed_biz_ids_v1'
        );
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {
        // ignore
      }
      return [];
    }
  );
  const [activePlanId, setActivePlanId] = useState<string>('plan-free-start');
  const [onboardingDraft, setOnboardingDraft] = useState<OnboardingDraft>(
    INITIAL_ONBOARDING_DRAFT
  );
  const [bookingDraft, setBookingDraft] = useState<BookingDraft>(() => {
    try {
      const saved = window.localStorage.getItem('timeto_booking_draft_v2');
      if (saved) {
        const parsed = JSON.parse(saved) as Partial<BookingDraft>;
        if (parsed && typeof parsed === 'object') {
          return { ...INITIAL_BOOKING_DRAFT, ...parsed };
        }
      }
    } catch {
      // ignore
    }
    return INITIAL_BOOKING_DRAFT;
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(
        'timeto_booking_draft_v2',
        JSON.stringify(bookingDraft)
      );
    } catch {
      // ignore
    }
  }, [bookingDraft]);

  useEffect(() => {
    fetch('/api/v1/payments/zibal/config')
      .then((res) => (res.ok ? res.json() : null))
      .then(
        (
          data: {
            merchantId?: string;
            isCustomMerchant?: boolean;
          } | null
        ) => {
          if (data?.isCustomMerchant && data.merchantId) {
            setPaymentConfig((prev) => {
              if (prev.zibalMerchantId === data.merchantId) return prev;
              const next = {
                ...prev,
                zibalMerchantId: data.merchantId,
                zarinpalMerchantId: data.merchantId,
              };
              try {
                window.localStorage.setItem(
                  'timeto_payment_config_v2',
                  JSON.stringify(next)
                );
              } catch {
                // ignore
              }
              return next;
            });
          } else if (
            paymentConfig.zibalMerchantId &&
            paymentConfig.zibalMerchantId !== 'zibal'
          ) {
            fetch('/api/v1/payments/zibal/config', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                merchantId: paymentConfig.zibalMerchantId,
              }),
            }).catch(() => {});
          }
        }
      )
      .catch(() => {});
  }, []);

  const [toast, setToast] = useState<ToastNotice | null>(null);

  const showToast = (
    message: string,
    tone: 'success' | 'info' | 'warning' | 'danger' = 'success'
  ) => {
    setToast({ id: Date.now(), message, tone });
  };

  const dismissToast = () => setToast(null);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => {
      setToast(null);
    }, 3200);
    return () => window.clearTimeout(timer);
  }, [toast?.id]);

  const currentBusiness: BusinessItem | null = React.useMemo(() => {
    if (ownedBusinessId) {
      const foundOwned = businesses.find((b) => b.id === ownedBusinessId);
      if (foundOwned && !foundOwned.isSampleShowcase) return foundOwned;
    }
    const firstMembership = authUser?.businessMemberships?.[0];
    if (firstMembership) {
      const foundMemberBiz = businesses.find(
        (b) =>
          b.id === firstMembership.businessId ||
          b.slug === firstMembership.businessSlug ||
          b.id === firstMembership.businessUuid
      );
      if (foundMemberBiz && !foundMemberBiz.isSampleShowcase)
        return foundMemberBiz;
    }
    const nonSampleBiz = businesses.find(
      (b) => !b.isSampleShowcase && !/^biz-[1-8]$/.test(b.id)
    );
    if (nonSampleBiz) return nonSampleBiz;

    let overrides: Record<string, Partial<BusinessItem>> = {};
    try {
      const overridesRaw = window.localStorage.getItem('timeto_biz_overrides_v2');
      if (overridesRaw) overrides = JSON.parse(overridesRaw);
    } catch {
      // ignore
    }

    const zeroBiz: BusinessItem = {
      id: 'biz-owner-zero',
      slug: 'my-salon-workspace',
      name: authUser?.fullName
        ? `سالن زیبایی ${authUser.fullName}`
        : 'سالن زیبایی من',
      type: BusinessType.WomenSalon,
      typeLabel: 'سالن زیبایی زنانه',
      categorySlug: 'hair-color',
      city: authUser?.defaultCity || 'اصفهان',
      neighborhood: '',
      address: '',
      phoneDisplay: authUser?.phone || '',
      ownerName: authUser?.fullName || 'مدیر سالن',
      ownerPhone: authUser?.phone || '',
      createdAtJalali: 'امروز',
      rating: 5.0,
      reviewCount: 0,
      startingPriceToman: 0,
      shortDescription: '',
      aboutText: '',
      verifiedBadge: true,
      approvalStatus: 'APPROVED',
      subscriptionPlan: 'شروع رایگان',
      subscriptionStatus: SubscriptionStatus.Trial,
      trialDaysRemaining: 30,
      extraSmsBalance: 0,
      smsSentCount: 0,
      workingHours: INITIAL_ONBOARDING_DRAFT.workingHours,
      workingHoursConfigured: false,
      visualTheme: 'violet',
      featured: false,
      isSampleShowcase: false,
      ...(overrides['biz-owner-zero'] || {}),
    };
    return zeroBiz;
  }, [ownedBusinessId, authUser, businesses]);

  const loadAuthenticatedRoleData = async (
    currentUser: AuthenticatedSessionUser
  ) => {
    try {
      const meRes = await realApiClient.fetchCustomerBootstrap();
      setFavoriteBusinessIds(meRes.data.favoriteBusinessIds);
      setAppointments((prev) =>
        mergeSavedAppointments([...meRes.data.appointments, ...prev])
      );
    } catch {
      // ادامه در صورت نبود داده مشتری
    }

    let latestLoadedServices: ServiceItem[] = [];
    if (currentUser.roles.includes('BUSINESS_OWNER')) {
      try {
        const wsRes = await realApiClient.fetchBusinessWorkspace();
        const ownedBiz = wsRes.data.business;
        if (ownedBiz) {
          setOwnedBusinessId(ownedBiz.id);
        }

        const srvMap = new Map<string, ServiceItem>();
        for (const s of wsRes.data.services) {
          srvMap.set(s.id, s);
        }
        const mergedServicesList = applySavedServiceSortOrder(
          Array.from(srvMap.values())
        );
        latestLoadedServices = mergedServicesList;
        setServices(mergedServicesList);

        let updatedBusinessesSnapshot: BusinessItem[] = businesses;
        setBusinesses((prev) => {
          const map = new Map(prev.map((b) => [b.id, b]));
          if (ownedBiz) {
            map.set(ownedBiz.id, ownedBiz);
          }
          const synced = syncStartingPricesWithServices(
            Array.from(map.values()),
            mergedServicesList
          );
          updatedBusinessesSnapshot = synced;
          return synced;
        });
        const freshBizPool = ownedBiz
          ? [
              ownedBiz,
              ...updatedBusinessesSnapshot.filter((b) => b.id !== ownedBiz.id),
            ]
          : updatedBusinessesSnapshot;

        setSpecialists((prev) => {
          const map = new Map(prev.map((sp) => [sp.id, sp]));
          for (const sp of wsRes.data.specialists) {
            map.set(sp.id, sp);
          }
          return Array.from(map.values());
        });
        setGallery((prev) =>
          mergeSavedGallery([...wsRes.data.gallery, ...prev])
        );
        setAppointments((prev) =>
          mergeSavedAppointments(
            [...wsRes.data.appointments, ...prev],
            freshBizPool,
            true
          )
        );
        setCustomers(mergeManualCustomers(wsRes.data.customers));
        setCampaigns(wsRes.data.campaigns);
      } catch {
        // در صورت عدم دسترسی یا نبود کسب‌وکار، مشتریان ثبت‌شده دستی حفظ می‌شوند
        setCustomers((prev) => mergeManualCustomers(prev));
      }
    }

    if (currentUser.roles.includes('PLATFORM_ADMIN')) {
      try {
        const adminRes = await realApiClient.fetchAdminOverview();
        const syncedAdminBusinesses = syncStartingPricesWithServices(
          mergeBusinessOverrides(
            adminRes.data.businesses,
            adminRes.data.users,
            true
          ),
          latestLoadedServices.length > 0 ? latestLoadedServices : services
        );
        setBusinesses(syncedAdminBusinesses);
        setCategories(mergeCategoriesWithDefaults(adminRes.data.categories));
        if (
          adminRes.data.plans.length > 0 &&
          !window.localStorage.getItem('timeto_custom_plans_v2')
        ) {
          setPlans(adminRes.data.plans);
        }
        if (Array.isArray(adminRes.data.users)) {
          setAdminUsers(adminRes.data.users);
        }
        if (Array.isArray(adminRes.data.appointments)) {
          const adminAppointments = adminRes.data.appointments;
          setAppointments(() => {
            const authoritativeApts = mergeSavedAppointments(
              adminAppointments,
              syncedAdminBusinesses,
              true
            );
            persistSavedAppointments(authoritativeApts);
            return authoritativeApts;
          });
        }
        if (Array.isArray(adminRes.adminNotifications)) {
          setAdminNotifications((prev) => {
            const byId = new Map<string, AdminNotificationItem>();
            for (const item of adminRes.adminNotifications as AdminNotificationItem[]) {
              if (item && item.id) byId.set(item.id, item);
            }
            for (const p of prev) {
              if (!byId.has(p.id)) byId.set(p.id, p);
            }
            const merged = Array.from(byId.values());
            try {
              window.localStorage.setItem(
                'timeto_admin_notifications_v1',
                JSON.stringify(merged)
              );
            } catch {
              // ignore
            }
            return merged;
          });
        }
      } catch {
        // عدم دسترسی ادمین
      }
    }
  };

  const getPersistedSessionUser = (): AuthenticatedSessionUser | null => {
    try {
      const saved = window.localStorage.getItem(PERSISTED_SESSION_USER_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.phone && Array.isArray(parsed.roles)) {
          return parsed as AuthenticatedSessionUser;
        }
      }
    } catch {
      // ignore
    }
    return null;
  };

  const refreshRealData = async () => {
    setIsLoadingInitialData(true);
    const localPersistedUser = getPersistedSessionUser();
    const localOwnedBizId = (() => {
      try {
        return window.localStorage.getItem('timeto_owned_business_id_v1');
      } catch {
        return null;
      }
    })();

    try {
      const [response, sharedRes] = await Promise.all([
        realApiClient.fetchBootstrap(),
        realApiClient.fetchPlatformSharedState().catch(() => ({ data: undefined })),
      ]);
      const sharedData = sharedRes?.data;
      if (response.mode === 'real' && response.data) {
        setDataMode('real');
        setDatabaseError(null);
        setCategories(mergeCategoriesWithDefaults(response.data.categories));

        const nextServices = (() => {
          const map = new Map<string, ServiceItem>();
          for (const s of response.data!.services) {
            if (
              s &&
              s.id &&
              !/^biz-[1-8]$/.test(s.businessId) &&
              !/^srv-[1-8]\d\d$/.test(s.id)
            ) {
              map.set(s.id, s);
            }
          }
          const resolvedSrvs = applySavedServiceSortOrder(
            Array.from(map.values())
          );
          try {
            window.localStorage.setItem(
              'timeto_local_services_v1',
              JSON.stringify(resolvedSrvs)
            );
          } catch {
            // ignore
          }
          return resolvedSrvs;
        })();
        setServices(nextServices);

        const nextBusinesses = syncStartingPricesWithServices(
          mergeBusinessOverrides(
            response.data.businesses,
            response.data.registeredUsers,
            true
          ),
          nextServices
        );
        setBusinesses(nextBusinesses);

        setSpecialists(() => {
          const map = new Map<string, SpecialistItem>();
          for (const sp of response.data!.specialists) {
            if (
              sp &&
              sp.id &&
              !/^biz-[1-8]$/.test(sp.businessId) &&
              !/^spc-[1-8]$/.test(sp.id) &&
              sp.fullName?.trim() !== 'مریم فرهادی'
            ) {
              map.set(sp.id, sp);
            }
          }
          const resolvedSpcs = Array.from(map.values());
          try {
            window.localStorage.setItem(
              'timeto_local_specialists_v1',
              JSON.stringify(resolvedSpcs)
            );
          } catch {
            // ignore
          }
          return resolvedSpcs;
        });
        setReviews(() => {
          let deletedRevIds = new Set<string>();
          let localRevs: ReviewItem[] = [];
          let revMeta: Record<string, Partial<ReviewItem>> = {};
          try {
            const delRaw =
              window.localStorage.getItem('timeto_deleted_review_ids_v1') || '[]';
            deletedRevIds = new Set<string>(JSON.parse(delRaw));
            const savedRaw =
              window.localStorage.getItem('timeto_local_reviews_v1') || '[]';
            localRevs = JSON.parse(savedRaw);
            const metaRaw =
              window.localStorage.getItem('timeto_review_moderation_meta_v1') ||
              '{}';
            revMeta = JSON.parse(metaRaw);
          } catch {
            // ignore
          }
          const map = new Map<string, ReviewItem>();
          for (const r of response.data!.reviews) {
            if (
              r &&
              r.id &&
              !deletedRevIds.has(r.id) &&
              !/^biz-[1-8]$/.test(r.businessId) &&
              !/^rev-[1-8]$/.test(r.id)
            ) {
              map.set(r.id, { ...r, ...(revMeta[r.id] || {}) });
            }
          }
          for (const r of localRevs) {
            if (
              r &&
              r.id &&
              !deletedRevIds.has(r.id) &&
              !/^biz-[1-8]$/.test(r.businessId)
            ) {
              map.set(r.id, { ...r, ...(revMeta[r.id] || {}) });
            }
          }
          return Array.from(map.values());
        });
        setGallery(() => mergeSavedGallery(response.data!.gallery || []));
        if (
          response.data.plans.length > 0 &&
          !window.localStorage.getItem('timeto_custom_plans_v2')
        ) {
          setPlans(response.data.plans);
        }

        const serverApts = Array.isArray(response.data.appointments)
          ? response.data.appointments
          : [];
        setAppointments(() => {
          const mergedApts = mergeSavedAppointments(
            serverApts,
            nextBusinesses,
            true
          );
          persistSavedAppointments(mergedApts);
          return mergedApts;
        });

        const resolvedPaymentConfig =
          sharedData?.paymentConfig || response.data.paymentConfig;
        if (
          resolvedPaymentConfig &&
          typeof resolvedPaymentConfig === 'object'
        ) {
          setPaymentConfig((prev) => {
            const next = {
              ...prev,
              ...(resolvedPaymentConfig as Partial<PaymentGatewayConfig>),
            };
            try {
              window.localStorage.setItem(
                'timeto_payment_config_v2',
                JSON.stringify(next)
              );
            } catch {
              // ignore
            }
            return next;
          });
        }

        const resolvedSettlements = Array.isArray(sharedData?.settlementRequests)
          ? sharedData.settlementRequests
          : response.data.settlementRequests;
        if (Array.isArray(resolvedSettlements)) {
          setSettlementRequests((prev) => {
            const byId = new Map<string, SettlementRequestItem>();
            for (const s of resolvedSettlements || []) {
              if (s && s.id) byId.set(s.id, s);
            }
            for (const s of prev) {
              if (s && s.id && !byId.has(s.id)) byId.set(s.id, s);
            }
            const merged = Array.from(byId.values());
            try {
              window.localStorage.setItem(
                'timeto_settlement_requests_v1',
                JSON.stringify(merged)
              );
            } catch {
              // ignore
            }
            return merged;
          });
        }

        const resolvedNotices = Array.isArray(sharedData?.platformBusinessNotices)
          ? sharedData.platformBusinessNotices
          : response.data.platformBusinessNotices;
        if (Array.isArray(resolvedNotices)) {
          setPlatformBusinessNotices((prev) => {
            const byId = new Map<string, PlatformBusinessNoticeItem>();
            for (const n of resolvedNotices || []) {
              if (n && n.id) byId.set(n.id, n);
            }
            for (const n of prev) {
              if (n && n.id && !byId.has(n.id)) byId.set(n.id, n);
            }
            const merged = Array.from(byId.values());
            try {
              window.localStorage.setItem(
                'timeto_platform_business_notices_v1',
                JSON.stringify(merged)
              );
            } catch {
              // ignore
            }
            return merged;
          });
        }

        setCustomers(mergeManualCustomers([]));
        setCampaigns([]);
        setAdminUsers(response.data.registeredUsers ?? []);
        setOwnedBusinessId(localOwnedBizId);

        // دریافت داده قطعی دیتابیس PostgreSQL و تمدید کوکی نشست کاربر فعال (بدون ارسال کش قدیمی مرورگر تا نمایش عادی و Incognito صددرصد یکسان باشند)
        try {
          void realApiClient
            .syncRegisteredAccounts({
              accounts: [],
              issueSessionForPhone: localPersistedUser?.phone || undefined,
              appointments: [],
            })
            .then((syncRes) => {
              if (Array.isArray(syncRes.registeredUsers)) {
                setAdminUsers(syncRes.registeredUsers);
              }
              let latestServices = nextServices;
              if (
                Array.isArray(syncRes.services) &&
                syncRes.services.length > 0
              ) {
                const srvMap = new Map<string, ServiceItem>();
                for (const s of syncRes.services) {
                  if (s && s.id && !/^biz-[1-8]$/.test(s.businessId)) {
                    srvMap.set(s.id, s);
                  }
                }
                latestServices = applySavedServiceSortOrder(
                  Array.from(srvMap.values())
                );
                setServices(latestServices);
              }
              if (
                Array.isArray(syncRes.specialists) &&
                syncRes.specialists.length > 0
              ) {
                setSpecialists(() => {
                  const spcMap = new Map<string, SpecialistItem>();
                  for (const sp of syncRes.specialists || []) {
                    if (
                      sp &&
                      sp.id &&
                      !/^biz-[1-8]$/.test(sp.businessId) &&
                      !/^spc-[1-8]$/.test(sp.id)
                    ) {
                      spcMap.set(sp.id, sp);
                    }
                  }
                  return Array.from(spcMap.values());
                });
              }
              let latestBusinesses = nextBusinesses;
              if (
                Array.isArray(syncRes.businesses) &&
                syncRes.businesses.length > 0
              ) {
                latestBusinesses = syncStartingPricesWithServices(
                  mergeBusinessOverrides(
                    syncRes.businesses,
                    syncRes.registeredUsers,
                    true
                  ),
                  latestServices
                );
                setBusinesses(latestBusinesses);
              }
              if (Array.isArray(syncRes.appointments)) {
                const syncedApts = syncRes.appointments;
                setAppointments(() => {
                  const merged = mergeSavedAppointments(
                    syncedApts,
                    latestBusinesses,
                    true
                  );
                  persistSavedAppointments(merged);
                  return merged;
                });
              }
              if (
                syncRes.paymentConfig &&
                typeof syncRes.paymentConfig === 'object'
              ) {
                setPaymentConfig((prev) => ({
                  ...prev,
                  ...(syncRes.paymentConfig as Partial<PaymentGatewayConfig>),
                }));
              }
              if (Array.isArray(syncRes.settlementRequests)) {
                setSettlementRequests((prev) => {
                  const byId = new Map<string, SettlementRequestItem>();
                  for (const s of syncRes.settlementRequests || []) {
                    if (s && s.id) byId.set(s.id, s);
                  }
                  for (const s of prev) {
                    if (s && s.id && !byId.has(s.id)) byId.set(s.id, s);
                  }
                  return Array.from(byId.values());
                });
              }
              if (Array.isArray(syncRes.platformBusinessNotices)) {
                setPlatformBusinessNotices((prev) => {
                  const byId = new Map<string, PlatformBusinessNoticeItem>();
                  for (const n of syncRes.platformBusinessNotices || []) {
                    if (n && n.id) byId.set(n.id, n);
                  }
                  for (const n of prev) {
                    if (n && n.id && !byId.has(n.id)) byId.set(n.id, n);
                  }
                  return Array.from(byId.values());
                });
              }
            })
            .catch(() => {});
        } catch {
          // ignore
        }

        const firstRealBiz = response.data.businesses[0];
        const firstRealSrv = response.data.services[0];
        const firstRealSpc = response.data.specialists[0];
        // هرگز پیش‌نویس نوبت انتخاب‌شده توسط مشتری را با سالن اول لیست (مثل angel) بازنویسی نکنیم!
        setBookingDraft((prev) => ({
          ...prev,
          businessSlug: prev.businessSlug || firstRealBiz?.slug || '',
          serviceId: prev.serviceId || firstRealSrv?.id || '',
          serviceIds:
            prev.serviceIds && prev.serviceIds.length > 0
              ? prev.serviceIds
              : firstRealSrv?.id
                ? [firstRealSrv.id]
                : [],
          specialistId: prev.specialistId || firstRealSpc?.id || '',
          customerName: prev.customerName || localPersistedUser?.fullName || '',
          customerPhone: prev.customerPhone || localPersistedUser?.phone || '',
          lastReferenceCode: undefined,
        }));

        if (localPersistedUser) {
          try {
            const sessionRes = await realApiClient.getCurrentUser();
            const effectiveUser =
              localPersistedUser.phone !== sessionRes.user.phone
                ? localPersistedUser
                : {
                    ...sessionRes.user,
                    fullName:
                      localPersistedUser.fullName &&
                      localPersistedUser.fullName !== 'کاربر تایم تو'
                        ? localPersistedUser.fullName
                        : sessionRes.user.fullName,
                    roles: localPersistedUser.roles.length
                      ? localPersistedUser.roles
                      : sessionRes.user.roles,
                    isPlatformAdmin:
                      localPersistedUser.isPlatformAdmin ||
                      sessionRes.user.isPlatformAdmin,
                  };
            setAuthUser(effectiveUser);
            setBookingDraft((prev) => ({
              ...prev,
              customerName: effectiveUser.fullName || prev.customerName,
              customerPhone: effectiveUser.phone || prev.customerPhone,
            }));
            await loadAuthenticatedRoleData(effectiveUser);
          } catch {
            setAuthUser(localPersistedUser);
            await loadAuthenticatedRoleData(localPersistedUser);
          }
        } else {
          setAuthUser(null);
        }
      } else if (response.mode === 'mock') {
        setDataMode('mock');
        setDatabaseError(null);
        if (localPersistedUser) {
          setAuthUser(localPersistedUser);
          setBookingDraft((prev) => ({
            ...prev,
            customerName: localPersistedUser.fullName || prev.customerName,
            customerPhone: localPersistedUser.phone || prev.customerPhone,
          }));
        }
      } else {
        setDataMode('real');
        setDatabaseError('پاسخ سرور نامعتبر است؛ به داده‌های آزمایشی بازگشت داده نمی‌شود.');
      }
    } catch (err) {
      const errorMessage =
        err instanceof ApiClientError || err instanceof Error
          ? err.message
          : 'ارتباط با سرور یا پایگاه داده PostgreSQL برقرار نشد؛ به داده‌های آزمایشی (Mock) بازگشت داده نمی‌شود.';
      setDataMode('real');
      setDatabaseError(errorMessage);
      showToast(errorMessage, 'danger');
    } finally {
      setIsLoadingInitialData(false);
    }
  };

  useEffect(() => {
    void refreshRealData();
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || dataMode !== 'real') return;
    const syncLiveFromServer = () => {
      void realApiClient
        .syncRegisteredAccounts({
          accounts: [],
          appointments: [],
        })
        .then((syncRes) => {
          if (Array.isArray(syncRes.registeredUsers)) {
            setAdminUsers(syncRes.registeredUsers);
          }
          if (Array.isArray(syncRes.services) && syncRes.services.length > 0) {
            setServices(() => {
              const srvMap = new Map<string, ServiceItem>();
              for (const s of syncRes.services || []) {
                if (s && s.id && !/^biz-[1-8]$/.test(s.businessId)) {
                  srvMap.set(s.id, s);
                }
              }
              return applySavedServiceSortOrder(Array.from(srvMap.values()));
            });
          }
          if (
            Array.isArray(syncRes.businesses) &&
            syncRes.businesses.length > 0
          ) {
            setBusinesses((prevBiz) =>
              mergeBusinessOverrides(
                syncRes.businesses || prevBiz,
                syncRes.registeredUsers,
                true
              )
            );
          }
          if (Array.isArray(syncRes.appointments)) {
            setAppointments(() => {
              const merged = mergeSavedAppointments(
                syncRes.appointments || [],
                syncRes.businesses || [],
                true
              );
              persistSavedAppointments(merged);
              return merged;
            });
          }
        })
        .catch(() => {});
    };

    const onWindowFocus = () => {
      syncLiveFromServer();
    };
    window.addEventListener('focus', onWindowFocus);
    const intervalId = window.setInterval(syncLiveFromServer, 25000);
    return () => {
      window.removeEventListener('focus', onWindowFocus);
      window.clearInterval(intervalId);
    };
  }, [dataMode]);

  const buildSessionUserFromMemory = (
    phone: string,
    overrideName?: string,
    overrideRole?: AccountRoleChoice
  ): AuthenticatedSessionUser => {
    const accounts = getSavedMemoryAccounts();
    const memoryAcc = accounts[phone];
    const isSuperAdmin =
      phone === '09138201042' || phone === adminNotificationSettings.adminPhone;
    const role: AccountRoleChoice =
      overrideRole ?? memoryAcc?.role ?? 'CUSTOMER';
    const fullName =
      overrideName ||
      memoryAcc?.fullName ||
      (isSuperAdmin
        ? adminNotificationSettings.adminDisplayName || 'مدیر کل تایم تو'
        : 'کاربر تایم تو');

    const roles: Array<'CUSTOMER' | 'BUSINESS_OWNER' | 'PLATFORM_ADMIN'> =
      isSuperAdmin
        ? ['CUSTOMER', 'PLATFORM_ADMIN']
        : role === 'BUSINESS_OWNER'
          ? ['CUSTOMER', 'BUSINESS_OWNER']
          : ['CUSTOMER'];

    return {
      userId: isSuperAdmin ? 'admin-user-1' : `usr-${phone}`,
      sessionId: `sess-${Date.now()}`,
      phone,
      fullName,
      gender: memoryAcc?.gender,
      defaultCity: memoryAcc?.city || 'اصفهان',
      roles,
      isPlatformAdmin: isSuperAdmin,
      businessMemberships: memoryAcc?.businessId
        ? [
            {
              businessUuid: memoryAcc.businessId,
              businessId: memoryAcc.businessId,
              businessSlug: memoryAcc.businessId,
              memberRole: 'OWNER',
            },
          ]
        : [],
    };
  };

  const requestOtpLogin = async (
    phone: string
  ): Promise<{ challengeId?: string }> => {
    if (dataMode === 'real') {
      const res = await realApiClient.requestOtp(phone);
      showToast(res.message, 'info');
      return { challengeId: res.challengeId };
    }
    showToast('کد تأیید ۶ رقمی ارسال شد.', 'info');
    return { challengeId: 'mock-challenge' };
  };

  const verifyOtpLogin = async (
    phone: string,
    code: string
  ): Promise<AuthenticatedSessionUser> => {
    if (dataMode === 'real') {
      const res = await realApiClient.verifyOtp(phone, code);
      const accounts = getSavedMemoryAccounts();
      const mem = accounts[phone];
      const mergedUser: AuthenticatedSessionUser = mem
        ? {
            ...res.user,
            fullName: mem.fullName || res.user.fullName,
            roles:
              mem.role === 'BUSINESS_OWNER' &&
              !res.user.roles.includes('BUSINESS_OWNER')
                ? [...res.user.roles, 'BUSINESS_OWNER']
                : res.user.roles,
          }
        : res.user;
      setAuthUser(mergedUser);
      if (mem?.businessId) {
        setOwnedBusinessId(mem.businessId);
        window.localStorage.setItem(
          'timeto_owned_business_id_v1',
          mem.businessId
        );
      }
      saveVisitorRole(
        mergedUser.roles.includes('BUSINESS_OWNER')
          ? 'BUSINESS_OWNER'
          : 'CUSTOMER'
      );
      setBookingDraft((prev) => ({
        ...prev,
        customerName: mergedUser.fullName || prev.customerName,
        customerPhone: mergedUser.phone || prev.customerPhone,
      }));
      await loadAuthenticatedRoleData(mergedUser);
      showToast(res.message, 'success');
      return mergedUser;
    }

    const sessionUser = buildSessionUserFromMemory(phone);
    const accounts = getSavedMemoryAccounts();
    const mem = accounts[phone];
    if (mem?.businessId) {
      setOwnedBusinessId(mem.businessId);
      try {
        window.localStorage.setItem(
          'timeto_owned_business_id_v1',
          mem.businessId
        );
      } catch {
        // ignore
      }
    }
    saveVisitorRole(
      sessionUser.roles.includes('BUSINESS_OWNER')
        ? 'BUSINESS_OWNER'
        : 'CUSTOMER'
    );
    setAuthUser(sessionUser);
    setBookingDraft((prev) => ({
      ...prev,
      customerName: sessionUser.fullName || prev.customerName,
      customerPhone: sessionUser.phone || prev.customerPhone,
    }));
    showToast('ورود با کد یک‌بارمصرف انجام شد.');
    return sessionUser;
  };

  const loginWithPassword = async (
    phoneOrUsername: string,
    password: string
  ): Promise<AuthenticatedSessionUser> => {
    const trimmedInput = phoneOrUsername.trim();
    const configuredUsername = (
      adminNotificationSettings.adminUsername || 'admin'
    )
      .trim()
      .toLowerCase();
    const resolvedPhone =
      trimmedInput.toLowerCase() === configuredUsername ||
      trimmedInput.toLowerCase() === 'admin'
        ? adminNotificationSettings.adminPhone || '09138201042'
        : trimmedInput;

    const accounts = getSavedMemoryAccounts();
    const memAccount = accounts[resolvedPhone];

    try {
      const storedRaw =
        window.localStorage.getItem('timeto_local_passwords_v1') || '{}';
      const stored = JSON.parse(storedRaw);
      const savedPass =
        memAccount?.password || stored[resolvedPhone] || stored[trimmedInput];
      if (savedPass && savedPass !== password) {
        throw new Error(
          'شماره موبایل / نام کاربری یا رمز عبور وارد شده صحیح نیست.'
        );
      }
    } catch (err) {
      if (err instanceof Error && err.message.includes('صحیح نیست')) {
        throw err;
      }
    }

    if (dataMode === 'real') {
      try {
        const res = await realApiClient.loginWithPassword(
          resolvedPhone,
          password
        );
        const mergedUser: AuthenticatedSessionUser = memAccount
          ? {
              ...res.user,
              fullName: memAccount.fullName || res.user.fullName,
              roles:
                memAccount.role === 'BUSINESS_OWNER' &&
                !res.user.roles.includes('BUSINESS_OWNER')
                  ? [...res.user.roles, 'BUSINESS_OWNER']
                  : res.user.roles,
            }
          : res.user;
        if (memAccount?.businessId) {
          setOwnedBusinessId(memAccount.businessId);
          try {
            window.localStorage.setItem(
              'timeto_owned_business_id_v1',
              memAccount.businessId
            );
          } catch {
            // ignore
          }
        }
        setAuthUser(mergedUser);
        saveVisitorRole(
          mergedUser.roles.includes('BUSINESS_OWNER')
            ? 'BUSINESS_OWNER'
            : 'CUSTOMER'
        );
        setBookingDraft((prev) => ({
          ...prev,
          customerName: mergedUser.fullName || prev.customerName,
          customerPhone: mergedUser.phone || prev.customerPhone,
        }));
        await loadAuthenticatedRoleData(mergedUser);
        showToast(res.message, 'success');
        return mergedUser;
      } catch {
        // اگر حساب فقط در مرورگر بود، نشست رسمی سرور را از طریق register-sync صادر کن
        if (memAccount) {
          try {
            const syncRes = await realApiClient.syncRegisteredAccounts({
              accounts: [
                {
                  phone: memAccount.phone,
                  fullName: memAccount.fullName,
                  city: memAccount.city || 'اصفهان',
                  role:
                    memAccount.role === 'BUSINESS_OWNER' ? 'owner' : 'customer',
                  password: memAccount.password || password,
                  businessId: memAccount.businessId,
                  businessName: memAccount.businessName,
                  businessType: memAccount.businessType,
                  categorySlug: memAccount.categorySlug,
                  typeLabel: memAccount.typeLabel,
                  slug: memAccount.slug,
                  neighborhood: memAccount.neighborhood,
                  avatarUrl: memAccount.avatarUrl,
                },
              ],
              issueSessionForPhone: resolvedPhone,
            });
            if (syncRes.user) {
              setAuthUser(syncRes.user);
            }
          } catch {
            // ignore
          }
        }
      }
    }

    const sessionUser = buildSessionUserFromMemory(resolvedPhone);
    if (memAccount?.businessId) {
      setOwnedBusinessId(memAccount.businessId);
      try {
        window.localStorage.setItem(
          'timeto_owned_business_id_v1',
          memAccount.businessId
        );
      } catch {
        // ignore
      }
    }
    saveVisitorRole(
      sessionUser.roles.includes('BUSINESS_OWNER')
        ? 'BUSINESS_OWNER'
        : 'CUSTOMER'
    );
    setAuthUser(sessionUser);
    setBookingDraft((prev) => ({
      ...prev,
      customerName: sessionUser.fullName || prev.customerName,
      customerPhone: sessionUser.phone || prev.customerPhone,
    }));
    showToast('ورود با رمز عبور با موفقیت انجام شد.');
    return sessionUser;
  };

  const completeUnifiedAuthSession = async (payload: {
    phone: string;
    password?: string;
    firstName?: string;
    lastName?: string;
    fullName: string;
    gender?: 'FEMALE' | 'MALE';
    role: AccountRoleChoice;
    avatarUrl?: string;
    salonInfo?: {
      businessName: string;
      businessType: BusinessType;
      categorySlug?: string;
      typeLabel?: string;
      city: string;
      neighborhood: string;
    };
  }): Promise<AuthenticatedSessionUser> => {
    let createdBusinessId: string | undefined;
    let createdBusinessSlug: string | undefined;

    if (payload.role === 'BUSINESS_OWNER') {
      const existingAccounts = getSavedMemoryAccounts();
      const prevAccount = existingAccounts[payload.phone];
      const cleanPayloadPhone = toEnglishDigitsClient(payload.phone).replace(
        /\D/g,
        ''
      );
      const existingBizForPhone = businesses.find((b) => {
        if (b.isSampleShowcase || /^biz-[1-8]$/.test(b.id)) return false;
        const bOwnerPhone = toEnglishDigitsClient(
          String(b.ownerPhone || b.phoneDisplay || '')
        ).replace(/\D/g, '');
        return (
          (prevAccount?.businessId && b.id === prevAccount.businessId) ||
          (cleanPayloadPhone && bOwnerPhone === cleanPayloadPhone)
        );
      });

      if (existingBizForPhone) {
        createdBusinessId = existingBizForPhone.id;
        createdBusinessSlug = existingBizForPhone.slug;
        setOwnedBusinessId(existingBizForPhone.id);
        try {
          window.localStorage.setItem(
            'timeto_owned_business_id_v1',
            existingBizForPhone.id
          );
        } catch {
          // ignore
        }
      } else if (prevAccount?.businessId) {
        createdBusinessId = prevAccount.businessId;
        createdBusinessSlug = prevAccount.slug;
        setOwnedBusinessId(prevAccount.businessId);
        try {
          window.localStorage.setItem(
            'timeto_owned_business_id_v1',
            prevAccount.businessId
          );
        } catch {
          // ignore
        }
      } else {
        const newBizId = `biz-owner-${cleanPayloadPhone || Date.now()}`;
        createdBusinessId = newBizId;
        const salonName =
          payload.salonInfo?.businessName?.trim() ||
          `سالن زیبایی ${payload.fullName}`;
        const salonType =
          payload.salonInfo?.businessType ?? BusinessType.WomenSalon;
        const salonCity = payload.salonInfo?.city?.trim() || 'اصفهان';
        const salonNeighborhood =
          payload.salonInfo?.neighborhood?.trim() || 'چهارباغ بالا';
        const isLaserCenter =
          payload.salonInfo?.categorySlug === 'laser-hair-removal' ||
          salonName.includes('لیزر') ||
          String(payload.salonInfo?.typeLabel || '').includes('لیزر');

        const generatedSlug = `salon-${cleanPayloadPhone.slice(-4) || Math.floor(1000 + Math.random() * 8999)}`;
        createdBusinessSlug = generatedSlug;

        const newBiz: BusinessItem = {
          id: newBizId,
          slug: generatedSlug,
          name: salonName,
          type: salonType,
          typeLabel:
            payload.salonInfo?.typeLabel ||
            (isLaserCenter
              ? 'مرکز لیزر موهای زائد'
              : salonType === BusinessType.MenBarbershop
                ? 'آرایشگاه مردانه'
                : salonType === BusinessType.IndependentSpecialist
                  ? 'متخصص مستقل زیبایی'
                  : 'سالن زیبایی زنانه'),
          categorySlug:
            payload.salonInfo?.categorySlug ||
            (isLaserCenter ? 'laser-hair-removal' : 'hair-color'),
          targetGender: isLaserCenter ? 'BOTH' : undefined,
          city: salonCity,
          neighborhood: salonNeighborhood,
          address: `${salonCity}، ${salonNeighborhood}`,
          phoneDisplay: payload.phone,
          ownerName: payload.fullName,
          ownerPhone: payload.phone,
          createdAtJalali: getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز',
          rating: 5.0,
          reviewCount: 0,
          startingPriceToman: 0,
          shortDescription: `${isLaserCenter ? 'مرکز تخصصی لیزر' : 'مرکز تخصصی زیبایی'} ${salonName} در ${salonCity}`,
          aboutText: '',
          verifiedBadge: false,
          approvalStatus: 'PENDING_REVIEW',
          subscriptionPlan: 'شروع رایگان (پایه)',
          subscriptionStatus: SubscriptionStatus.Trial,
          trialDaysRemaining: 30,
          extraSmsBalance: 0,
          smsSentCount: 0,
          workingHours: INITIAL_ONBOARDING_DRAFT.workingHours,
          workingHoursConfigured: false,
          contractAccepted: false,
          visualTheme: 'violet',
          featured: false,
          isSampleShowcase: false,
          avatarUrl: payload.avatarUrl,
        };

        sendPlatformBusinessNotice({
          targetBusinessId: newBizId,
          targetBusinessName: salonName,
          title: '⚠️ خوش آمدید! تکمیل پروفایل و تایید قرارداد جهت نمایش عمومی سالن الزامی است',
          message:
            'کسب‌وکار شما ثبت اولیه شد. توجه: تا زمان تکمیل گام‌های الزامی (۱. آدرس و موقعیت نقشه، ۲. حداقل یک خدمت، ۳. ساعت کاری، ۴. معرفی متخصص، و ۵. ثبت شبا + تیک تایید مفاد قرارداد همکاری)، پروفایل سالن شما در ویترین عمومی نمایش داده نمی‌شود. (بخش گالری تصاویر کاملاً اختیاری است).',
        });

        try {
          const localOnbRaw =
            window.localStorage.getItem(
              'timeto_local_onboarded_businesses_v1'
            ) || '[]';
          const localOnbList: BusinessItem[] = JSON.parse(localOnbRaw);
          window.localStorage.setItem(
            'timeto_local_onboarded_businesses_v1',
            JSON.stringify([
              newBiz,
              ...localOnbList.filter((x) => x.id !== newBiz.id),
            ])
          );
          window.localStorage.setItem('timeto_owned_business_id_v1', newBizId);
        } catch {
          // ignore
        }

        const newNotif: AdminNotificationItem = {
          id: `notif-${Date.now()}`,
          type: 'NEW_BUSINESS',
          title: `ثبت‌نام سالن جدید: ${newBiz.name}`,
          message: `${payload.fullName} (${payload.phone}) سالن «${newBiz.name}» را ثبت کرد و منتظر تایید شماست.`,
          businessId: newBiz.id,
          businessName: newBiz.name,
          ownerName: payload.fullName,
          ownerPhone: payload.phone,
          city: newBiz.city,
          createdAtJalali: 'امروز',
          isRead: false,
        };

        setAdminNotifications((prev) => {
          const next = [newNotif, ...prev];
          try {
            window.localStorage.setItem(
              'timeto_admin_notifications_v1',
              JSON.stringify(next)
            );
          } catch {
            // ignore
          }
          return next;
        });

        setBusinesses((prev) => [
          newBiz,
          ...prev.filter((b) => b.id !== newBiz.id),
        ]);
        setOwnedBusinessId(newBizId);
      }
    }

    try {
      const deletedRaw =
        window.localStorage.getItem('timeto_deleted_admin_phones_v1') || '[]';
      const deletedPhones: string[] = JSON.parse(deletedRaw);
      if (deletedPhones.includes(payload.phone)) {
        window.localStorage.setItem(
          'timeto_deleted_admin_phones_v1',
          JSON.stringify(deletedPhones.filter((p) => p !== payload.phone))
        );
      }
    } catch {
      // ignore
    }

    if (payload.role === 'CUSTOMER') {
      const customerNotif: AdminNotificationItem = {
        id: `notif-usr-${Date.now()}`,
        type: 'NEW_BUSINESS',
        title: `ثبت‌نام کاربر جدید (مشتری): ${payload.fullName}`,
        message: `کاربر عادی «${payload.fullName}» با شماره همراه ${payload.phone} در سامانه ثبت‌نام کرد.`,
        ownerName: payload.fullName,
        ownerPhone: payload.phone,
        city: payload.salonInfo?.city || 'اصفهان',
        createdAtJalali: 'امروز',
        isRead: false,
      };
      setAdminNotifications((prev) => {
        const next = [customerNotif, ...prev];
        try {
          window.localStorage.setItem(
            'timeto_admin_notifications_v1',
            JSON.stringify(next)
          );
        } catch {
          // ignore
        }
        return next;
      });
    }

    const resolvedCategorySlug =
      payload.salonInfo?.categorySlug ||
      (String(payload.salonInfo?.businessName || '').includes('لیزر') ||
      String(payload.salonInfo?.typeLabel || '').includes('لیزر')
        ? 'laser-hair-removal'
        : undefined);

    saveMemoryAccount({
      phone: payload.phone,
      password: payload.password || 'Timeto@1234',
      firstName: payload.firstName || payload.fullName.split(' ')[0] || '',
      lastName:
        payload.lastName ||
        payload.fullName.split(' ').slice(1).join(' ') ||
        '',
      fullName: payload.fullName,
      gender: payload.gender,
      role: payload.role,
      avatarUrl: payload.avatarUrl,
      businessId: createdBusinessId,
      businessName: payload.salonInfo?.businessName,
      businessType: payload.salonInfo?.businessType,
      categorySlug: resolvedCategorySlug,
      typeLabel: payload.salonInfo?.typeLabel,
      slug: createdBusinessSlug,
      city: payload.salonInfo?.city || 'اصفهان',
      neighborhood: payload.salonInfo?.neighborhood,
      updatedAt: Date.now(),
    });
    setAccountsRevision((r) => r + 1);

    saveVisitorRole(payload.role);
    let sessionUser = buildSessionUserFromMemory(
      payload.phone,
      payload.fullName,
      payload.role
    );
    if (payload.gender) {
      sessionUser = { ...sessionUser, gender: payload.gender };
    }
    setAuthUser(sessionUser);
    setBookingDraft((prev) => ({
      ...prev,
      customerName: payload.fullName || prev.customerName,
      customerPhone: payload.phone || prev.customerPhone,
    }));

    // ثبت دائمی کاربر جدید (مشتری یا صاحب سالن) در دیتابیس PostgreSQL و صدور نشست واقعی سرور
    if (dataMode === 'real') {
      try {
        const allLocalAccounts = Object.values(getSavedMemoryAccounts()).map(
          (acc) => ({
            phone: acc.phone,
            fullName: acc.fullName,
            city: acc.city || 'اصفهان',
            role: (acc.role === 'BUSINESS_OWNER' ? 'owner' : 'customer') as
              | 'owner'
              | 'customer',
            password: acc.password,
            businessId: acc.businessId,
            businessName: acc.businessName,
            businessType: acc.businessType,
            categorySlug: acc.categorySlug,
            typeLabel: acc.typeLabel,
            slug: acc.slug,
            approvalStatus: acc.approvalStatus,
            neighborhood: acc.neighborhood,
            avatarUrl: acc.avatarUrl,
          })
        );
        const syncRes = await realApiClient.syncRegisteredAccounts({
          accounts: allLocalAccounts.length
            ? allLocalAccounts
            : [
                {
                  phone: payload.phone,
                  fullName: payload.fullName,
                  city: payload.salonInfo?.city || 'اصفهان',
                  role: payload.role === 'BUSINESS_OWNER' ? 'owner' : 'customer',
                  password: payload.password,
                  businessId: createdBusinessId,
                  businessName: payload.salonInfo?.businessName,
                  businessType: payload.salonInfo?.businessType,
                  categorySlug: resolvedCategorySlug,
                  typeLabel: payload.salonInfo?.typeLabel,
                  slug: createdBusinessSlug,
                  neighborhood: payload.salonInfo?.neighborhood,
                  avatarUrl: payload.avatarUrl,
                },
              ],
          issueSessionForPhone: payload.phone,
        });
        if (Array.isArray(syncRes.registeredUsers)) {
          setAdminUsers(syncRes.registeredUsers);
        }
        if (
          Array.isArray(syncRes.businesses) &&
          syncRes.businesses.length > 0
        ) {
          setBusinesses(mergeBusinessOverrides(syncRes.businesses));
        }
        if (syncRes.user) {
          sessionUser = {
            ...syncRes.user,
            fullName: payload.fullName || syncRes.user.fullName,
            roles:
              payload.role === 'BUSINESS_OWNER' &&
              !syncRes.user.roles.includes('BUSINESS_OWNER')
                ? [...syncRes.user.roles, 'BUSINESS_OWNER']
                : syncRes.user.roles,
          };
          setAuthUser(sessionUser);
        }
      } catch {
        // ادامه با حساب محلی در صورت خطای شبکه
      }
    }

    return sessionUser;
  };

  const setAccountPassword = async (password: string): Promise<boolean> => {
    if (password.trim().length < 4) {
      showToast('رمز عبور باید حداقل ۴ کاراکتر باشد.', 'warning');
      return false;
    }
    if (dataMode === 'real') {
      try {
        const res = await realApiClient.setAccountPassword(password);
        showToast(res.message, 'success');
        return true;
      } catch {
        // ادامه با ذخیره در حافظه مرورگر
      }
    }

    if (authUser?.phone) {
      try {
        const storedRaw =
          window.localStorage.getItem('timeto_local_passwords_v1') || '{}';
        const stored = JSON.parse(storedRaw);
        stored[authUser.phone] = password;
        window.localStorage.setItem(
          'timeto_local_passwords_v1',
          JSON.stringify(stored)
        );
      } catch {
        // ignore
      }
    }
    showToast('رمز عبور ثابت شما در حافظه ذخیره شد.');
    return true;
  };

  const resetPasswordWithOtp = async (
    phone: string,
    code: string,
    newPassword: string
  ): Promise<boolean> => {
    if (newPassword.trim().length < 4) {
      showToast('رمز عبور جدید باید حداقل ۴ کاراکتر باشد.', 'warning');
      return false;
    }
    if (dataMode === 'real') {
      try {
        const res = await realApiClient.resetPasswordWithOtp(
          phone,
          code,
          newPassword
        );
        setAuthUser(res.user);
        await loadAuthenticatedRoleData(res.user);
        showToast(res.message, 'success');
        return true;
      } catch {
        // ادامه با ذخیره در حافظه
      }
    }

    try {
      const storedRaw =
        window.localStorage.getItem('timeto_local_passwords_v1') || '{}';
      const stored = JSON.parse(storedRaw);
      stored[phone] = newPassword;
      window.localStorage.setItem(
        'timeto_local_passwords_v1',
        JSON.stringify(stored)
      );
      const accounts = getSavedMemoryAccounts();
      if (accounts[phone]) {
        saveMemoryAccount({
          ...accounts[phone],
          password: newPassword,
          updatedAt: Date.now(),
        });
      }
    } catch {
      // ignore
    }
    await loginWithPassword(phone, newPassword);
    showToast('رمز عبور جدید شما با موفقیت ثبت شد و وارد حساب شدید.');
    return true;
  };

  const logoutUser = async (): Promise<void> => {
    if (dataMode === 'real') {
      try {
        await realApiClient.logout();
      } catch {
        // نادیده گرفتن خطا در صورت انقضای قبلی نشست
      }
    }
    setAuthUser(null);
    setOwnedBusinessId(null);
    try {
      window.localStorage.removeItem(PERSISTED_SESSION_USER_KEY);
      window.localStorage.removeItem('timeto_owned_business_id_v1');
    } catch {
      // ignore
    }
    showToast('از حساب کاربری خارج شدید.', 'info');
  };

  const updateCustomerProfile = async (patch: {
    fullName?: string;
    phone?: string;
    defaultCity?: string;
  }): Promise<boolean> => {
    const currentPhone = authUser?.phone || '';
    const requestedPhone = patch.phone
      ? normalizeIranMobile(patch.phone)
      : currentPhone;

    if (patch.phone && !/^09\d{9}$/.test(requestedPhone)) {
      showToast(
        'شماره موبایل باید ۱۱ رقم معتبر و با پیش‌شماره ۰۹ باشد.',
        'warning'
      );
      return false;
    }

    if (currentPhone) {
      const memUpdate = updateMemoryAccountPhoneOrProfile(currentPhone, {
        newPhone: requestedPhone || currentPhone,
        fullName: patch.fullName,
        city: patch.defaultCity,
      });
      if (!memUpdate.ok) {
        showToast(
          memUpdate.error || 'خطا در بروزرسانی شماره موبایل یا مشخصات.',
          'warning'
        );
        return false;
      }
    }

    if (
      requestedPhone &&
      currentPhone &&
      requestedPhone !== currentPhone &&
      rawAdminUsers.some(
        (u) => normalizeIranMobile(u.phone || u.phoneMasked) === requestedPhone
      )
    ) {
      showToast(
        'این شماره موبایل قبلاً برای حساب دیگری ثبت شده است.',
        'warning'
      );
      return false;
    }

    try {
      const overridesRaw =
        window.localStorage.getItem('timeto_admin_user_overrides_v1') || '{}';
      const overrides = JSON.parse(overridesRaw);
      const targetPhoneKey = requestedPhone || currentPhone;
      if (targetPhoneKey) {
        if (currentPhone && currentPhone !== targetPhoneKey) {
          delete overrides[currentPhone];
        }
        overrides[targetPhoneKey] = {
          ...(overrides[targetPhoneKey] || {}),
          ...(patch.fullName ? { fullName: patch.fullName.trim() } : {}),
          ...(patch.defaultCity ? { city: patch.defaultCity.trim() } : {}),
          phone: targetPhoneKey,
        };
        window.localStorage.setItem(
          'timeto_admin_user_overrides_v1',
          JSON.stringify(overrides)
        );
      }
    } catch {
      // ignore
    }

    if (dataMode === 'real') {
      try {
        const res = await realApiClient.updateMyProfile({
          fullName: patch.fullName,
          defaultCity: patch.defaultCity,
        });
        const updatedUser: AuthenticatedSessionUser = {
          ...res.user,
          fullName: patch.fullName?.trim() || res.user.fullName,
          phone: requestedPhone || res.user.phone,
          defaultCity: patch.defaultCity?.trim() || res.user.defaultCity,
        };
        setAuthUser(updatedUser);
        setBookingDraft((prev) => ({
          ...prev,
          customerName: updatedUser.fullName || prev.customerName,
          customerPhone: updatedUser.phone || prev.customerPhone,
        }));
        setAccountsRevision((r) => r + 1);
        showToast('مشخصات کاربری و شماره همراه بروزرسانی شد.', 'success');
        return true;
      } catch {
        // در صورت خطای شبکه یا حساب محلی، تغییرات روی نشست و حافظه اعمال شود
      }
    }

    if (authUser) {
      const updatedSession: AuthenticatedSessionUser = {
        ...authUser,
        fullName: patch.fullName?.trim() || authUser.fullName,
        phone: requestedPhone || authUser.phone,
        defaultCity: patch.defaultCity?.trim() || authUser.defaultCity,
      };
      setAuthUser(updatedSession);
      setBookingDraft((prev) => ({
        ...prev,
        customerName: updatedSession.fullName || prev.customerName,
        customerPhone: updatedSession.phone || prev.customerPhone,
      }));
    }
    setAccountsRevision((r) => r + 1);
    showToast('تغییرات پروفایل و شماره همراه ذخیره شد.');
    return true;
  };

  const toggleFavoriteBusiness = (businessId: string) => {
    if (!authUser) {
      openAuthModal({
        initialScreen: 'LOGIN',
        defaultRole: 'CUSTOMER',
        promptReason:
          'برای ذخیره سالن در لیست علاقه‌مندی‌های حساب کاربری خود، ابتدا وارد شوید.',
      });
      return;
    }

    setFavoriteBusinessIds((prev) => {
      const exists = prev.includes(businessId);
      const next = exists
        ? prev.filter((id) => id !== businessId)
        : [...prev, businessId];
      try {
        const phoneKey = `timeto_fav_biz_${authUser.phone}`;
        window.localStorage.setItem(phoneKey, JSON.stringify(next));
        window.localStorage.setItem(
          'beautyhub_fav_businesses',
          JSON.stringify(next)
        );
      } catch {
        // ignore storage errors
      }
      const targetBiz = businesses.find((b) => b.id === businessId);
      showToast(
        exists
          ? `${targetBiz ? `«${targetBiz.name}»` : 'سالن'} از لیست علاقه‌مندی‌ها حذف شد.`
          : `${targetBiz ? `«${targetBiz.name}»` : 'سالن'} در علاقه‌مندی‌های پروفایل شما ذخیره شد.`,
        exists ? 'info' : 'success'
      );
      return next;
    });

    if (dataMode === 'real') {
      void realApiClient.toggleFavoriteBusiness(businessId).catch(() => {
        // همگام‌سازی محلی قبلاً انجام شده است
      });
    }
  };

  const toggleFavoriteSpecialist = (specialistId: string) => {
    if (!authUser) {
      openAuthModal({
        initialScreen: 'LOGIN',
        defaultRole: 'CUSTOMER',
        promptReason:
          'برای ذخیره متخصص در لیست علاقه‌مندی‌های حساب کاربری خود، ابتدا وارد شوید.',
      });
      return;
    }

    setFavoriteSpecialistIds((prev) => {
      const exists = prev.includes(specialistId);
      const next = exists
        ? prev.filter((id) => id !== specialistId)
        : [...prev, specialistId];
      try {
        const phoneKey = `timeto_fav_spc_${authUser.phone}`;
        window.localStorage.setItem(phoneKey, JSON.stringify(next));
        window.localStorage.setItem(
          'beautyhub_fav_specialists',
          JSON.stringify(next)
        );
      } catch {
        // ignore storage errors
      }
      const targetSpc = specialists.find((s) => s.id === specialistId);
      showToast(
        exists
          ? `${targetSpc ? `«${targetSpc.fullName}»` : 'متخصص'} از لیست علاقه‌مندی‌ها حذف شد.`
          : `${targetSpc ? `«${targetSpc.fullName}»` : 'متخصص'} در علاقه‌مندی‌های پروفایل شما ذخیره شد.`,
        exists ? 'info' : 'success'
      );
      return next;
    });
  };

  const updateBusinessProfile = (
    businessId: string,
    patch: Partial<BusinessItem>
  ) => {
    setBusinesses((prev) => {
      const existsInPrev = prev.some((b) => b.id === businessId);
      const baseList =
        !existsInPrev && currentBusiness && currentBusiness.id === businessId
          ? [currentBusiness, ...prev]
          : prev;
      const next = baseList.map((b) =>
        b.id === businessId
          ? {
              ...b,
              ...patch,
              approvalStatus:
                patch.approvalStatus ?? b.approvalStatus ?? 'APPROVED',
            }
          : b
      );
      try {
        const overridesRaw =
          window.localStorage.getItem('timeto_biz_overrides_v2') || '{}';
        const overrides = JSON.parse(overridesRaw);
        const existingEntry = { ...(overrides[businessId] || {}) };
        delete existingEntry.walletBalanceToman;
        const { walletBalanceToman: _ignoredWallet, ...safePatch } = patch;
        const existingStatus = existingEntry.approvalStatus;
        overrides[businessId] = {
          ...existingEntry,
          ...safePatch,
          approvalStatus:
            patch.approvalStatus ?? existingStatus ?? 'APPROVED',
        };
        window.localStorage.setItem(
          'timeto_biz_overrides_v2',
          JSON.stringify(overrides)
        );

        const localOnbRaw =
          window.localStorage.getItem('timeto_local_onboarded_businesses_v1') ||
          '[]';
        const localOnbList: BusinessItem[] = JSON.parse(localOnbRaw);
        if (localOnbList.some((lb) => lb.id === businessId)) {
          window.localStorage.setItem(
            'timeto_local_onboarded_businesses_v1',
            JSON.stringify(
              localOnbList.map((lb) =>
                lb.id === businessId
                  ? {
                      ...lb,
                      ...patch,
                      approvalStatus:
                        patch.approvalStatus ?? lb.approvalStatus ?? 'APPROVED',
                    }
                  : lb
              )
            )
          );
        }
      } catch {
        // ignore storage errors
      }
      return next;
    });

    // اگر صاحب سالن تصویر پروفایل سالن را تغییر دهد و تنها متخصص سالن باشد (یا هنوز عکس جدایی برای متخصص نگذاشته باشد)، عکس متخصص هم همگام شود
    if (patch.avatarUrl && patch.avatarUrl.trim()) {
      setSpecialists((prev) => {
        const bizSpecs = prev.filter((sp) => sp.businessId === businessId);
        const next = prev.map((sp) => {
          if (sp.businessId !== businessId) return sp;
          if (bizSpecs.length === 1 || !sp.avatarUrl) {
            return { ...sp, avatarUrl: patch.avatarUrl };
          }
          return sp;
        });
        try {
          window.localStorage.setItem(
            'timeto_local_specialists_v1',
            JSON.stringify(next)
          );
        } catch {
          // ignore
        }
        return next;
      });
    }

    if (dataMode === 'real') {
      void realApiClient
        .updateBusinessProfile(businessId, patch)
        .then(() => {
          showToast('اطلاعات پروفایل و موقعیت نقشه کسب‌وکار ذخیره شد.');
        })
        .catch(() => {
          showToast('تغییرات موقعیت نقشه و مشخصات کسب‌وکار اعمال شد.');
        });
      return;
    }

    showToast('اطلاعات پروفایل و موقعیت نقشه کسب‌وکار بروزرسانی شد.');
  };

  const updatePlan = (planId: string, patch: Partial<SubscriptionPlanItem>) => {
    setPlans((prev) => {
      const next = prev.map((p) => (p.id === planId ? { ...p, ...patch } : p));
      try {
        window.localStorage.setItem(
          'timeto_custom_plans_v2',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    showToast('پلن اشتراک با موفقیت ویرایش و ذخیره شد.');
  };

  const updateAdPackage = (pkgId: string, patch: Partial<AdPackageItem>) => {
    setAdPackages((prev) => {
      const next = prev.map((pkg) =>
        pkg.id === pkgId ? { ...pkg, ...patch } : pkg
      );
      try {
        window.localStorage.setItem(
          'timeto_custom_ad_packages_v2',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    showToast('تعرفه و مشخصات بسته تبلیغاتی بروزرسانی شد.');
  };

  const updatePaymentConfig = (patch: Partial<PaymentGatewayConfig>) => {
    setPaymentConfig((prev) => {
      const next = { ...prev, ...patch };
      try {
        window.localStorage.setItem(
          'timeto_payment_config_v2',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (next.zibalMerchantId) {
        fetch('/api/v1/payments/zibal/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ merchantId: next.zibalMerchantId }),
        }).catch(() => {});
      }
      if (dataMode === 'real') {
        void realApiClient
          .savePlatformSharedState({ paymentConfig: next })
          .catch(() => {});
      }
      return next;
    });
    showToast('تنظیمات درگاه پرداخت و نرخ کارمزد در پایگاه داده ذخیره شد.');
  };

  const applyApprovedOrderEffect = (order: PaymentOrderItem) => {
    if (order.itemType === 'PLAN') {
      setActivePlanId(order.itemId);
      const foundPlan = plans.find((p) => p.id === order.itemId);
      updateBusinessProfile(order.businessId, {
        subscriptionPlan: foundPlan?.name || order.itemTitle,
        subscriptionStatus: SubscriptionStatus.Active,
      });
    } else if (order.itemType === 'AD_PACKAGE') {
      const duration = order.requestedDurationDays || 30;
      const placement = order.requestedPlacement || 'SEARCH_TOP';
      const targetBiz = businesses.find((b) => b.id === order.businessId);
      updateBusinessProfile(order.businessId, {
        isSponsored: true,
        featured: true,
        sponsoredPlacement: placement,
        sponsoredDaysRemaining: duration,
        sponsoredExpiresJalali: `تا ${duration} روز آینده`,
        sponsoredOrder: placement === 'HERO_SPOTLIGHT' ? 1 : 2,
        sponsoredCategorySlug:
          order.requestedCategorySlug || targetBiz?.categorySlug,
        sponsoredNeighborhood:
          order.requestedNeighborhood || targetBiz?.neighborhood,
        sponsoredImpressions: (targetBiz?.sponsoredImpressions ?? 120) + 45,
        sponsoredClicks: targetBiz?.sponsoredClicks ?? 18,
        sponsoredLabel:
          order.requestedLabel ||
          (placement === 'HOME_BANNER'
            ? 'بنر ویژه صفحه اول'
            : 'پیشنهاد ویژه رزرو آنلاین'),
      });
    } else if (order.itemType === 'SMS_PACK') {
      const targetBiz = businesses.find((b) => b.id === order.businessId);
      const addedSms = order.requestedSmsCount || 200;
      updateBusinessProfile(order.businessId, {
        extraSmsBalance: (targetBiz?.extraSmsBalance ?? 0) + addedSms,
      });
    }
  };

  const submitPaymentOrder = (
    input: Omit<PaymentOrderItem, 'id' | 'createdAtJalali' | 'status'>,
    autoApprove = false
  ): PaymentOrderItem => {
    const newOrder: PaymentOrderItem = {
      ...input,
      id: `ORD-1403-${Math.floor(100 + Math.random() * 899)}`,
      createdAtJalali: getUpcomingJalaliDays(1)[0]?.dateJalali || '۱۴۰۳/۰۸/۲۱',
      status: autoApprove ? 'APPROVED' : 'PENDING',
    };
    setPaymentOrders((prev) => {
      const next = [newOrder, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_payment_orders_v2',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    const orderNotif: AdminNotificationItem = {
      id: `notif-ord-${Date.now()}`,
      type: 'NEW_PAYMENT_ORDER',
      title: `سفارش مالی جدید: ${newOrder.itemTitle}`,
      message: `کسب‌وکار «${newOrder.businessName}» سفارش «${newOrder.itemTitle}» به مبلغ ${newOrder.amountToman.toLocaleString('fa-IR')} تومان ثبت کرد.`,
      businessId: newOrder.businessId,
      businessName: newOrder.businessName,
      ownerName: newOrder.businessName,
      ownerPhone:
        currentBusiness?.ownerPhone ||
        currentBusiness?.phoneDisplay ||
        authUser?.phone ||
        '',
      city: currentBusiness?.city || 'اصفهان',
      amountToman: newOrder.amountToman,
      orderId: newOrder.id,
      createdAtJalali: 'امروز',
      isRead: false,
    };
    setAdminNotifications((prev) => {
      const next = [orderNotif, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    if (autoApprove) {
      applyApprovedOrderEffect(newOrder);
      showToast(
        `پرداخت «${newOrder.itemTitle}» تایید و روی کسب‌وکار شما فعال شد.`
      );
    } else {
      showToast(
        `رسید پرداخت «${newOrder.itemTitle}» ثبت شد و در صف تایید مدیریت قرار گرفت.`
      );
    }
    return newOrder;
  };

  const reviewPaymentOrder = (
    orderId: string,
    decision: 'APPROVED' | 'REJECTED'
  ) => {
    const target = paymentOrders.find((o) => o.id === orderId);
    setPaymentOrders((prev) => {
      const next = prev.map((o) =>
        o.id === orderId ? { ...o, status: decision } : o
      );
      try {
        window.localStorage.setItem(
          'timeto_payment_orders_v2',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    // علامت‌گذاری خودکار اعلان مربوط به این سفارش مالی به عنوان خوانده‌شده
    setAdminNotifications((prev) => {
      const next = prev.map((n) =>
        n.orderId === orderId ? { ...n, isRead: true } : n
      );
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    if (target && decision === 'APPROVED') {
      applyApprovedOrderEffect(target);
      showToast(
        `سفارش «${target.itemTitle}» برای «${target.businessName}» تایید و به صورت خودکار فعال شد.`
      );
    } else if (target && decision === 'REJECTED') {
      showToast(
        `سفارش «${target.itemTitle}» برای «${target.businessName}» رد شد.`,
        'warning'
      );
    }
  };

  const updateBusinessWorkingHours = (
    businessId: string,
    hours: WorkingHourItem[]
  ) => {
    const persistHoursOverride = (savedHours: WorkingHourItem[]) => {
      try {
        const overridesRaw =
          window.localStorage.getItem('timeto_biz_overrides_v2') || '{}';
        const overrides = JSON.parse(overridesRaw);
        overrides[businessId] = {
          ...(overrides[businessId] || {}),
          workingHours: savedHours,
          workingHoursConfigured: true,
        };
        window.localStorage.setItem(
          'timeto_biz_overrides_v2',
          JSON.stringify(overrides)
        );
      } catch {
        // ignore
      }
    };

    if (dataMode === 'real') {
      void realApiClient
        .updateBusinessWorkingHours(businessId, hours)
        .then((res) => {
          persistHoursOverride(res.workingHours);
          setBusinesses((prev) =>
            prev.map((b) =>
              b.id === businessId
                ? {
                    ...b,
                    workingHours: res.workingHours,
                    workingHoursConfigured: true,
                  }
                : b
            )
          );
          showToast('ساعات کاری هفتگی در پایگاه داده ذخیره و در پیشرفت پروفایل لحاظ شد.');
        })
        .catch(() => {
          persistHoursOverride(hours);
          setBusinesses((prev) =>
            prev.map((b) =>
              b.id === businessId
                ? { ...b, workingHours: hours, workingHoursConfigured: true }
                : b
            )
          );
          showToast('ساعات کاری هفتگی ذخیره و در پیشرفت پروفایل شما ثبت شد.');
        });
      return;
    }

    persistHoursOverride(hours);
    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === businessId
          ? { ...b, workingHours: hours, workingHoursConfigured: true }
          : b
      )
    );
    showToast('ساعات کاری هفتگی ذخیره و در پیشرفت پروفایل ثبت شد.');
  };

  const updateBusinessApproval = (
    businessId: string,
    status: ApprovalStatus
  ) => {
    const targetBiz = businesses.find(
      (b) => b.id === businessId || b.slug === businessId
    );
    const updatedTargetBiz: BusinessItem | undefined = targetBiz
      ? {
          ...targetBiz,
          approvalStatus: status,
          verifiedBadge: status === 'APPROVED',
          isSampleShowcase: false,
        }
      : undefined;

    // بروزرسانی فوری در وضعیت محلی، لیست سالن‌های ثبت‌شده و Overrides
    setBusinesses((prev) => {
      const next = prev.map((b) =>
        b.id === businessId || b.slug === businessId
          ? {
              ...b,
              approvalStatus: status,
              verifiedBadge: status === 'APPROVED',
              isSampleShowcase: false,
            }
          : b
      );
      try {
        const overridesRaw =
          window.localStorage.getItem('timeto_biz_overrides_v2') || '{}';
        const overrides = JSON.parse(overridesRaw);
        overrides[businessId] = {
          ...(overrides[businessId] || {}),
          approvalStatus: status,
          verifiedBadge: status === 'APPROVED',
        };
        if (updatedTargetBiz?.slug) {
          overrides[updatedTargetBiz.slug] = {
            ...(overrides[updatedTargetBiz.slug] || {}),
            approvalStatus: status,
            verifiedBadge: status === 'APPROVED',
          };
        }
        window.localStorage.setItem(
          'timeto_biz_overrides_v2',
          JSON.stringify(overrides)
        );

        if (status === 'APPROVED') {
          // حذف از لیست زباله‌دان دائمی در صورت وجود
          const permRaw =
            window.localStorage.getItem(
              'timeto_permanently_deleted_biz_ids_v1'
            ) || '[]';
          const permList: string[] = JSON.parse(permRaw);
          if (permList.includes(businessId)) {
            window.localStorage.setItem(
              'timeto_permanently_deleted_biz_ids_v1',
              JSON.stringify(permList.filter((id) => id !== businessId))
            );
          }

          // ذخیره در لیست کسب‌وکارهای تاییدشده محلی تا پروفایل بلافاصله در کل اپلیکیشن در دسترس باشد
          if (updatedTargetBiz) {
            const localOnbRaw =
              window.localStorage.getItem(
                'timeto_local_onboarded_businesses_v1'
              ) || '[]';
            const localOnbList: BusinessItem[] = JSON.parse(localOnbRaw);
            const filteredLocal = localOnbList.filter(
              (item) =>
                item &&
                item.id !== updatedTargetBiz.id &&
                item.slug !== updatedTargetBiz.slug
            );
            filteredLocal.unshift(updatedTargetBiz);
            window.localStorage.setItem(
              'timeto_local_onboarded_businesses_v1',
              JSON.stringify(filteredLocal)
            );
          }
        } else if (status === 'REJECTED') {
          const localOnbRaw =
            window.localStorage.getItem(
              'timeto_local_onboarded_businesses_v1'
            ) || '[]';
          const localOnbList: BusinessItem[] = JSON.parse(localOnbRaw);
          const filteredLocal = localOnbList.filter(
            (item) =>
              item &&
              item.id !== businessId &&
              item.slug !== businessId &&
              item.id !== targetBiz?.id &&
              item.slug !== targetBiz?.slug
          );
          window.localStorage.setItem(
            'timeto_local_onboarded_businesses_v1',
            JSON.stringify(filteredLocal)
          );
          setAppointments((prevApts) => {
            const cleanedApts = prevApts.filter(
              (a) =>
                a.businessId !== businessId &&
                a.businessSlug !== businessId &&
                a.businessId !== targetBiz?.id &&
                a.businessSlug !== targetBiz?.slug
            );
            persistSavedAppointments(cleanedApts);
            return cleanedApts;
          });
        }
      } catch {
        // ignore
      }
      return next;
    });

    // ثبت فوری شناسه کسب‌وکار در لیست بررسی‌شده‌های مدیر کل تا بلافاصله از صف بررسی خارج شود
    setAdminReviewedBizIds((prev) => {
      const nextSet = new Set(prev);
      nextSet.add(businessId);
      if (targetBiz?.id) nextSet.add(targetBiz.id);
      if (targetBiz?.slug) nextSet.add(targetBiz.slug);
      const nextArr = Array.from(nextSet);
      try {
        window.localStorage.setItem(
          'timeto_admin_reviewed_biz_ids_v1',
          JSON.stringify(nextArr)
        );
      } catch {
        // ignore
      }
      return nextArr;
    });

    // علامت‌گذاری اعلان مربوط به این کسب‌وکار به عنوان خوانده‌شده
    setAdminNotifications((prev) => {
      const next = prev.map((n) =>
        n.businessId === businessId ? { ...n, isRead: true } : n
      );
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    if (dataMode === 'real') {
      void realApiClient
        .updateBusinessApproval(businessId, status, updatedTargetBiz ?? targetBiz)
        .then(() => {
          setBusinesses((prev) => mergeBusinessOverrides(prev, adminUsers));
          showToast(
            status === 'APPROVED'
              ? 'کسب‌وکار با موفقیت تایید شد، از صف بررسی خارج گردید و پروفایل آن در اپلیکیشن منتشر شد.'
              : 'کسب‌وکار رد شد و از صف بررسی خارج گردید.',
            status === 'APPROVED' ? 'success' : 'warning'
          );
        })
        .catch(() => {
          setBusinesses((prev) => mergeBusinessOverrides(prev, adminUsers));
          showToast(
            status === 'APPROVED'
              ? 'کسب‌وکار تایید شد و از صف بررسی خارج گردید.'
              : 'وضعیت کسب‌وکار به «ردشده» تغییر یافت و از صف خارج شد.',
            status === 'APPROVED' ? 'success' : 'warning'
          );
        });
      return;
    }

    showToast(
      status === 'APPROVED'
        ? 'وضعیت کسب‌وکار به «تاییدشده» تغییر یافت و از صف بررسی خارج شد.'
        : 'کسب‌وکار رد صلاحیت شد و از صف بررسی به زباله‌دان منتقل گردید.',
      status === 'APPROVED' ? 'success' : 'warning'
    );
  };

  const grantBusinessPlanOrAdByAdmin = (input: {
    businessId: string;
    grantType: 'PLAN' | 'SPONSORED_AD' | 'BOTH' | 'VIP_AMBASSADOR';
    planId?: string;
    durationDays: number;
    isTrialGift?: boolean;
    sponsoredPlacement?: SponsoredPlacementSlot;
    sponsoredLabel?: string;
    bonusSmsCount?: number;
    isVipPartner?: boolean;
    vipCommissionPercent?: number;
  }) => {
    const targetBiz = businesses.find((b) => b.id === input.businessId);
    const days = Math.max(1, Math.min(365, Number(input.durationDays) || 30));
    const expiresAtMs = Date.now() + days * 24 * 60 * 60 * 1000;
    const expiresJalali = (() => {
      try {
        const fmt = new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
          timeZone: 'Asia/Tehran',
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
        });
        return fmt.format(new Date(expiresAtMs));
      } catch {
        return `تا ${toPersianDigits(days)} روز آینده`;
      }
    })();

    const patch: Partial<BusinessItem> = {};
    const grantedSummaryParts: string[] = [];

    if (input.grantType === 'VIP_AMBASSADOR' || input.isVipPartner) {
      const vipRate =
        typeof input.vipCommissionPercent === 'number' &&
        input.vipCommissionPercent >= 0
          ? input.vipCommissionPercent
          : 0;
      patch.isVipPartner = true;
      patch.verifiedBadge = true;
      patch.vipCommissionPercent = vipRate;
      patch.subscriptionPlan = '👑 سفیر برند و سالن منتخب تایم‌تو (VIP)';
      patch.subscriptionStatus = SubscriptionStatus.Active;
      patch.trialDaysRemaining = days;
      patch.planExpiresAtMs = expiresAtMs;
      patch.isSponsored = true;
      patch.featured = true;
      patch.sponsoredPlacement = input.sponsoredPlacement || 'HERO_SPOTLIGHT';
      patch.sponsoredOrder = 1;
      patch.sponsoredDaysRemaining = days;
      patch.sponsoredExpiresAtMs = expiresAtMs;
      patch.sponsoredExpiresJalali = expiresJalali;
      patch.sponsoredLabel =
        input.sponsoredLabel?.trim() || '👑 سالن منتخب تایم‌تو (سفیر برند)';
      grantedSummaryParts.push(
        `بسته ویژه «👑 سفیر برند / سالن منتخب تایم‌تو» با کارمزد اختصاصی ${toPersianDigits(vipRate)}٪${vipRate === 0 ? ' (معافیت کامل کارمزد)' : ''}`
      );
      grantedSummaryParts.push('جایگاه اول ویترین هیرو و نشان تایید طلایی');
    } else {
      if (input.grantType === 'PLAN' || input.grantType === 'BOTH') {
        const foundPlan =
          plans.find((p) => p.id === input.planId) ??
          plans.find((p) => p.id === 'plan-professional') ??
          plans[1] ??
          plans[0];
        patch.subscriptionPlan = foundPlan?.name || 'حرفه‌ای (پرفروش)';
        patch.subscriptionStatus = input.isTrialGift
          ? SubscriptionStatus.Trial
          : SubscriptionStatus.Active;
        patch.trialDaysRemaining = days;
        patch.planExpiresAtMs = expiresAtMs;
        grantedSummaryParts.push(
          `پلن «${patch.subscriptionPlan}» (${input.isTrialGift ? 'تست هدیه' : 'فعال'})`
        );
      }

      if (input.grantType === 'SPONSORED_AD' || input.grantType === 'BOTH') {
        const placement = input.sponsoredPlacement || 'SEARCH_TOP';
        patch.isSponsored = true;
        patch.featured = true;
        patch.sponsoredPlacement = placement;
        patch.sponsoredOrder = placement === 'HERO_SPOTLIGHT' ? 1 : 2;
        patch.sponsoredDaysRemaining = days;
        patch.sponsoredExpiresAtMs = expiresAtMs;
        patch.sponsoredExpiresJalali = expiresJalali;
        patch.sponsoredLabel =
          input.sponsoredLabel?.trim() ||
          (input.isTrialGift
            ? '★ پیشنهاد ویژه (تست هدیه مدیریت)'
            : '★ پیشنهاد ویژه رزرو آنلاین');
        grantedSummaryParts.push(
          `جایگاه تبلیغاتی ویژه (${
            placement === 'HERO_SPOTLIGHT'
              ? 'ویترین اول هیرو'
              : placement === 'HOME_BANNER'
                ? 'بنر صفحه اول'
                : 'صدر نتایج جست‌وجو'
          })`
        );
      }

      if (
        typeof input.vipCommissionPercent === 'number' &&
        input.vipCommissionPercent >= 0
      ) {
        patch.vipCommissionPercent = input.vipCommissionPercent;
        patch.isVipPartner = true;
        grantedSummaryParts.push(
          `تعرفه کارمزد اختصاصی ${toPersianDigits(input.vipCommissionPercent)}٪`
        );
      }
    }

    if (input.bonusSmsCount && input.bonusSmsCount > 0) {
      patch.extraSmsBalance =
        (targetBiz?.extraSmsBalance ?? 0) + Number(input.bonusSmsCount);
      grantedSummaryParts.push(
        `${toPersianDigits(input.bonusSmsCount)} پیامک هدیه باشگاه مشتریان`
      );
    }

    updateBusinessProfile(input.businessId, patch);

    sendPlatformBusinessNotice({
      targetBusinessId: input.businessId,
      targetBusinessName: targetBiz?.name || 'کسب‌وکار شما',
      title:
        input.grantType === 'VIP_AMBASSADOR' || input.isVipPartner
          ? `👑 تبریک! سالن شما به عنوان «سفیر برند و سالن منتخب تایم‌تو (VIP)» برگزیده شد`
          : input.isTrialGift
            ? `🎁 فعال‌سازی تست هدیه ${toPersianDigits(days)} روزه توسط مدیریت تایم‌تو`
            : `✅ فعال‌سازی اشتراک و جایگاه ویژه (${toPersianDigits(days)} روزه)`,
      message: `${grantedSummaryParts.join(' + ')} به مدت ${toPersianDigits(
        days
      )} روز (تا تاریخ ${expiresJalali}) برای کسب‌وکار شما فعال گردید. روزشمار اعتبار در بالای پنل شما قابل مشاهده است.`,
    });

    showToast(
      `${grantedSummaryParts.join(' و ')} به مدت ${toPersianDigits(
        days
      )} روز برای «${targetBiz?.name || 'کسب‌وکار'}» فعال شد.`
    );
  };

  const permanentlyDeleteBusiness = (businessId: string) => {
    const targetBiz = businesses.find((b) => b.id === businessId);
    setBusinesses((prev) =>
      prev.filter(
        (b) =>
          b.id !== businessId &&
          (!targetBiz?.name || b.name.trim() !== targetBiz.name.trim())
      )
    );
    setServices((prev) => prev.filter((s) => s.businessId !== businessId));
    setSpecialists((prev) => prev.filter((sp) => sp.businessId !== businessId));

    try {
      const permRaw =
        window.localStorage.getItem('timeto_permanently_deleted_biz_ids_v1') ||
        '[]';
      const permList: string[] = JSON.parse(permRaw);
      const tokensToSave = [
        businessId,
        targetBiz?.slug,
        targetBiz?.name?.trim(),
      ].filter(Boolean) as string[];
      for (const tok of tokensToSave) {
        if (!permList.includes(tok)) {
          permList.push(tok);
        }
      }
      window.localStorage.setItem(
        'timeto_permanently_deleted_biz_ids_v1',
        JSON.stringify(permList)
      );

      const ovRaw =
        window.localStorage.getItem('timeto_biz_overrides_v2') || '{}';
      const ov = JSON.parse(ovRaw);
      if (ov[businessId]) {
        delete ov[businessId];
        window.localStorage.setItem(
          'timeto_biz_overrides_v2',
          JSON.stringify(ov)
        );
      }

      const localOnbRaw =
        window.localStorage.getItem('timeto_local_onboarded_businesses_v1') ||
        '[]';
      const localOnbList: BusinessItem[] = JSON.parse(localOnbRaw);
      const filteredOnb = localOnbList.filter(
        (lb) =>
          lb.id !== businessId &&
          (!targetBiz?.name || lb.name.trim() !== targetBiz.name.trim())
      );
      window.localStorage.setItem(
        'timeto_local_onboarded_businesses_v1',
        JSON.stringify(filteredOnb)
      );
    } catch {
      // ignore
    }

    if (dataMode === 'real') {
      const token =
        typeof window !== 'undefined'
          ? window.localStorage.getItem('beautyhub_session_token')
          : null;
      void fetch(`/api/v1/admin/businesses/${encodeURIComponent(businessId)}`, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      }).catch(() => {});
    }

    showToast(
      `کسب‌وکار «${targetBiz?.name || businessId}» برای همیشه از زباله‌دان و تمام دستگاه‌ها حذف شد.`,
      'danger'
    );
  };

  const sendPlatformBusinessNotice = (input: {
    targetBusinessId: 'ALL' | string;
    targetBusinessName?: string;
    title: string;
    message: string;
  }): PlatformBusinessNoticeItem => {
    const item: PlatformBusinessNoticeItem = {
      id: `pbn-${Date.now()}`,
      targetBusinessId: input.targetBusinessId,
      targetBusinessName:
        input.targetBusinessId === 'ALL'
          ? 'همه کسب‌وکارها'
          : input.targetBusinessName,
      title: input.title.trim() || 'اطلاعیه مدیریت پلتفرم تایم‌تو',
      message: input.message.trim(),
      createdAtJalali: 'امروز',
      readByBusinessIds: [],
    };

    setPlatformBusinessNotices((prev) => {
      const next = [item, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_platform_business_notices_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void realApiClient
          .savePlatformSharedState({ platformBusinessNotices: next })
          .catch(() => {});
      }
      return next;
    });

    // باز کردن خودکار آکاردئون استوری‌ها و اطلاعیه‌ها برای صاحب کسب‌وکار هنگام دریافت پیام جدید
    try {
      window.localStorage.setItem('timeto_stories_accordion_collapsed_v1', '0');
    } catch {
      // ignore
    }

    showToast(
      input.targetBusinessId === 'ALL'
        ? 'اطلاعیه سراسری برای تمام صاحبان کسب‌وکار ارسال شد و در پنل آن‌ها نمایش داده می‌شود.'
        : `پیام و اعلان مستقیم برای «${input.targetBusinessName || 'کسب‌وکار'}» ارسال شد.`
    );
    return item;
  };

  const markPlatformBusinessNoticeRead = (
    noticeId: string,
    businessId?: string
  ) => {
    const resolvedBizId = businessId || currentBusiness?.id || 'biz-owner-zero';
    setPlatformBusinessNotices((prev) => {
      const next = prev.map((n) => {
        if (n.id !== noticeId) return n;
        if (n.readByBusinessIds.includes(resolvedBizId)) return n;
        return {
          ...n,
          readByBusinessIds: [...n.readByBusinessIds, resolvedBizId],
        };
      });
      try {
        window.localStorage.setItem(
          'timeto_platform_business_notices_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void realApiClient
          .savePlatformSharedState({ platformBusinessNotices: next })
          .catch(() => {});
      }
      return next;
    });
  };

  const persistLocalServices = (list: ServiceItem[]) => {
    try {
      window.localStorage.setItem(
        'timeto_local_services_v1',
        JSON.stringify(list)
      );
    } catch {
      // ignore
    }
  };

  const addService = (item: Omit<ServiceItem, 'id'>) => {
    const targetBiz =
      businesses.find((b) => b.id === item.businessId) ?? currentBusiness;
    const antiFraudCheck = validateServiceAntiFraud({
      title: item.title,
      description: item.description,
      priceToman: item.priceToman,
      business: targetBiz,
    });
    if (!antiFraudCheck.valid) {
      showToast(
        antiFraudCheck.error || 'اطلاعات یا تعرفه خدمت معتبر نیست.',
        'warning'
      );
      return;
    }

    const applyAddLocal = (resolvedItem: ServiceItem) => {
      setServices((prev) => {
        const seenIds = new Set<string>();
        const deduplicated = [resolvedItem, ...prev].map((s) => {
          if (!seenIds.has(s.id)) {
            seenIds.add(s.id);
            return s;
          }
          const fixedId = makeUniqueId('srv');
          seenIds.add(fixedId);
          return { ...s, id: fixedId };
        });
        persistLocalServices(deduplicated);
        setBusinesses((bizPrev) =>
          syncStartingPricesWithServices(bizPrev, deduplicated)
        );
        return deduplicated;
      });
    };

    if (dataMode === 'real') {
      void realApiClient
        .createService(item)
        .then((res) => {
          const mergedItem: ServiceItem = {
            ...res.item,
            pricingType: item.pricingType ?? res.item.pricingType,
            maxPriceToman: item.maxPriceToman ?? res.item.maxPriceToman,
            packageIncludes: item.packageIncludes ?? res.item.packageIncludes,
          };
          applyAddLocal(mergedItem);
          showToast(`خدمت «${mergedItem.title}» ثبت شد.`);
        })
        .catch(() => {
          const fallbackItem: ServiceItem = {
            ...item,
            id: makeUniqueId('srv'),
          };
          applyAddLocal(fallbackItem);
          showToast(`خدمت «${item.title}» به فهرست خدمات اضافه شد.`);
        });
      return;
    }

    const newItem: ServiceItem = {
      ...item,
      id: makeUniqueId('srv'),
    };
    applyAddLocal(newItem);
    showToast(`خدمت «${item.title}» به فهرست اضافه شد.`);
  };

  const updateService = (id: string, patch: Partial<ServiceItem>) => {
    const applyUpdateLocal = (mergedPatch: Partial<ServiceItem>) => {
      setServices((prev) => {
        const next = prev.map((s) =>
          s.id === id ? { ...s, ...mergedPatch } : s
        );
        persistLocalServices(next);
        setBusinesses((bizPrev) =>
          syncStartingPricesWithServices(bizPrev, next)
        );
        return next;
      });
    };

    if (dataMode === 'real') {
      void realApiClient
        .updateService(id, patch)
        .then((res) => {
          applyUpdateLocal({
            ...res.item,
            pricingType: patch.pricingType,
            maxPriceToman: patch.maxPriceToman,
            packageIncludes: patch.packageIncludes,
          });
          showToast('ویرایش خدمت ذخیره شد.');
        })
        .catch(() => {
          applyUpdateLocal(patch);
          showToast('ویرایش خدمت ذخیره شد.');
        });
      return;
    }

    applyUpdateLocal(patch);
    showToast('ویرایش خدمت ذخیره شد.');
  };

  const deleteService = (id: string) => {
    const applyDeleteLocal = () => {
      setServices((prev) => {
        const next = prev.filter((s) => s.id !== id);
        persistLocalServices(next);
        setBusinesses((bizPrev) =>
          syncStartingPricesWithServices(bizPrev, next)
        );
        return next;
      });
    };

    if (dataMode === 'real') {
      void realApiClient
        .deleteService(id)
        .then(() => {
          applyDeleteLocal();
          showToast('خدمت انتخاب‌شده حذف شد.', 'warning');
        })
        .catch(() => {
          applyDeleteLocal();
          showToast('خدمت انتخاب‌شده از فهرست حذف شد.', 'warning');
        });
      return;
    }

    applyDeleteLocal();
    showToast('خدمت انتخاب‌شده از فهرست حذف شد.', 'warning');
  };

  const reorderBusinessServices = (
    businessId: string,
    orderedServiceIds: string[]
  ) => {
    if (!businessId || orderedServiceIds.length === 0) return;
    setServices((prev) => {
      const orderLookup = new Map<string, number>();
      orderedServiceIds.forEach((id, index) => {
        orderLookup.set(id, index + 1);
      });

      try {
        const rawOrder = window.localStorage.getItem('timeto_service_sort_order_v1');
        const savedOrderMap: Record<string, number> = rawOrder
          ? JSON.parse(rawOrder)
          : {};
        orderedServiceIds.forEach((id, index) => {
          savedOrderMap[id] = index + 1;
        });
        window.localStorage.setItem(
          'timeto_service_sort_order_v1',
          JSON.stringify(savedOrderMap)
        );
      } catch {
        // ignore storage errors
      }

      const bizItems: ServiceItem[] = [];
      const otherItems: ServiceItem[] = [];
      prev.forEach((srv, idx) => {
        if (srv.businessId === businessId) {
          bizItems.push({
            ...srv,
            sortOrder: orderLookup.get(srv.id) ?? 5000 + idx,
          });
        } else {
          otherItems.push(srv);
        }
      });

      bizItems.sort((a, b) => (a.sortOrder ?? 9999) - (b.sortOrder ?? 9999));
      const next = [...bizItems, ...otherItems];
      persistLocalServices(next);
      return next;
    });
  };

  const persistLocalSpecialists = (list: SpecialistItem[]) => {
    try {
      window.localStorage.setItem(
        'timeto_local_specialists_v1',
        JSON.stringify(list)
      );
    } catch {
      // ignore
    }
  };

  const addSpecialist = (item: Omit<SpecialistItem, 'id'>) => {
    const fallbackItem: SpecialistItem = {
      ...item,
      id: makeUniqueId('spc'),
    };
    if (dataMode === 'real') {
      void realApiClient
        .createSpecialist(item)
        .then((res) => {
          const mergedSpc: SpecialistItem = {
            ...res.item,
            avatarUrl: item.avatarUrl || res.item.avatarUrl,
          };
          setSpecialists((prev) => {
            const next = [mergedSpc, ...prev];
            persistLocalSpecialists(next);
            return next;
          });
          showToast(`متخصص «${res.item.fullName}» در پایگاه داده ثبت شد.`);
        })
        .catch(() => {
          setSpecialists((prev) => {
            const next = [fallbackItem, ...prev];
            persistLocalSpecialists(next);
            return next;
          });
          showToast(`متخصص «${item.fullName}» به تیم اضافه شد.`);
        });
      return;
    }

    setSpecialists((prev) => {
      const next = [fallbackItem, ...prev];
      persistLocalSpecialists(next);
      return next;
    });
    showToast(`متخصص «${item.fullName}» به تیم اضافه شد.`);
  };

  const updateSpecialist = (id: string, patch: Partial<SpecialistItem>) => {
    if (dataMode === 'real') {
      void realApiClient
        .updateSpecialist(id, patch)
        .then((res) => {
          setSpecialists((prev) => {
            const next = prev.map((sp) =>
              sp.id === id
                ? {
                    ...res.item,
                    avatarUrl:
                      patch.avatarUrl !== undefined
                        ? patch.avatarUrl
                        : res.item.avatarUrl ?? sp.avatarUrl,
                  }
                : sp
            );
            persistLocalSpecialists(next);
            return next;
          });
          showToast('اطلاعات و تصویر متخصص در پایگاه داده بروزرسانی شد.');
        })
        .catch(() => {
          setSpecialists((prev) => {
            const next = prev.map((sp) =>
              sp.id === id ? { ...sp, ...patch } : sp
            );
            persistLocalSpecialists(next);
            return next;
          });
          showToast('اطلاعات متخصص بروزرسانی شد.');
        });
      return;
    }

    setSpecialists((prev) => {
      const next = prev.map((sp) => (sp.id === id ? { ...sp, ...patch } : sp));
      persistLocalSpecialists(next);
      return next;
    });
    showToast('اطلاعات متخصص بروزرسانی شد.');
  };

  // کیف پول مشتریان (شارژ، پرداخت رزرو، بازگشت خودکار بیعانه لغو نوبت و برداشت به کارت/شبا)
  const [allCustomerWalletTxs, setAllCustomerWalletTxs] = useState<
    CustomerWalletTransactionItem[]
  >(() => {
    try {
      const raw = window.localStorage.getItem('timeto_customer_wallet_txs_v1');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });

  const persistCustomerWalletTxs = (next: CustomerWalletTransactionItem[]) => {
    try {
      window.localStorage.setItem(
        'timeto_customer_wallet_txs_v1',
        JSON.stringify(next)
      );
    } catch {
      // ignore
    }
  };

  const normalizeCustomerPhoneKey = (raw?: string | null): string => {
    const digits = String(raw || '')
      .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
      .replace(/\D/g, '');
    if (digits.length === 10 && digits.startsWith('9')) return `0${digits}`;
    if (digits.length === 12 && digits.startsWith('989'))
      return `0${digits.slice(2)}`;
    return digits;
  };

  const activeCustomerPhone =
    normalizeCustomerPhoneKey(authUser?.phone || bookingDraft.customerPhone) ||
    'guest';

  const customerWalletTransactions = React.useMemo(() => {
    if (!activeCustomerPhone || activeCustomerPhone === 'guest') return [];
    return allCustomerWalletTxs.filter(
      (tx) => normalizeCustomerPhoneKey(tx.customerPhone) === activeCustomerPhone
    );
  }, [allCustomerWalletTxs, activeCustomerPhone]);

  const customerWalletBalanceToman = React.useMemo(() => {
    let bal = 0;
    for (const tx of customerWalletTransactions) {
      if (tx.type === 'TOPUP' || tx.type === 'REFUND_CANCEL') {
        bal += tx.amountToman;
      } else if (
        tx.type === 'BOOKING_PAYMENT' ||
        tx.type === 'WITHDRAWAL_REQUEST'
      ) {
        bal -= tx.amountToman;
      }
    }
    return Math.max(0, bal);
  }, [customerWalletTransactions]);

  const topUpCustomerWallet = (
    amountToman: number,
    trackingCode?: string,
    targetPhone?: string,
    targetName?: string
  ): CustomerWalletTransactionItem => {
    const resolvedPhone =
      normalizeCustomerPhoneKey(targetPhone) || activeCustomerPhone;
    const resolvedName =
      targetName?.trim() ||
      authUser?.fullName ||
      bookingDraft.customerName ||
      'کاربر تایم تو';
    const cleanTracking =
      trackingCode?.trim() ||
      `ZP-${Math.floor(10000000 + Math.random() * 90000000)}`;

    // جلوگیری از ثبت مضاعف یک کد رهگیری یکسان
    const existingTx = allCustomerWalletTxs.find(
      (item) =>
        item.type === 'TOPUP' &&
        item.trackingCode === cleanTracking &&
        normalizeCustomerPhoneKey(item.customerPhone) === resolvedPhone
    );
    if (existingTx) {
      return existingTx;
    }

    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';
    const tx: CustomerWalletTransactionItem = {
      id: makeUniqueId('cwtx'),
      customerPhone: resolvedPhone,
      customerName: resolvedName,
      type: 'TOPUP',
      amountToman: Math.max(0, Math.round(amountToman)),
      title: 'شارژ کیف پول از درگاه شاپرک',
      description: `افزایش موجودی کیف پول از طریق درگاه بانکی (${resolvedPhone})`,
      trackingCode: cleanTracking,
      createdAtJalali: todayJalali,
      createdAtMs: Date.now(),
    };
    setAllCustomerWalletTxs((prev) => {
      if (
        prev.some(
          (item) =>
            item.type === 'TOPUP' &&
            item.trackingCode === cleanTracking &&
            normalizeCustomerPhoneKey(item.customerPhone) === resolvedPhone
        )
      ) {
        return prev;
      }
      const next = [tx, ...prev];
      persistCustomerWalletTxs(next);
      return next;
    });
    showToast(
      `کیف پول شما به مبلغ ${formatPriceToman(amountToman)} با موفقیت شارژ شد ✓`
    );
    return tx;
  };

  const payFromCustomerWallet = (
    amountToman: number,
    title: string,
    description: string
  ): { ok: boolean; trackingCode: string } => {
    const cleanAmt = Math.max(0, Math.round(amountToman));
    if (customerWalletBalanceToman < cleanAmt) {
      showToast(
        'موجودی کیف پول شما برای این پرداخت کافی نیست. لطفاً ابتدا کیف پول را شارژ کنید.',
        'warning'
      );
      return { ok: false, trackingCode: '' };
    }
    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';
    const code = `WL-${Math.floor(10000000 + Math.random() * 90000000)}`;
    const tx: CustomerWalletTransactionItem = {
      id: makeUniqueId('cwtx'),
      customerPhone: activeCustomerPhone,
      customerName:
        authUser?.fullName || bookingDraft.customerName || 'کاربر تایم تو',
      type: 'BOOKING_PAYMENT',
      amountToman: cleanAmt,
      title,
      description,
      trackingCode: code,
      createdAtJalali: todayJalali,
      createdAtMs: Date.now(),
    };
    setAllCustomerWalletTxs((prev) => {
      const next = [tx, ...prev];
      persistCustomerWalletTxs(next);
      return next;
    });
    return { ok: true, trackingCode: code };
  };

  const requestCustomerWalletWithdrawal = (
    amountToman: number,
    bankCardOrSheba: string
  ): CustomerWalletTransactionItem | null => {
    const cleanAmt = Math.max(0, Math.round(amountToman));
    if (cleanAmt <= 0 || cleanAmt > customerWalletBalanceToman) {
      showToast('مبلغ درخواستی معتبر نیست یا بیش از موجودی کیف پول است.', 'warning');
      return null;
    }
    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';
    const tx: CustomerWalletTransactionItem = {
      id: makeUniqueId('cwtx'),
      customerPhone: activeCustomerPhone,
      customerName:
        authUser?.fullName || bookingDraft.customerName || 'کاربر تایم تو',
      type: 'WITHDRAWAL_REQUEST',
      amountToman: cleanAmt,
      title: 'درخواست تسویه و واریز به کارت / شبا',
      description: `واریز به حساب مقصد: ${bankCardOrSheba}`,
      trackingCode: `WD-${Math.floor(10000000 + Math.random() * 90000000)}`,
      bankCardOrSheba,
      withdrawalStatus: 'PENDING',
      createdAtJalali: todayJalali,
      createdAtMs: Date.now(),
    };
    setAllCustomerWalletTxs((prev) => {
      const next = [tx, ...prev];
      persistCustomerWalletTxs(next);
      return next;
    });
    showToast(
      `درخواست برداشت ${formatPriceToman(cleanAmt)} به حساب بانکی شما ثبت شد و در سیکل پایا واریز می‌گردد ✓`
    );
    return tx;
  };

  const updateAppointmentStatus = (
    id: string,
    status: AppointmentStatus,
    cancelledByRole?: 'CUSTOMER' | 'BUSINESS_OWNER',
    customRefundAmountToman?: number
  ) => {
    const targetApt = appointments.find((a) => a.id === id);

    // محاسبه مبلغ بازگشت بیعانه به کیف پول مشتری در صورت لغو نوبت
    let refundedAmount = 0;
    if (
      status === AppointmentStatus.Cancelled &&
      targetApt &&
      targetApt.status !== AppointmentStatus.Cancelled &&
      !targetApt.refundedToWalletToman
    ) {
      const targetBiz = businesses.find((b) => b.id === targetApt.businessId);
      const depositPct = normalizeDepositPercent(targetBiz?.depositPercent);
      const baseDepositPaid =
        targetApt.depositPaidToman && targetApt.depositPaidToman > 0
          ? targetApt.depositPaidToman
          : Math.round((targetApt.priceToman || 300000) * (depositPct / 100));

      if (typeof customRefundAmountToman === 'number') {
        refundedAmount = Math.max(0, Math.round(customRefundAmountToman));
      } else if (cancelledByRole === 'BUSINESS_OWNER') {
        // اگر خودِ صاحب کسب‌وکار نوبت را لغو کند، ۱۰۰٪ بیعانه بدون هیچ کسری به کیف پول مشتری برمی‌گردد
        refundedAmount = baseDepositPaid;
      } else {
        refundedAmount = baseDepositPaid;
      }

      if (refundedAmount > 0) {
        const rawAptPhone = (
          targetApt.customerPhoneMasked ||
          authUser?.phone ||
          'guest'
        )
          .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
          .replace(/\D/g, '');
        const resolvedPhone =
          rawAptPhone.length === 11 ? rawAptPhone : activeCustomerPhone;
        const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';
        const refundTx: CustomerWalletTransactionItem = {
          id: makeUniqueId('cwtx'),
          customerPhone: resolvedPhone,
          customerName:
            targetApt.customerName || authUser?.fullName || 'کاربر تایم تو',
          type: 'REFUND_CANCEL',
          amountToman: refundedAmount,
          title: `بازگشت بیعانه لغو نوبت (${targetApt.businessName})`,
          description: `استرداد آنی بیعانه خدمت «${targetApt.serviceTitle}» کد پیگیری ${targetApt.referenceCode}`,
          trackingCode: `RF-${Math.floor(10000000 + Math.random() * 90000000)}`,
          createdAtJalali: todayJalali,
          createdAtMs: Date.now(),
        };
        setAllCustomerWalletTxs((prev) => {
          const next = [refundTx, ...prev];
          persistCustomerWalletTxs(next);
          return next;
        });

        // کسر مبلغ بیعانه برگشتی از کیف پول سالن
        if (targetBiz && (targetBiz.walletBalanceToman ?? 0) > 0) {
          updateBusinessProfile(targetBiz.id, {
            walletBalanceToman: Math.max(
              0,
              (targetBiz.walletBalanceToman ?? 0) - refundedAmount
            ),
          });
        }
      }
    }

    setAppointments((prev) => {
      const next = prev.map((a) =>
        a.id === id
          ? {
              ...a,
              status,
              refundedToWalletToman:
                refundedAmount > 0 ? refundedAmount : a.refundedToWalletToman,
            }
          : a
      );
      persistSavedAppointments(next);
      return next;
    });

    // ارسال پیامک به مشتری صرفاً پس از تایید یا رد/لغو توسط صاحب کسب‌وکار
    if (
      targetApt &&
      (status === AppointmentStatus.Confirmed ||
        status === AppointmentStatus.Cancelled)
    ) {
      void fetch('/api/v1/appointments/notify-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appointmentId: id,
          status,
          customerName: targetApt.customerName,
          customerPhone: targetApt.customerPhoneMasked,
          businessName: targetApt.businessName,
          serviceTitle: targetApt.serviceTitle,
          dateJalali: targetApt.dateJalali,
          timeSlot: targetApt.timeSlot,
        }),
      }).catch(() => {});
    }

    if (dataMode === 'real') {
      void realApiClient
        .updateAppointmentStatus(id, status)
        .then(() => {
          showToast(
            status === AppointmentStatus.Cancelled && refundedAmount > 0
              ? `نوبت لغو شد، پیامک اطلاع‌رسانی برای مشتری ارسال گردید و مبلغ ${formatPriceToman(refundedAmount)} بابت بازگشت بیعانه فوراً به کیف پول مشتری واریز شد ✓`
              : status === AppointmentStatus.Confirmed
              ? 'نوبت با موفقیت تایید شد و پیامک تایید نوبت برای مشتری ارسال گردید ✓'
              : 'وضعیت نوبت بروزرسانی شد.'
          );
        })
        .catch(() => {
          showToast(
            status === AppointmentStatus.Cancelled && refundedAmount > 0
              ? `نوبت لغو شد، پیامک اطلاع‌رسانی برای مشتری ارسال گردید و مبلغ ${formatPriceToman(refundedAmount)} بابت بازگشت بیعانه فوراً به کیف پول مشتری واریز شد ✓`
              : status === AppointmentStatus.Confirmed
              ? 'نوبت با موفقیت تایید شد و پیامک تایید برای مشتری ارسال گردید ✓'
              : 'وضعیت نوبت بروزرسانی شد.'
          );
        });
      return;
    }

    showToast(
      status === AppointmentStatus.Cancelled && refundedAmount > 0
        ? `نوبت لغو شد، پیامک اطلاع‌رسانی برای مشتری ارسال گردید و مبلغ ${formatPriceToman(refundedAmount)} بابت بازگشت بیعانه فوراً به کیف پول مشتری واریز شد ✓`
        : status === AppointmentStatus.Confirmed
        ? 'نوبت با موفقیت تایید شد و پیامک تایید برای مشتری ارسال گردید ✓'
        : 'وضعیت نوبت بروزرسانی شد.'
    );
  };

  const addDailyIncomeLog = (
    input: Omit<DailyIncomeLogItem, 'id' | 'createdAtJalali'>
  ): DailyIncomeLogItem => {
    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';
    const newItem: DailyIncomeLogItem = {
      ...input,
      id: makeUniqueId('inc'),
      dateJalali: input.dateJalali || todayJalali,
      createdAtJalali: todayJalali,
    };
    setDailyIncomeLogs((prev) => {
      const next = [newItem, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_daily_income_logs_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    showToast('دریافتی حضوری با موفقیت در حسابداری و دخل روزانه ثبت شد.');
    return newItem;
  };

  const deleteDailyIncomeLog = (id: string) => {
    setDailyIncomeLogs((prev) => {
      const next = prev.filter((item) => item.id !== id);
      try {
        window.localStorage.setItem(
          'timeto_daily_income_logs_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    showToast('ردیف دریافتی حضوری از لیست دخل روزانه حذف شد.', 'info');
  };

  const [businessStories, setBusinessStories] = useState<BusinessStoryItem[]>(
    () => {
      try {
        const raw = window.localStorage.getItem('timeto_business_stories_v1');
        if (raw) {
          const parsed = JSON.parse(raw) as BusinessStoryItem[];
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {
        // ignore
      }
      return [];
    }
  );

  const addBusinessStory = (
    input: Omit<BusinessStoryItem, 'id' | 'createdAtJalali' | 'createdAtMs'>
  ): BusinessStoryItem => {
    const todayJalali = getUpcomingJalaliDays(1)[0]?.date || '۱۴۰۵/۰۸/۱۱';
    const newStory: BusinessStoryItem = {
      ...input,
      id: makeUniqueId('story'),
      createdAtJalali: todayJalali,
      createdAtMs: Date.now(),
    };
    setBusinessStories((prev) => {
      const next = [newStory, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_business_stories_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    showToast('استوری / هایلایت ویژه شما در بالای پروفایل سالن منتشر شد ✓');
    return newStory;
  };

  const deleteBusinessStory = (id: string) => {
    setBusinessStories((prev) => {
      const next = prev.filter((s) => s.id !== id);
      try {
        window.localStorage.setItem(
          'timeto_business_stories_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    showToast('استوری از پروفایل سالن حذف شد.', 'info');
  };

  const settleAppointmentInPerson = (
    appointmentId: string,
    customAmountToman?: number
  ) => {
    const targetApt = appointments.find((a) => a.id === appointmentId);
    if (!targetApt) return;
    if (targetApt.inPersonSettled) {
      showToast('تسویه حضوری این نوبت قبلاً ثبت شده است.', 'info');
      return;
    }

    const matchedBiz = businesses.find(
      (b) =>
        b.id === targetApt.businessId ||
        b.slug === targetApt.businessSlug ||
        b.name === targetApt.businessName
    );
    const aptBreakdown = resolveAppointmentFinancialBreakdown({
      appointment: targetApt,
      business: matchedBiz,
    });
    const alreadyPaidDeposit = aptBreakdown.baseDepositToman;
    const defaultRemaining = aptBreakdown.remainingInSalonToman;
    const resolvedAmount =
      customAmountToman && customAmountToman > 0
        ? customAmountToman
        : defaultRemaining;
    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';

    setAppointments((prev) => {
      const next = prev.map((a) =>
        a.id === appointmentId
          ? {
              ...a,
              status: AppointmentStatus.Completed,
              inPersonSettled: true,
              inPersonSettledAmountToman: resolvedAmount,
              inPersonSettledAtJalali: todayJalali,
            }
          : a
      );
      persistSavedAppointments(next);
      return next;
    });

    addDailyIncomeLog({
      businessId: targetApt.businessId,
      dateJalali: targetApt.dateJalali || todayJalali,
      amountToman: resolvedAmount,
      paymentMethod: 'APPOINTMENT_SETTLEMENT',
      entryType: 'SINGLE_APPOINTMENT',
      appointmentId: targetApt.id,
      customerName: targetApt.customerName,
      serviceTitle: targetApt.serviceTitle,
      specialistName: targetApt.specialistName,
      note:
        alreadyPaidDeposit > 0
          ? `تسویه الباقی حضوری نوبت (پس از کسر ${formatPriceToman(alreadyPaidDeposit)} بیعانه آنلاین)`
          : 'تسویه کامل حضوری نوبت در سالن',
    });
  };

  const recordSponsoredClick = (businessId: string) => {
    const target = businesses.find((b) => b.id === businessId);
    if (!target) return;
    updateBusinessProfile(businessId, {
      sponsoredClicks: (target.sponsoredClicks ?? 14) + 1,
      sponsoredImpressions: (target.sponsoredImpressions ?? 110) + 4,
    });
  };

  const sendAppointmentReminders = async (
    businessId?: string
  ): Promise<number> => {
    const targetBizId = businessId || currentBusiness?.id;
    const upcoming = appointments.filter(
      (a) =>
        (!targetBizId || a.businessId === targetBizId) &&
        (a.status === AppointmentStatus.Confirmed ||
          a.status === AppointmentStatus.Pending)
    );

    if (upcoming.length === 0) {
      showToast(
        'در حال حاضر نوبت فعالی برای ارسال پیامک یادآور وجود ندارد.',
        'info'
      );
      return 0;
    }

    const itemsPayload = upcoming.map((a) => ({
      phone: a.customerPhoneMasked,
      customerName: a.customerName,
      businessName: a.businessName,
      dateJalali: a.dateJalali,
      timeSlot: a.timeSlot,
    }));

    if (dataMode === 'real') {
      try {
        await fetch('/api/v1/appointments/send-reminders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ items: itemsPayload }),
        });
      } catch {
        // ادامه ثبت در گزارش
      }
    }

    const newLog: SmsMessageLogItem = {
      id: `sms-rem-${Date.now()}`,
      businessId: targetBizId || 'biz-1',
      businessName:
        currentBusiness?.name || upcoming[0]?.businessName || 'سالن زیبایی',
      recipientsCount: upcoming.length,
      recipientPhones: upcoming.map((a) => a.customerPhoneMasked),
      messageText: `یادآوری خودکار نوبت فردا/امروز (پترن خدماتی ملی‌پیامک) برای ${upcoming.length} مراجع`,
      templateTitle: 'یادآور خودکار پیش از نوبت (۳ و ۲۴ ساعت قبل)',
      createdAtJalali: 'امروز',
      status: 'SENT',
    };

    setSmsLogs((prev) => {
      const next = [newLog, ...prev];
      try {
        window.localStorage.setItem('timeto_sms_logs_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });

    showToast(
      `پیامک یادآور پیش از نوبت با موفقیت برای ${upcoming.length} مراجع از طریق خط خدماتی ارسال شد.`
    );
    return upcoming.length;
  };

  const requestWalletSettlement = (
    businessId?: string
  ): SettlementRequestItem | null => {
    const targetBiz =
      businesses.find((b) => b.id === (businessId || currentBusiness?.id)) ??
      currentBusiness;
    if (!targetBiz) {
      showToast('کسب‌وکاری برای تسویه یافت نشد.', 'warning');
      return null;
    }
    if (!targetBiz.contractAccepted) {
      showToast(
        'لطفاً ابتدا در بخش «اطلاعات سالن ← شبا و حساب بانکی»، مفاد قرارداد همکاری و قوانین تسویه را مطالعه و تایید نمایید.',
        'warning'
      );
      return null;
    }
    const rawSheba = (targetBiz.bankShebaNumber || '').trim();
    if (rawSheba.replace(/\D/g, '').length < 24) {
      showToast(
        'لطفاً ابتدا شماره شبا ۲۴ رقمی (IR...) خود را در بخش پروفایل یا کادر تسویه وارد و ذخیره کنید.',
        'warning'
      );
      return null;
    }

    // قفل امنیتی ضدتقلب: بررسی نوبت‌های آینده که هنوز زمان انجامشان نرسیده است
    const bizApts = appointments.filter(
      (a) =>
        (a.businessId === targetBiz.id || a.businessSlug === targetBiz.slug) &&
        a.status !== AppointmentStatus.Cancelled
    );
    const lockedFutureEscrowToman = bizApts
      .filter((a) => !isAppointmentEligibleForSettlement(a))
      .reduce(
        (sum, a) =>
          sum + (a.salonNetDepositCreditedToman ?? a.depositPaidToman ?? 0),
        0
      );

    const dossierNumbers = computeBusinessBookingDossierNumbers(targetBiz);
    const totalWalletBalance = dossierNumbers.pendingPayoutToman;
    const releasableBalance = Math.max(
      0,
      totalWalletBalance - lockedFutureEscrowToman
    );

    if (releasableBalance <= 0) {
      if (lockedFutureEscrowToman > 0) {
        showToast(
          `مبلغ ${lockedFutureEscrowToman.toLocaleString('fa-IR')} تومان مربوط به نوبت‌های آینده است که هنوز زمان انجامشان نرسیده و پس از انجام خدمت قابل برداشت خواهد بود.`,
          'warning'
        );
      } else {
        showToast(
          'موجودی آزادشده و قابل برداشت کیف پول سالن شما در حال حاضر ۰ تومان است.',
          'info'
        );
      }
      return null;
    }

    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';
    const cycleLabel =
      paymentConfig.settlementCycle === 'BIWEEKLY'
        ? 'سیکل دو هفته یک‌بار پایا (۱ و ۱۵ ماه)'
        : 'سیکل هفتگی پایا (شنبه‌ها)';

    const newItem: SettlementRequestItem = {
      id: `STL-${Math.floor(1000 + Math.random() * 9000)}`,
      businessId: targetBiz.id,
      businessName: targetBiz.name,
      ownerName:
        targetBiz.bankAccountHolder || targetBiz.ownerName || 'مدیر سالن',
      ownerPhone: targetBiz.ownerPhone || targetBiz.phoneDisplay || '',
      shebaNumber: rawSheba.startsWith('IR') ? rawSheba : `IR${rawSheba}`,
      cardNumber: targetBiz.bankCardNumber,
      amountToman: releasableBalance,
      commissionToman: dossierNumbers.totalCommissionToman,
      netPayoutToman: releasableBalance,
      createdAtJalali: todayJalali,
      status: 'PENDING',
    };

    setSettlementRequests((prev) => {
      const next = [newItem, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_settlement_requests_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void realApiClient
          .savePlatformSharedState({ settlementRequests: next })
          .catch(() => {});
      }
      return next;
    });

    showToast(
      `درخواست تسویه شبا به مبلغ ${releasableBalance.toLocaleString('fa-IR')} تومان ثبت شد و در ${cycleLabel} به حساب شبای شما واریز می‌گردد ✓`
    );
    return newItem;
  };

  function computeBusinessBookingDossierNumbers(targetBiz: BusinessItem) {
    const bizApts = appointments.filter(
      (a) =>
        (a.businessId === targetBiz.id ||
          a.businessSlug === targetBiz.slug ||
          (a.businessName && a.businessName.trim() === targetBiz.name.trim())) &&
        a.status !== AppointmentStatus.Cancelled &&
        a.status !== AppointmentStatus.NoShow
    );
    let totalServicePriceToman = 0;
    let totalDepositToman = 0;
    let totalCommissionToman = 0;
    let totalSalonNetToman = 0;

    for (const apt of bizApts) {
      const srvPrice = Math.max(0, Number(apt.priceToman) || 350_000);
      const breakdown = calculateBookingFinancialBreakdown({
        totalServicePriceToman: srvPrice,
        depositPercent: targetBiz.depositPercent,
        business: targetBiz,
        commissionConfig: paymentConfig,
      });
      const dep =
        typeof apt.depositPaidToman === 'number' && apt.depositPaidToman > 0
          ? apt.depositPaidToman
          : breakdown.baseDepositToman;
      const comm =
        typeof apt.platformCommissionToman === 'number' &&
        apt.platformCommissionToman >= 0
          ? apt.platformCommissionToman
          : breakdown.platformCommissionToman;
      const net =
        typeof apt.salonNetDepositCreditedToman === 'number' &&
        apt.salonNetDepositCreditedToman >= 0
          ? apt.salonNetDepositCreditedToman
          : Math.max(0, dep - comm);

      totalServicePriceToman += srvPrice;
      totalDepositToman += dep;
      totalCommissionToman += comm;
      totalSalonNetToman += net;
    }

    const commMeta = resolveBusinessCommissionMeta(targetBiz, paymentConfig);
    const depositPercent = normalizeDepositPercent(targetBiz.depositPercent);
    const totalRemainingInSalonToman = Math.max(
      0,
      totalServicePriceToman - totalDepositToman
    );

    const paidSettlementsTotal = settlementRequests
      .filter((s) => s.businessId === targetBiz.id && s.status === 'PAID')
      .reduce((sum, s) => sum + (Number(s.netPayoutToman) || 0), 0);

    const pendingPayoutToman = Math.max(
      0,
      totalSalonNetToman - paidSettlementsTotal
    );

    return {
      bookingsCount: bizApts.length,
      depositPercent,
      commissionPercent: commMeta.commissionPercent,
      totalServicePriceToman,
      totalRemainingInSalonToman,
      totalDepositToman,
      totalCommissionToman,
      totalSalonNetToman,
      paidSettlementsTotal,
      pendingPayoutToman,
    };
  };

  const settleBusinessDossierByAdmin = (
    businessId: string,
    trackingCode?: string
  ): SettlementRequestItem | null => {
    const targetBiz = businesses.find((b) => b.id === businessId);
    if (!targetBiz) {
      showToast('کسب‌وکار مورد نظر یافت نشد.', 'warning');
      return null;
    }

    const dossier = computeBusinessBookingDossierNumbers(targetBiz);
    const payoutAmount = dossier.pendingPayoutToman;
    if (payoutAmount <= 0 && dossier.bookingsCount === 0) {
      showToast(
        `برای سالن «${targetBiz.name}» هنوز رزروی ثبت نشده و مانده تسویه‌نشده‌ای وجود ندارد.`,
        'info'
      );
      return null;
    }

    const code =
      trackingCode?.trim() ||
      `PAYA-${Math.floor(100000 + Math.random() * 899999)}`;
    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز';
    const rawSheba = (targetBiz.bankShebaNumber || '').trim();
    const formattedSheba = rawSheba
      ? rawSheba.startsWith('IR')
        ? rawSheba
        : `IR${rawSheba}`
      : 'ثبت‌نشده (واریز به کارت/حساب سالن)';

    const settledRecord: SettlementRequestItem = {
      id: `STL-${Date.now().toString().slice(-5)}`,
      businessId: targetBiz.id,
      businessName: targetBiz.name,
      ownerName:
        targetBiz.bankAccountHolder || targetBiz.ownerName || 'مدیر سالن',
      ownerPhone: targetBiz.ownerPhone || targetBiz.phoneDisplay || '',
      shebaNumber: formattedSheba,
      cardNumber: targetBiz.bankCardNumber,
      amountToman: dossier.totalDepositToman || payoutAmount,
      commissionToman: dossier.totalCommissionToman,
      netPayoutToman: payoutAmount > 0 ? payoutAmount : dossier.totalSalonNetToman,
      bookingsCount: dossier.bookingsCount,
      totalServiceAmountToman: dossier.totalServicePriceToman,
      totalDepositCollectedToman: dossier.totalDepositToman,
      createdAtJalali: todayJalali,
      status: 'PAID',
      paidTrackingCode: code,
      paidAtJalali: todayJalali,
    };

    setSettlementRequests((prev) => {
      const updatedPrev = prev.map((s) =>
        s.businessId === targetBiz.id && s.status === 'PENDING'
          ? {
              ...s,
              status: 'PAID' as const,
              paidTrackingCode: code,
              paidAtJalali: todayJalali,
            }
          : s
      );
      const next = [settledRecord, ...updatedPrev];
      try {
        window.localStorage.setItem(
          'timeto_settlement_requests_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void realApiClient
          .savePlatformSharedState({ settlementRequests: next })
          .catch(() => {});
      }
      return next;
    });

    sendPlatformBusinessNotice({
      targetBusinessId: targetBiz.id,
      targetBusinessName: targetBiz.name,
      title: `📊 صورتحساب و تاییدیه واریز هفتگی شبا (کد پایا: ${code})`,
      message: `مدیریت محترم «${targetBiz.name}»؛ جزئیات کامل تسویه هفتگی شما به شرح زیر است: ۱) تعداد کل نوبت‌ها: ${toPersianDigits(
        dossier.bookingsCount
      )} رزرو با ارزش کل خدمات ارائه‌شده ${toPersianDigits(
        dossier.totalServicePriceToman.toLocaleString('fa-IR')
      )} تومان | ۲) مبلغ دریافتی حضوری توسط سالن از مشتریان: ${toPersianDigits(
        dossier.totalRemainingInSalonToman.toLocaleString('fa-IR')
      )} تومان | ۳) جمع کل بیعانه دریافتی آنلاین (${toPersianDigits(
        dossier.depositPercent
      )}٪): ${toPersianDigits(
        dossier.totalDepositToman.toLocaleString('fa-IR')
      )} تومان | ۴) کسر سهم کارمزد پلتفرم (${toPersianDigits(
        dossier.commissionPercent
      )}٪ از کل ارزش خدمات): ${toPersianDigits(
        dossier.totalCommissionToman.toLocaleString('fa-IR')
      )} تومان | ۵) خالص واریزشده به شبای شما (بیعانه منهای کارمزد کل خدمات): ${toPersianDigits(
        settledRecord.netPayoutToman.toLocaleString('fa-IR')
      )} تومان (کد رهگیری پایا: ${code}).`,
    });

    showToast(
      `واریز خالص ${toPersianDigits(settledRecord.netPayoutToman.toLocaleString('fa-IR'))} تومان برای «${targetBiz.name}» ثبت شد و صورتحساب ۵ بخشی کامل برای صاحب سالن ارسال گردید ✓`
    );
    return settledRecord;
  };

  const markSettlementPaid = (settlementId: string, trackingCode?: string) => {
    const code =
      trackingCode?.trim() || `PAYA-${Math.floor(100000 + Math.random() * 899999)}`;
    const matchedReq = settlementRequests.find((s) => s.id === settlementId);
    const targetBiz = matchedReq
      ? businesses.find((b) => b.id === matchedReq.businessId)
      : undefined;
    const dossier = targetBiz
      ? computeBusinessBookingDossierNumbers(targetBiz)
      : null;

    setSettlementRequests((prev) => {
      const next = prev.map((item) =>
        item.id === settlementId
          ? {
              ...item,
              status: 'PAID' as const,
              paidTrackingCode: code,
              paidAtJalali: 'امروز',
              bookingsCount: item.bookingsCount ?? dossier?.bookingsCount,
              totalServiceAmountToman:
                item.totalServiceAmountToman ?? dossier?.totalServicePriceToman,
              totalDepositCollectedToman:
                item.totalDepositCollectedToman ?? dossier?.totalDepositToman,
              commissionToman:
                item.commissionToman || dossier?.totalCommissionToman || 0,
            }
          : item
      );
      try {
        window.localStorage.setItem(
          'timeto_settlement_requests_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void realApiClient
          .savePlatformSharedState({ settlementRequests: next })
          .catch(() => {});
      }
      return next;
    });

    if (matchedReq) {
      const totalSrv = dossier?.totalServicePriceToman || matchedReq.amountToman;
      const totalDep = dossier?.totalDepositToman || matchedReq.amountToman;
      const totalInPerson = Math.max(0, totalSrv - totalDep);
      const totalComm =
        dossier?.totalCommissionToman || matchedReq.commissionToman || 0;
      sendPlatformBusinessNotice({
        targetBusinessId: matchedReq.businessId,
        targetBusinessName: matchedReq.businessName,
        title: `📊 صورتحساب واریز هفتگی شبا (کد رهگیری پایا: ${code})`,
        message: `مدیریت محترم «${matchedReq.businessName}»؛ بابت ${toPersianDigits(
          dossier?.bookingsCount || 1
        )} رزرو ثبت‌شده: ۱) ارزش کل خدمات ارائه‌شده: ${toPersianDigits(
          totalSrv.toLocaleString('fa-IR')
        )} تومان | ۲) دریافتی حضوری شما در سالن: ${toPersianDigits(
          totalInPerson.toLocaleString('fa-IR')
        )} تومان | ۳) بیعانه دریافتی آنلاین: ${toPersianDigits(
          totalDep.toLocaleString('fa-IR')
        )} تومان | ۴) کسر کارمزد پلتفرم (${toPersianDigits(
          dossier?.commissionPercent ?? 3
        )}٪ از کل خدمات): ${toPersianDigits(
          totalComm.toLocaleString('fa-IR')
        )} تومان | ۵) خالص واریزی به شبا (بیعانه منهای کارمزد): ${toPersianDigits(
          matchedReq.netPayoutToman.toLocaleString('fa-IR')
        )} تومان (کد پایا: ${code}).`,
      });
    }

    showToast(
      `واریز شبا با کد رهگیری پایا ${code} ثبت شد و صورتحساب کامل به پنل صاحب کسب‌وکار ارسال گردید.`
    );
  };

  const runNightlyBatchSettlement = (): number => {
    const eligibleBusinesses = businesses.filter((b) => {
      if (b.isSampleShowcase || /^biz-[1-8]$/.test(b.id)) return false;
      const dossier = computeBusinessBookingDossierNumbers(b);
      return dossier.pendingPayoutToman > 0;
    });
    const pendingItems = settlementRequests.filter(
      (s) => s.status === 'PENDING'
    );

    if (eligibleBusinesses.length === 0 && pendingItems.length === 0) {
      showToast(
        'در حال حاضر درخواست تسویه باز یا پرونده سالنی با مانده تسویه‌نشده وجود ندارد.',
        'info'
      );
      return 0;
    }

    const batchTimeCode = `PAYA-BATCH-${Math.floor(10000 + Math.random() * 89999)}`;
    const newlyCreated: SettlementRequestItem[] = eligibleBusinesses.map(
      (b, idx) => {
        const dossier = computeBusinessBookingDossierNumbers(b);
        const rawSheba = (b.bankShebaNumber || '').trim();
        const code = `${batchTimeCode}-${idx + 1}`;

        sendPlatformBusinessNotice({
          targetBusinessId: b.id,
          targetBusinessName: b.name,
          title: `📊 صورتحساب تسویه هفتگی شبا (کد پایا: ${code})`,
          message: `مدیریت محترم «${b.name}»؛ بابت ${toPersianDigits(
            dossier.bookingsCount
          )} رزرو ثبت‌شده: ۱) جمع کل خدمات ارائه‌شده: ${toPersianDigits(
            dossier.totalServicePriceToman.toLocaleString('fa-IR')
          )} تومان | ۲) دریافتی حضوری شما در سالن: ${toPersianDigits(
            dossier.totalRemainingInSalonToman.toLocaleString('fa-IR')
          )} تومان | ۳) بیعانه دریافتی آنلاین (${toPersianDigits(
            dossier.depositPercent
          )}٪): ${toPersianDigits(
            dossier.totalDepositToman.toLocaleString('fa-IR')
          )} تومان | ۴) کسر کارمزد پلتفرم (${toPersianDigits(
            dossier.commissionPercent
          )}٪ از کل خدمات): ${toPersianDigits(
            dossier.totalCommissionToman.toLocaleString('fa-IR')
          )} تومان | ۵) خالص واریزشده به شبای شما (بیعانه منهای کارمزد): ${toPersianDigits(
            dossier.pendingPayoutToman.toLocaleString('fa-IR')
          )} تومان.`,
        });

        return {
          id: `STL-${Date.now()}-${idx}`,
          businessId: b.id,
          businessName: b.name,
          ownerName: b.bankAccountHolder || b.ownerName || 'مدیر سالن',
          ownerPhone: b.ownerPhone || b.phoneDisplay || '',
          shebaNumber: rawSheba
            ? rawSheba.startsWith('IR')
              ? rawSheba
              : `IR${rawSheba}`
            : 'واریز به حساب ثبت‌شده سالن',
          cardNumber: b.bankCardNumber,
          amountToman: dossier.totalDepositToman,
          commissionToman: dossier.totalCommissionToman,
          netPayoutToman: dossier.pendingPayoutToman,
          bookingsCount: dossier.bookingsCount,
          totalServiceAmountToman: dossier.totalServicePriceToman,
          totalDepositCollectedToman: dossier.totalDepositToman,
          createdAtJalali: 'امروز (تسویه هفتگی پایا)',
          status: 'PAID',
          paidTrackingCode: code,
          paidAtJalali: 'امروز',
        };
      }
    );

    setSettlementRequests((prev) => {
      const updatedPrev = prev.map((s) =>
        s.status === 'PENDING'
          ? {
              ...s,
              status: 'PAID' as const,
              paidTrackingCode: s.paidTrackingCode || batchTimeCode,
              paidAtJalali: 'امروز',
            }
          : s
      );
      const next = [...newlyCreated, ...updatedPrev];
      try {
        window.localStorage.setItem(
          'timeto_settlement_requests_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void realApiClient
          .savePlatformSharedState({ settlementRequests: next })
          .catch(() => {});
      }
      return next;
    });

    const totalCount = eligibleBusinesses.length + pendingItems.length;
    showToast(
      `تسویه هفتگی پایا (شبا) برای ${toPersianDigits(totalCount)} سالن انجام شد و صورتحساب تفکیکی برای صاحبان کسب‌وکار ارسال گردید.`
    );
    return totalCount;
  };

  const persistCategories = (next: CategoryItem[]) => {
    try {
      window.localStorage.setItem(
        'timeto_custom_categories_v2',
        JSON.stringify(next)
      );
    } catch {
      // ignore
    }
  };

  const addCategory = (item: Omit<CategoryItem, 'id'>) => {
    const localNew: CategoryItem = { ...item, id: makeUniqueId('cat') };
    setCategories((prev) => {
      const next = [localNew, ...prev];
      persistCategories(next);
      return next;
    });

    if (dataMode === 'real') {
      void realApiClient
        .createCategory(item)
        .then((res) => {
          setCategories((prev) => {
            const next = prev.map((c) => (c.id === localNew.id ? res.item : c));
            persistCategories(next);
            return next;
          });
          showToast(`دسته‌بندی «${res.item.title}» ذخیره شد.`);
        })
        .catch(() => {
          showToast(`دسته‌بندی «${item.title}» به فهرست اضافه شد.`);
        });
      return;
    }

    showToast(`دسته‌بندی «${item.title}» به فهرست اضافه شد.`);
  };

  const updateCategory = (id: string, patch: Partial<CategoryItem>) => {
    setCategories((prev) => {
      const next = prev.map((c) => (c.id === id ? { ...c, ...patch } : c));
      persistCategories(next);
      return next;
    });

    if (dataMode === 'real') {
      void realApiClient
        .updateCategory(id, patch)
        .then((res) => {
          setCategories((prev) => {
            const next = prev.map((c) => (c.id === id ? res.item : c));
            persistCategories(next);
            return next;
          });
          showToast('دسته‌بندی با موفقیت ویرایش شد.');
        })
        .catch(() => {
          showToast('دسته‌بندی با موفقیت ویرایش شد.');
        });
      return;
    }

    showToast('دسته‌بندی ویرایش شد.');
  };

  const deleteCategory = (id: string) => {
    setCategories((prev) => {
      const next = prev.filter((c) => c.id !== id);
      persistCategories(next);
      return next;
    });
    showToast('دسته‌بندی انتخاب‌شده حذف شد.', 'warning');
  };

  const reorderCategory = (id: string, direction: 'UP' | 'DOWN') => {
    setCategories((prev) => {
      const idx = prev.findIndex((c) => c.id === id);
      if (idx < 0) return prev;
      const targetIdx = direction === 'UP' ? idx - 1 : idx + 1;
      if (targetIdx < 0 || targetIdx >= prev.length) return prev;
      const next = [...prev];
      const temp = next[idx];
      next[idx] = next[targetIdx];
      next[targetIdx] = temp;
      persistCategories(next);
      return next;
    });
    showToast('اولویت نمایش دسته‌بندی بروزرسانی شد.', 'info');
  };

  const addGalleryItem = (item: Omit<GalleryItem, 'id'>) => {
    const persistGalleryItemLocally = (newItem: GalleryItem) => {
      try {
        const savedRaw = window.localStorage.getItem('timeto_saved_gallery_v1');
        const savedList: GalleryItem[] = savedRaw ? JSON.parse(savedRaw) : [];
        const nextList = [
          newItem,
          ...(Array.isArray(savedList)
            ? savedList.filter((x) => x.id !== newItem.id)
            : []),
        ];
        window.localStorage.setItem(
          'timeto_saved_gallery_v1',
          JSON.stringify(nextList)
        );
      } catch {
        // ignore storage quota
      }
    };

    const localItem: GalleryItem = {
      ...item,
      id: makeUniqueId('gal'),
    };
    persistGalleryItemLocally(localItem);
    setGallery((prev) => [localItem, ...prev]);

    if (dataMode === 'real') {
      void realApiClient
        .createGalleryItem(item)
        .then((res) => {
          const mergedItem: GalleryItem = {
            ...res.item,
            imageUrl: item.imageUrl,
            compressedSizeKb: item.compressedSizeKb,
          };
          persistGalleryItemLocally(mergedItem);
          setGallery((prev) =>
            prev.map((g) => (g.id === localItem.id ? mergedItem : g))
          );
          showToast('تصویر نمونه‌کار با موفقیت در گالری سالن ذخیره شد ✓');
        })
        .catch(() => {
          showToast('تصویر نمونه‌کار با موفقیت در گالری سالن ثبت شد ✓');
        });
      return;
    }

    showToast('تصویر نمونه‌کار جدید به گالری سالن اضافه شد ✓');
  };

  const removeGalleryItem = (id: string) => {
    try {
      const savedRaw = window.localStorage.getItem('timeto_saved_gallery_v1');
      if (savedRaw) {
        const savedList: GalleryItem[] = JSON.parse(savedRaw);
        if (Array.isArray(savedList)) {
          window.localStorage.setItem(
            'timeto_saved_gallery_v1',
            JSON.stringify(savedList.filter((g) => g.id !== id))
          );
        }
      }
      const deletedRaw = window.localStorage.getItem(
        'timeto_deleted_gallery_ids_v1'
      );
      const deletedList: string[] = deletedRaw ? JSON.parse(deletedRaw) : [];
      if (!deletedList.includes(id)) {
        window.localStorage.setItem(
          'timeto_deleted_gallery_ids_v1',
          JSON.stringify([...deletedList, id])
        );
      }
    } catch {
      // ignore
    }

    setGallery((prev) => prev.filter((g) => g.id !== id));

    if (dataMode === 'real') {
      void realApiClient
        .deleteGalleryItem(id)
        .then(() => {
          showToast('تصویر نمونه‌کار از گالری حذف شد.', 'info');
        })
        .catch(() => {
          showToast('تصویر نمونه‌کار از گالری حذف شد.', 'info');
        });
      return;
    }

    showToast('تصویر نمونه‌کار از گالری حذف شد.', 'info');
  };

  const addCampaign = (item: Omit<MarketingCampaignItem, 'id'>) => {
    if (dataMode === 'real') {
      void realApiClient
        .createCampaign(item)
        .then((res) => {
          setCampaigns((prev) => [res.item, ...prev]);
          showToast('کمپین تبلیغاتی در پایگاه داده ثبت شد.');
        })
        .catch((err: unknown) => {
          showToast(
            err instanceof Error
              ? err.message
              : 'خطا در ثبت کمپین در دیتابیس',
            'danger'
          );
        });
      return;
    }

    setCampaigns((prev) => [{ ...item, id: makeUniqueId('cmp') }, ...prev]);
    showToast('کمپین تبلیغاتی ایجاد شد.');
  };

  const normalizeIranMobile = (raw: string): string => {
    const digits = (raw || '')
      .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
      .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
      .replace(/\D/g, '');
    if (digits.length === 10 && digits.startsWith('9')) {
      return `0${digits}`;
    }
    if (digits.length === 12 && digits.startsWith('989')) {
      return `0${digits.slice(2)}`;
    }
    return digits;
  };

  const formatMaskedPhoneDisplay = (cleanPhone: string): string => {
    if (!/^09\d{9}$/.test(cleanPhone)) return cleanPhone;
    const toFa = (s: string) =>
      s.replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)] || d);
    return `${toFa(cleanPhone.slice(0, 4))}***${toFa(cleanPhone.slice(7))}`;
  };

  const persistManualCustomerList = (list: CustomerRecord[]) => {
    try {
      window.localStorage.setItem(
        'timeto_manual_customers_v1',
        JSON.stringify(list)
      );
    } catch {
      // ignore
    }
  };

  const addCustomer = (input: {
    fullName: string;
    phone: string;
    city?: string;
    favoriteService?: string;
    totalVisits?: number;
    totalSpentToman?: number;
    lastVisitJalali?: string;
    notes?: string;
    businessId?: string;
  }): CustomerRecord | null => {
    const cleanName = input.fullName.trim();
    const cleanPhone = normalizeIranMobile(input.phone);

    if (!cleanName) {
      showToast('لطفاً نام و نام خانوادگی مشتری را وارد کنید.', 'warning');
      return null;
    }
    if (!/^09\d{9}$/.test(cleanPhone)) {
      showToast(
        'شماره موبایل مشتری باید ۱۱ رقم و با پیش‌شماره ۰۹ باشد (مثال: ۰۹۱۳۱۲۳۴۵۶۷).',
        'warning'
      );
      return null;
    }

    const targetBizId =
      input.businessId || currentBusiness?.id || ownedBusinessId || 'biz-1';
    const targetCity = input.city?.trim() || currentBusiness?.city || 'اصفهان';

    const existing = customers.find(
      (c) =>
        normalizeIranMobile(c.phone || c.phoneMasked) === cleanPhone &&
        (!c.businessId || c.businessId === targetBizId)
    );

    if (existing) {
      const updatedRecord: CustomerRecord = {
        ...existing,
        businessId: existing.businessId || targetBizId,
        fullName: cleanName,
        phone: cleanPhone,
        phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
        city: targetCity,
        favoriteService:
          input.favoriteService?.trim() || existing.favoriteService,
        totalVisits:
          typeof input.totalVisits === 'number'
            ? input.totalVisits
            : existing.totalVisits,
        totalSpentToman:
          typeof input.totalSpentToman === 'number'
            ? input.totalSpentToman
            : existing.totalSpentToman,
        lastVisitJalali: input.lastVisitJalali?.trim() || existing.lastVisitJalali,
        notes: input.notes?.trim() || existing.notes,
      };
      setCustomers((prev) => {
        const next = prev.map((c) =>
          c.id === existing.id ? updatedRecord : c
        );
        persistManualCustomerList(next);
        return next;
      });
      showToast(
        `پرونده «${cleanName}» با این شماره موبایل قبلاً ثبت شده بود و اطلاعاتش بروزرسانی شد.`,
        'info'
      );
      return updatedRecord;
    }

    const newCustomer: CustomerRecord = {
      id: `cus-man-${Date.now()}-${Math.floor(100 + Math.random() * 899)}`,
      businessId: targetBizId,
      fullName: cleanName,
      phone: cleanPhone,
      phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
      city: targetCity,
      totalVisits:
        typeof input.totalVisits === 'number' && input.totalVisits >= 0
          ? input.totalVisits
          : 1,
      lastVisitJalali: input.lastVisitJalali?.trim() || 'امروز',
      totalSpentToman:
        typeof input.totalSpentToman === 'number' && input.totalSpentToman >= 0
          ? input.totalSpentToman
          : 0,
      favoriteService: input.favoriteService?.trim() || 'خدمات عمومی سالن',
      notes:
        input.notes?.trim() ||
        'ثبت‌شده به صورت دستی توسط مدیریت سالن در لیست مشتریان',
      sourceLabel: 'MANUAL',
    };

    setCustomers((prev) => {
      const next = [newCustomer, ...prev];
      persistManualCustomerList(next);
      return next;
    });

    showToast(`مشتری «${cleanName}» با موفقیت به باشگاه مشتریان سالن اضافه شد.`);
    return newCustomer;
  };

  const addCustomersBulk = (
    items: Array<{
      fullName: string;
      phone: string;
      favoriteService?: string;
      notes?: string;
      totalVisits?: number;
      totalSpentToman?: number;
    }>,
    businessId?: string
  ): { addedCount: number; updatedCount: number } => {
    const targetBizId =
      businessId || currentBusiness?.id || ownedBusinessId || 'biz-1';
    const targetCity = currentBusiness?.city || 'اصفهان';

    let addedCount = 0;
    let updatedCount = 0;

    setCustomers((prev) => {
      const nextList = [...prev];
      for (const rawItem of items) {
        const cleanName = (rawItem.fullName || '').trim();
        const cleanPhone = normalizeIranMobile(rawItem.phone || '');
        if (!cleanName || !/^09\d{9}$/.test(cleanPhone)) {
          continue;
        }
        const existingIdx = nextList.findIndex(
          (c) =>
            normalizeIranMobile(c.phone || c.phoneMasked) === cleanPhone &&
            (!c.businessId || c.businessId === targetBizId)
        );
        if (existingIdx >= 0) {
          const ex = nextList[existingIdx];
          nextList[existingIdx] = {
            ...ex,
            businessId: ex.businessId || targetBizId,
            fullName: cleanName || ex.fullName,
            phone: cleanPhone,
            phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
            favoriteService:
              rawItem.favoriteService?.trim() || ex.favoriteService,
            notes: rawItem.notes?.trim() || ex.notes,
            totalVisits:
              typeof rawItem.totalVisits === 'number'
                ? rawItem.totalVisits
                : ex.totalVisits,
          };
          updatedCount += 1;
        } else {
          nextList.unshift({
            id: `cus-bulk-${Date.now()}-${Math.floor(1000 + Math.random() * 8999)}-${addedCount}`,
            businessId: targetBizId,
            fullName: cleanName,
            phone: cleanPhone,
            phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
            city: targetCity,
            totalVisits:
              typeof rawItem.totalVisits === 'number' && rawItem.totalVisits >= 0
                ? rawItem.totalVisits
                : 1,
            lastVisitJalali: 'ثبت گروهی',
            totalSpentToman:
              typeof rawItem.totalSpentToman === 'number' &&
              rawItem.totalSpentToman >= 0
                ? rawItem.totalSpentToman
                : 0,
            favoriteService:
              rawItem.favoriteService?.trim() || 'مشتری حضوری سالن',
            notes:
              rawItem.notes?.trim() ||
              'افزوده‌شده در ورود گروهی مشتریان قبلی سالن',
            sourceLabel: 'BULK_IMPORT',
          });
          addedCount += 1;
        }
      }
      persistManualCustomerList(nextList);
      return nextList;
    });

    if (addedCount > 0 || updatedCount > 0) {
      showToast(
        `${addedCount} مشتری جدید اضافه شد${updatedCount > 0 ? ` و ${updatedCount} پرونده قبلی بروزرسانی شد` : ''}.`
      );
    } else {
      showToast(
        'هیچ ردیف معتبری (شامل نام و شماره موبایل ۱۱ رقمی با شروع ۰۹) یافت نشد.',
        'warning'
      );
    }
    return { addedCount, updatedCount };
  };

  const updateCustomer = (id: string, patch: Partial<CustomerRecord>) => {
    setCustomers((prev) => {
      const next = prev.map((c) => {
        if (c.id !== id) return c;
        const nextPhone = patch.phone
          ? normalizeIranMobile(patch.phone)
          : c.phone;
        return {
          ...c,
          ...patch,
          phone: nextPhone,
          phoneMasked: nextPhone
            ? formatMaskedPhoneDisplay(nextPhone)
            : patch.phoneMasked || c.phoneMasked,
        };
      });
      persistManualCustomerList(next);
      return next;
    });
    showToast('اطلاعات پرونده مشتری بروزرسانی شد.');
  };

  const deleteCustomer = (id: string) => {
    try {
      const deletedRaw =
        window.localStorage.getItem('timeto_deleted_customer_ids_v1') || '[]';
      const deletedList: string[] = JSON.parse(deletedRaw);
      if (!deletedList.includes(id)) {
        deletedList.push(id);
        window.localStorage.setItem(
          'timeto_deleted_customer_ids_v1',
          JSON.stringify(deletedList)
        );
      }
    } catch {
      // ignore
    }
    setCustomers((prev) => {
      const next = prev.filter((c) => c.id !== id);
      persistManualCustomerList(next);
      return next;
    });
    showToast('پرونده مشتری از لیست حذف شد.', 'info');
  };

  const recalculateBusinessAndSpecialistRating = (
    targetBusinessId: string,
    nextReviews: ReviewItem[],
    targetSpecialistSlug?: string
  ) => {
    const bizReviews = nextReviews.filter((r) => r.businessId === targetBusinessId);
    const count = bizReviews.length;
    const avg =
      count > 0
        ? Math.round(
            (bizReviews.reduce((sum, r) => sum + Number(r.rating || 5), 0) /
              count) *
              10
          ) / 10
        : 5.0;

    setBusinesses((prev) =>
      prev.map((b) =>
        b.id === targetBusinessId
          ? { ...b, rating: avg, reviewCount: count }
          : b
      )
    );

    if (targetSpecialistSlug) {
      const spcReviews = nextReviews.filter(
        (r) => r.specialistSlug === targetSpecialistSlug
      );
      if (spcReviews.length > 0) {
        const spcAvg =
          Math.round(
            (spcReviews.reduce((sum, r) => sum + Number(r.rating || 5), 0) /
              spcReviews.length) *
              10
          ) / 10;
        setSpecialists((prev) =>
          prev.map((sp) =>
            sp.slug === targetSpecialistSlug ? { ...sp, rating: spcAvg } : sp
          )
        );
      }
    }
  };

  const addReview = async (input: {
    businessId: string;
    specialistSlug?: string;
    serviceTitle: string;
    rating: number;
    comment: string;
  }): Promise<boolean> => {
    const moderation = validateReviewContent(input.comment);
    if (!moderation.valid) {
      showToast(
        moderation.reason || 'متن دیدگاه نامعتبر است.',
        'warning'
      );
      return false;
    }

    const authorName = authUser?.fullName || 'کاربر تایم‌تو';
    const authorPhone = authUser?.phone || undefined;

    if (dataMode === 'real') {
      try {
        const res = await realApiClient.createReview({
          ...input,
          authorName,
          authorPhone,
        });
        setReviews((prev) => {
          const next = [res.item, ...prev.filter((r) => r.id !== res.item.id)];
          try {
            const savedRaw =
              window.localStorage.getItem('timeto_local_reviews_v1') || '[]';
            const savedList: ReviewItem[] = JSON.parse(savedRaw);
            window.localStorage.setItem(
              'timeto_local_reviews_v1',
              JSON.stringify([
                res.item,
                ...savedList.filter((r) => r.id !== res.item.id),
              ])
            );
          } catch {
            // ignore
          }
          recalculateBusinessAndSpecialistRating(
            input.businessId,
            next,
            input.specialistSlug
          );
          return next;
        });
        showToast('دیدگاه و امتیاز شما با موفقیت ثبت و منتشر شد.');
        return true;
      } catch (err) {
        if (
          err instanceof ApiClientError &&
          (err.errorCode === 'PROHIBITED_PROFANITY' ||
            err.errorCode === 'GIBBERISH' ||
            err.errorCode === 'TOO_SHORT')
        ) {
          showToast(err.message, 'warning');
          return false;
        }
        // اگر سالن محلی بود و هنوز در دیتابیس ثبت نشده بود، در وضعیت کلاینت ذخیره شود
      }
    }

    const todayJalali = getUpcomingJalaliDays(1)[0]?.dateJalali || '۱۴۰۳/۰۸/۲۱';
    const newReview: ReviewItem = {
      id: `rev-${Date.now()}`,
      businessId: input.businessId,
      specialistSlug: input.specialistSlug,
      authorName,
      authorPhone,
      serviceTitle: input.serviceTitle,
      rating: input.rating,
      dateJalali: todayJalali,
      comment: input.comment.trim(),
    };
    setReviews((prev) => {
      const next = [newReview, ...prev];
      try {
        const savedRaw =
          window.localStorage.getItem('timeto_local_reviews_v1') || '[]';
        const savedList: ReviewItem[] = JSON.parse(savedRaw);
        window.localStorage.setItem(
          'timeto_local_reviews_v1',
          JSON.stringify([newReview, ...savedList])
        );
      } catch {
        // ignore
      }
      recalculateBusinessAndSpecialistRating(
        input.businessId,
        next,
        input.specialistSlug
      );
      return next;
    });
    showToast('دیدگاه و امتیاز شما با موفقیت ثبت و منتشر شد.');
    return true;
  };

  const replyToReview = async (
    reviewId: string,
    replyText: string
  ): Promise<boolean> => {
    const cleanReply = replyText.trim();
    if (!cleanReply) {
      showToast('لطفاً متن پاسخ مدیریت سالن را وارد کنید.', 'warning');
      return false;
    }

    const moderation = validateReviewContent(cleanReply);
    if (!moderation.valid && moderation.code === 'PROHIBITED_PROFANITY') {
      showToast(
        'پاسخ مدیریت سالن نباید حاوی الفاظ توهین‌آمیز باشد.',
        'warning'
      );
      return false;
    }

    const replyDate = getUpcomingJalaliDays(1)[0]?.dateJalali || '۱۴۰۳/۰۸/۲۱';
    if (dataMode === 'real') {
      try {
        await realApiClient.replyReview(reviewId, cleanReply, replyDate);
      } catch {
        // ادامه با ذخیره در وضعیت محلی
      }
    }

    try {
      const metaRaw =
        window.localStorage.getItem('timeto_review_moderation_meta_v1') || '{}';
      const meta = JSON.parse(metaRaw);
      meta[reviewId] = {
        ...(meta[reviewId] || {}),
        salonReply: cleanReply,
        salonReplyDateJalali: replyDate,
      };
      window.localStorage.setItem(
        'timeto_review_moderation_meta_v1',
        JSON.stringify(meta)
      );
    } catch {
      // ignore
    }

    setReviews((prev) =>
      prev.map((r) =>
        r.id === reviewId
          ? {
              ...r,
              salonReply: cleanReply,
              salonReplyDateJalali: replyDate,
            }
          : r
      )
    );
    showToast('پاسخ مدیریت سالن زیر دیدگاه مشتری ثبت شد.');
    return true;
  };

  const reportReviewAbuse = async (
    reviewId: string,
    reason: string
  ): Promise<boolean> => {
    const cleanReason =
      reason.trim() || 'گزارش فحاشی، توهین یا متن جفنگ جهت بررسی مدیر کل';
    const targetRev = reviews.find((r) => r.id === reviewId);

    if (dataMode === 'real') {
      try {
        await realApiClient.reportReview(reviewId, cleanReason);
      } catch {
        // ادامه با ذخیره محلی
      }
    }

    try {
      const metaRaw =
        window.localStorage.getItem('timeto_review_moderation_meta_v1') || '{}';
      const meta = JSON.parse(metaRaw);
      meta[reviewId] = {
        ...(meta[reviewId] || {}),
        isReportedBySalon: true,
        reportReason: cleanReason,
      };
      window.localStorage.setItem(
        'timeto_review_moderation_meta_v1',
        JSON.stringify(meta)
      );
    } catch {
      // ignore
    }

    setReviews((prev) =>
      prev.map((r) =>
        r.id === reviewId
          ? {
              ...r,
              isReportedBySalon: true,
              reportReason: cleanReason,
            }
          : r
      )
    );

    if (targetRev) {
      const targetBiz = businesses.find((b) => b.id === targetRev.businessId);
      const reportNotif: AdminNotificationItem = {
        id: `notif-rev-${Date.now()}`,
        type: 'NEW_SUPPORT_TICKET',
        title: `گزارش دیدگاه نامناسب در «${targetBiz?.name || 'سالن'}»`,
        message: `صاحب سالن دیدگاه «${targetRev.authorName}» را به علت «${cleanReason}» برای بررسی فحاشی/جفنگ گزارش کرد.`,
        businessId: targetRev.businessId,
        businessName: targetBiz?.name,
        ownerName: targetRev.authorName,
        createdAtJalali: 'امروز',
        isRead: false,
      };
      setAdminNotifications((prev) => {
        const next = [reportNotif, ...prev];
        try {
          window.localStorage.setItem(
            'timeto_admin_notifications_v1',
            JSON.stringify(next)
          );
        } catch {
          // ignore
        }
        return next;
      });
    }

    showToast(
      'گزارش شما برای مدیر کل ارسال شد. توجه: دیدگاه‌های منفی محترمانه حذف نمی‌شوند و فقط فحاشی یا جفنگ توسط مدیر کل پاک می‌شود.',
      'info'
    );
    return true;
  };

  const deleteReviewByAdmin = async (reviewId: string): Promise<boolean> => {
    const targetRev = reviews.find((r) => r.id === reviewId);
    if (dataMode === 'real') {
      try {
        await realApiClient.deleteReviewAdmin(reviewId);
      } catch {
        // ادامه با حذف در کلاینت
      }
    }

    try {
      const delRaw =
        window.localStorage.getItem('timeto_deleted_review_ids_v1') || '[]';
      const delList: string[] = JSON.parse(delRaw);
      if (!delList.includes(reviewId)) {
        delList.push(reviewId);
        window.localStorage.setItem(
          'timeto_deleted_review_ids_v1',
          JSON.stringify(delList)
        );
      }
      const savedRaw =
        window.localStorage.getItem('timeto_local_reviews_v1') || '[]';
      const savedList: ReviewItem[] = JSON.parse(savedRaw);
      window.localStorage.setItem(
        'timeto_local_reviews_v1',
        JSON.stringify(savedList.filter((r) => r.id !== reviewId))
      );
    } catch {
      // ignore
    }

    setReviews((prev) => {
      const next = prev.filter((r) => r.id !== reviewId);
      if (targetRev) {
        recalculateBusinessAndSpecialistRating(
          targetRev.businessId,
          next,
          targetRev.specialistSlug
        );
      }
      return next;
    });
    showToast('دیدگاه حاوی توهین/جفنگ توسط مدیر کل حذف شد و امتیاز سالن بروزرسانی گردید.', 'info');
    return true;
  };

  const updateOnboardingDraft = (patch: Partial<OnboardingDraft>) => {
    setOnboardingDraft((prev) => ({ ...prev, ...patch }));
  };

  const markAdminNotificationRead = (id: string) => {
    setAdminNotifications((prev) => {
      const next = prev.map((n) => (n.id === id ? { ...n, isRead: true } : n));
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void fetch('/api/v1/admin/notifications/read', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ id }),
        }).catch(() => {});
      }
      return next;
    });
  };

  const clearAllAdminNotifications = () => {
    setAdminNotifications((prev) => {
      const next = prev.map((n) => ({ ...n, isRead: true }));
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      if (dataMode === 'real') {
        void fetch('/api/v1/admin/notifications/read', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ clearAll: true }),
        }).catch(() => {});
      }
      return next;
    });
    showToast('تمامی اعلان‌های مدیریت خوانده شد.', 'info');
  };

  const updateAdminNotificationSettings = (
    patch: Partial<AdminNotificationSettings>
  ) => {
    setAdminNotificationSettings((prev) => {
      const next = { ...prev, ...patch };
      try {
        window.localStorage.setItem(
          'timeto_admin_notify_settings_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });
    showToast('تنظیمات مدیر کل و اطلاع‌رسانی ذخیره شد.');
  };

  const submitSupportTicket = (input: {
    senderName?: string;
    senderPhone?: string;
    categoryLabel: string;
    subject: string;
    message: string;
    senderRole?: 'CUSTOMER' | 'BUSINESS_OWNER';
    businessId?: string;
    businessName?: string;
  }): SupportTicketItem => {
    const isBizRole =
      input.senderRole === 'BUSINESS_OWNER' ||
      Boolean(input.businessId) ||
      Boolean(ownedBusinessId) ||
      Boolean(authUser?.roles?.includes('BUSINESS_OWNER'));

    const matchedBiz =
      businesses.find((b) => b.id === (input.businessId || ownedBusinessId)) ||
      (isBizRole ? currentBusiness : null);

    const newTicket: SupportTicketItem = {
      id: `TCK-${Math.floor(1000 + Math.random() * 9000)}`,
      senderRole: isBizRole ? 'BUSINESS_OWNER' : 'CUSTOMER',
      senderName:
        input.senderName?.trim() ||
        matchedBiz?.ownerName ||
        authUser?.fullName ||
        'کاربر تایم تو',
      senderPhone:
        input.senderPhone?.trim() ||
        matchedBiz?.ownerPhone ||
        authUser?.phone ||
        'ثبت‌نشده',
      businessId: matchedBiz?.id || input.businessId,
      businessName: input.businessName || matchedBiz?.name,
      categoryLabel: input.categoryLabel,
      subject: input.subject.trim(),
      message: input.message.trim(),
      createdAtJalali: 'امروز',
      status: 'OPEN',
    };

    setSupportTickets((prev) => {
      const next = [newTicket, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_support_tickets_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    const ticketNotif: AdminNotificationItem = {
      id: `notif-tck-${Date.now()}`,
      type: 'NEW_SUPPORT_TICKET',
      title: `تیکت پشتیبانی جدید: ${newTicket.subject}`,
      message: `${
        newTicket.senderRole === 'BUSINESS_OWNER'
          ? `صاحب کسب‌وکار «${newTicket.businessName || newTicket.senderName}»`
          : `مشتری (${newTicket.senderName})`
      } — تماس: ${newTicket.senderPhone}`,
      businessId: newTicket.businessId,
      businessName: newTicket.businessName,
      ownerName: newTicket.senderName,
      ownerPhone: newTicket.senderPhone,
      city: matchedBiz?.city || 'اصفهان',
      ticketId: newTicket.id,
      createdAtJalali: 'امروز',
      isRead: false,
    };

    setAdminNotifications((prev) => {
      const next = [ticketNotif, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    showToast(
      `تیکت شما با کد ${newTicket.id} برای مدیریت کلان ارسال شد و پاسخ آن در همین بخش درج خواهد شد.`
    );
    return newTicket;
  };

  const replySupportTicket = (
    ticketId: string,
    replyText: string,
    status: 'ANSWERED' | 'CLOSED' = 'ANSWERED'
  ) => {
    setSupportTickets((prev) => {
      const next = prev.map((t) =>
        t.id === ticketId
          ? {
              ...t,
              adminReply: replyText.trim(),
              repliedAtJalali: 'امروز',
              status,
            }
          : t
      );
      try {
        window.localStorage.setItem(
          'timeto_support_tickets_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    setAdminNotifications((prev) => {
      const next = prev.map((n) =>
        n.ticketId === ticketId ? { ...n, isRead: true } : n
      );
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    showToast('پاسخ شما برای تیکت پشتیبانی ثبت شد.');
  };

  const sendBusinessCustomerSms = async (input: {
    businessId?: string;
    recipientPhones: string[];
    messageText: string;
    templateTitle?: string;
  }): Promise<boolean> => {
    const targetBiz =
      businesses.find((b) => b.id === input.businessId) ??
      currentBusiness ??
      businesses[0];
    if (!targetBiz) {
      showToast('کسب‌وکار فعالی یافت نشد.', 'danger');
      return false;
    }

    const cleanPhones = Array.from(
      new Set(
        input.recipientPhones
          .map((p) =>
            p
              .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
              .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
              .replace(/\D/g, '')
          )
          .filter((p) => /^09\d{9}$/.test(p))
      )
    );

    if (cleanPhones.length === 0) {
      showToast(
        'لطفاً حداقل یک شماره موبایل معتبر ۱۱ رقمی (با شروع ۰۹) انتخاب یا وارد کنید.',
        'warning'
      );
      return false;
    }

    if (!input.messageText.trim()) {
      showToast('لطفاً متن پیامک را وارد کنید.', 'warning');
      return false;
    }

    // قفل ضدتقلب پیامک تبلیغاتی: ارسال پیامک انبوه باشگاه مشتریان صرفاً از شارژ بسته پیامکی خریداری‌شده کسر می‌شود
    const purchasedSmsQuota = targetBiz.extraSmsBalance ?? 0;
    const usedSoFar = targetBiz.smsSentCount ?? 0;
    const remainingQuota = Math.max(0, purchasedSmsQuota - usedSoFar);

    if (cleanPhones.length > remainingQuota) {
      showToast(
        `ظرفیت بسته پیامکی تبلیغاتی شما (${remainingQuota} پیامک باقی‌مانده) کمتر از تعداد گیرندگان انتخابی (${cleanPhones.length} نفر) است. لطفاً ابتدا از همین صفحه بسته پیامک تهیه کنید.`,
        'warning'
      );
      return false;
    }

    const nextSentCount = usedSoFar + cleanPhones.length;

    if (dataMode === 'real') {
      try {
        await realApiClient.sendBusinessSms({
          businessId: targetBiz.id,
          recipientPhones: cleanPhones,
          messageText: input.messageText.trim(),
          templateTitle: input.templateTitle,
        });
      } catch {
        // در صورت عدم اتصال خط خدماتی انبوه، لاگ مصرف ثبت می‌شود
      }
    }

    updateBusinessProfile(targetBiz.id, {
      smsSentCount: nextSentCount,
    });

    const newLog: SmsMessageLogItem = {
      id: `sms-${Date.now()}`,
      businessId: targetBiz.id,
      businessName: targetBiz.name,
      recipientsCount: cleanPhones.length,
      recipientPhones: cleanPhones,
      messageText: input.messageText.trim(),
      templateTitle: input.templateTitle || 'پیامک مستقیم به مشتریان',
      createdAtJalali: 'امروز',
      status: 'SENT',
    };

    setSmsLogs((prev) => {
      const next = [newLog, ...prev];
      try {
        window.localStorage.setItem('timeto_sms_logs_v1', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });

    showToast(
      `پیامک شما با موفقیت برای ${cleanPhones.length} مشتری ارسال و در گزارش مصرف ثبت شد.`
    );
    return true;
  };

  const submitBusinessOnboarding = async (): Promise<boolean> => {
    if (onboardingDraft.selectedPlanId) {
      setActivePlanId(onboardingDraft.selectedPlanId);
    }

    const chosenPlan =
      plans.find((p) => p.id === onboardingDraft.selectedPlanId) ?? plans[0];
    const isFreePlan =
      !onboardingDraft.selectedPlanId ||
      onboardingDraft.selectedPlanId === 'plan-free' ||
      onboardingDraft.selectedPlanId === 'plan-free-start';

    if (dataMode === 'real') {
      try {
        const res = await realApiClient.onboardBusiness(onboardingDraft);
        setOwnedBusinessId(res.businessId);
        try {
          window.localStorage.setItem(
            'timeto_owned_business_id_v1',
            res.businessId
          );
        } catch {
          // ignore
        }
        setCategories(res.data.categories);
        setBusinesses(mergeBusinessOverrides(res.data.businesses));
        if (res.user) {
          setAuthUser(res.user);
          await loadAuthenticatedRoleData(res.user);
        } else {
          try {
            const sessionRes = await realApiClient.getCurrentUser();
            setAuthUser(sessionRes.user);
            await loadAuthenticatedRoleData(sessionRes.user);
          } catch {
            // ادامه
          }
        }
        showToast(
          `کسب‌وکار «${onboardingDraft.businessName}» با موفقیت در دیتابیس ثبت شد و برای تایید مدیر کل ارسال گردید.`
        );
        return true;
      } catch {
        // اگر به هر دلیل ارتباط با سرور برقرار نشد، در حافظه محلی هم ذخیره شود تا کاربر متوقف نشود
      }
    }

    const newBizId = `biz-onb-${Date.now()}`;
    const minServicePrice =
      onboardingDraft.services.length > 0
        ? Math.min(...onboardingDraft.services.map((s) => s.priceToman))
        : 450000;

    const newBiz: BusinessItem = {
      id: newBizId,
      slug: `${onboardingDraft.slug || 'salon'}-${Math.floor(100 + Math.random() * 899)}`,
      name: onboardingDraft.businessName || 'سالن زیبایی جدید',
      type: onboardingDraft.businessType,
      typeLabel:
        onboardingDraft.businessType === BusinessType.MenBarbershop
          ? 'آرایشگاه مردانه'
          : onboardingDraft.businessType === BusinessType.IndependentSpecialist
            ? 'متخصص مستقل زیبایی'
            : 'سالن زیبایی زنانه',
      categorySlug: onboardingDraft.categorySlug || 'hair-color',
      city: onboardingDraft.city || 'اصفهان',
      neighborhood: onboardingDraft.neighborhood || 'چهارباغ بالا',
      address: onboardingDraft.address || 'اصفهان',
      phoneDisplay: onboardingDraft.phone || '09131234567',
      ownerName: onboardingDraft.ownerName || 'مدیر سالن',
      ownerPhone: onboardingDraft.phone || '09131234567',
      createdAtJalali: getUpcomingJalaliDays(1)[0]?.dateJalali || 'امروز',
      rating: 5.0,
      reviewCount: 0,
      startingPriceToman: minServicePrice,
      shortDescription:
        onboardingDraft.shortDescription ||
        'مرکز تخصصی زیبایی و مراقبت با نوبت‌دهی آنلاین در تایم تو.',
      aboutText:
        onboardingDraft.shortDescription ||
        'پذیرش منظم آنلاین با کادر مجرب و رعایت کامل استانداردهای بهداشتی.',
      verifiedBadge: false,
      approvalStatus: 'PENDING_REVIEW',
      subscriptionPlan: chosenPlan?.name ?? 'شروع رایگان (پایه)',
      subscriptionStatus: isFreePlan
        ? SubscriptionStatus.Trial
        : SubscriptionStatus.Active,
      trialDaysRemaining: isFreePlan ? 30 : undefined,
      extraSmsBalance: 0,
      smsSentCount: 0,
      workingHours: onboardingDraft.workingHours,
      visualTheme: 'violet',
      featured: false,
      isSampleShowcase: false,
      instagramHandle: onboardingDraft.instagramHandle,
      mapLat: onboardingDraft.mapLat,
      mapLng: onboardingDraft.mapLng,
      avatarUrl: onboardingDraft.avatarUrl,
    };

    try {
      const localOnbRaw =
        window.localStorage.getItem('timeto_local_onboarded_businesses_v1') ||
        '[]';
      const localOnbList: BusinessItem[] = JSON.parse(localOnbRaw);
      const nextLocalList = [newBiz, ...localOnbList];
      window.localStorage.setItem(
        'timeto_local_onboarded_businesses_v1',
        JSON.stringify(nextLocalList)
      );
      window.localStorage.setItem('timeto_owned_business_id_v1', newBizId);
    } catch {
      // ignore
    }

    const newNotif: AdminNotificationItem = {
      id: `notif-${Date.now()}`,
      type: 'NEW_BUSINESS',
      title: `ثبت‌نام کسب‌وکار جدید: ${newBiz.name}`,
      message: `${newBiz.ownerName} (${newBiz.ownerPhone}) سالن «${newBiz.name}» را در ${newBiz.city} ثبت کرد و منتظر تایید شماست.`,
      businessId: newBiz.id,
      businessName: newBiz.name,
      ownerName: newBiz.ownerName,
      ownerPhone: newBiz.ownerPhone,
      city: newBiz.city,
      createdAtJalali: 'امروز',
      isRead: false,
    };
    setAdminNotifications((prev) => {
      const next = [newNotif, ...prev];
      try {
        window.localStorage.setItem(
          'timeto_admin_notifications_v1',
          JSON.stringify(next)
        );
      } catch {
        // ignore
      }
      return next;
    });

    setBusinesses((prev) => [newBiz, ...prev]);
    setOwnedBusinessId(newBizId);

    showToast(
      `راه‌اندازی «${onboardingDraft.businessName}» با موفقیت ثبت شد و در صف تایید قرار گرفت.`
    );
    return true;
  };

  const updateBookingDraft = (patch: Partial<BookingDraft>) => {
    setBookingDraft((prev) => ({ ...prev, ...patch }));
  };

  const mergedSpecialists: SpecialistItem[] = React.useMemo(() => {
    const map = new Map<string, SpecialistItem>();
    for (const sp of specialists) {
      if (
        sp &&
        sp.id &&
        !/^spc-[1-8]$/.test(sp.id) &&
        sp.fullName?.trim() !== 'مریم فرهادی'
      ) {
        map.set(sp.id, sp);
      }
    }
    for (const biz of businesses) {
      if (biz.approvalStatus === 'REJECTED' || biz.isSampleShowcase) {
        continue;
      }
      const alreadyHasSpecialist = Array.from(map.values()).some(
        (sp) => sp.businessId === biz.id || sp.slug === biz.slug
      );
      if (!alreadyHasSpecialist) {
        const synthSpecId = `spec-ind-${biz.id}`;
        const roleLbl =
          biz.type === BusinessType.IndependentSpecialist
            ? biz.typeLabel || 'متخصص مستقل زیبایی'
            : biz.typeLabel || 'متخصص و مدیر مرکز';
        const cleanOwner =
          biz.ownerName &&
          biz.ownerName.trim() &&
          biz.ownerName.trim() !== 'مریم فرهادی'
            ? biz.ownerName.trim()
            : biz.name || 'متخصص زیبایی';
        map.set(synthSpecId, {
          id: synthSpecId,
          businessId: biz.id,
          slug: biz.slug,
          fullName:
            biz.type === BusinessType.IndependentSpecialist
              ? biz.name || cleanOwner
              : cleanOwner,
          roleTitle: roleLbl,
          experienceYears: 5,
          rating: biz.rating || 5.0,
          reviewCount: biz.reviewCount || 0,
          city: biz.city || 'اصفهان',
          specialties: [
            roleLbl,
            biz.neighborhood ? `محدوده ${biz.neighborhood}` : 'اصفهان',
          ],
          bio:
            biz.shortDescription ||
            biz.aboutText ||
            `ارائه خدمات تخصصی ${roleLbl} با تعیین وقت آنلاین در ${biz.city || 'اصفهان'}`,
          isActive: true,
          isIndependent: biz.type === BusinessType.IndependentSpecialist,
          avatarUrl: biz.avatarUrl,
        });
      }
    }
    return Array.from(map.values());
  }, [specialists, businesses]);

  const completeSimulatedBooking = (
    paymentMeta?: {
      depositPaidToman: number;
      paymentMethod: 'GATEWAY' | 'WALLET';
      paymentTrackingCode: string;
    },
    overrideDraft?: Partial<BookingDraft> & {
      businessId?: string;
      businessName?: string;
    }
  ): AppointmentItem => {
    const effectiveDraft: BookingDraft = {
      ...bookingDraft,
      ...(overrideDraft || {}),
    };
    const targetSlug = String(effectiveDraft.businessSlug || '').trim();
    const targetBizId = String(overrideDraft?.businessId || '').trim();

    // هرگز روی businesses[0] (مثل سالن آنجل) fallback نشود! فقط کسب‌وکار دقیقِ انتخاب‌شده توسط کاربر ملاک است
    const biz = businesses.find(
      (b) =>
        (targetSlug && (b.slug === targetSlug || b.id === targetSlug)) ||
        (targetBizId && b.id === targetBizId)
    );

    if (!biz && !targetSlug && !targetBizId) {
      const msg =
        'اطلاعات سالن یا متخصص انتخاب‌شده یافت نشد. لطفاً مجدداً از صفحه پروفایل سالن اقدام به رزرو نمایید.';
      showToast(msg, 'danger');
      throw new Error(msg);
    }

    if (biz?.isSampleShowcase || /^biz-[1-8]$/.test(biz?.id || '')) {
      const msg =
        'این سالن یک نمونه نمایشی جهت مشاهده امکانات پلتفرم تایم تو است و امکان ثبت رزرو واقعی روی آن وجود ندارد.';
      showToast(msg, 'warning');
      throw new Error(msg);
    }

    const resolvedBizId = biz?.id || targetBizId || targetSlug;
    const resolvedBizSlug = biz?.slug || targetSlug || targetBizId;
    const resolvedBizName =
      biz?.name || overrideDraft?.businessName || 'سالن زیبایی';

    const bizServices = services.filter(
      (s) =>
        s.businessId === resolvedBizId ||
        s.businessId === resolvedBizSlug ||
        (biz?.id && s.businessId === biz.id)
    );
    const summary = computeSelectedServicesSummary(
      bizServices.length > 0 ? bizServices : services,
      effectiveDraft.serviceIds ?? [],
      effectiveDraft.serviceId
    );
    const primarySrv = summary.selectedServices[0];
    const resolvedTotalServicePrice =
      summary.totalPriceToman ||
      bizServices[0]?.priceToman ||
      biz?.startingPriceToman ||
      400000;
    const bizSpecs = mergedSpecialists.filter(
      (sp) =>
        sp.businessId === resolvedBizId ||
        sp.businessId === resolvedBizSlug ||
        (biz?.id && sp.businessId === biz.id)
    );
    const spc =
      bizSpecs.find((sp) => sp.id === effectiveDraft.specialistId) ??
      mergedSpecialists.find((sp) => sp.id === effectiveDraft.specialistId) ??
      bizSpecs[0];
    const resolvedSpecialistName =
      spc?.fullName && spc.fullName.trim() !== 'مریم فرهادی'
        ? spc.fullName.trim()
        : biz?.ownerName && biz.ownerName.trim() !== 'مریم فرهادی'
          ? biz.ownerName.trim()
          : resolvedBizName;
    const refCode = `TM-${Math.floor(404000 + Math.random() * 9000)}`;

    const financialBreakdown = calculateBookingFinancialBreakdown({
      totalServicePriceToman: resolvedTotalServicePrice,
      depositPercent: biz?.depositPercent,
      business: biz,
      commissionConfig: {
        maleCommissionPercent: paymentConfig.maleCommissionPercent,
        laserCommissionPercent: paymentConfig.laserCommissionPercent,
        femaleCommissionPercent:
          paymentConfig.femaleCommissionPercent ||
          paymentConfig.platformCommissionPercent,
      },
    });

    const resolvedBaseDepositToman =
      paymentMeta?.depositPaidToman && paymentMeta.depositPaidToman > 0
        ? paymentMeta.depositPaidToman
        : financialBreakdown.baseDepositToman;

    const optimisticApt: AppointmentItem = {
      id: `apt-${Date.now()}`,
      referenceCode: refCode,
      businessId: resolvedBizId,
      businessSlug: resolvedBizSlug,
      businessName: resolvedBizName,
      customerName:
        effectiveDraft.customerName || authUser?.fullName || 'مراجع تایم‌تو',
      customerPhoneMasked:
        effectiveDraft.customerPhone || authUser?.phone || '۰۹۱۳***۰۰۰۰',
      serviceId: primarySrv?.id || effectiveDraft.serviceId,
      serviceTitle: summary.combinedTitle || 'خدمات زیبایی',
      specialistId:
        spc?.id || effectiveDraft.specialistId || `spec-ind-${resolvedBizId}`,
      specialistName: resolvedSpecialistName,
      dateJalali: effectiveDraft.dateJalali,
      timeSlot: effectiveDraft.timeSlot,
      durationMinutes: summary.totalDurationMinutes || 60,
      priceToman: resolvedTotalServicePrice,
      depositPaidToman: resolvedBaseDepositToman,
      platformCommissionToman: financialBreakdown.platformCommissionToman,
      customerGatewayAndTaxFeeToman:
        financialBreakdown.customerGatewayAndTaxFeeToman,
      salonNetDepositCreditedToman:
        financialBreakdown.salonNetDepositCreditedToman,
      paymentMethod: paymentMeta?.paymentMethod,
      paymentTrackingCode: paymentMeta?.paymentTrackingCode,
      createdAtMs: Date.now(),
      status: AppointmentStatus.Pending,
      notes: effectiveDraft.customerNotes || undefined,
    };

    const resolvedOwnerPhone =
      biz?.ownerPhone || biz?.phoneDisplay || undefined;

    const triggerBookingNotification = (resolvedRefCode?: string) => {
      void fetch('/api/v1/appointments/notify-booking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessSlug: resolvedBizSlug,
          businessId: resolvedBizId,
          businessName: resolvedBizName,
          ownerPhone: resolvedOwnerPhone,
          customerName:
            effectiveDraft.customerName || authUser?.fullName || 'مراجع تایم‌تو',
          customerPhone: effectiveDraft.customerPhone || authUser?.phone || '',
          serviceTitle: summary.combinedTitle || 'خدمات زیبایی',
          priceToman: resolvedTotalServicePrice,
          durationMinutes: summary.totalDurationMinutes || 60,
          dateJalali: effectiveDraft.dateJalali,
          timeSlot: effectiveDraft.timeSlot,
          depositPaidToman: resolvedBaseDepositToman,
          referenceCode: resolvedRefCode || refCode,
        }),
      }).catch(() => {});
    };

    if (dataMode === 'real') {
      void realApiClient
        .createAppointment({
          businessSlug: resolvedBizSlug,
          businessId: resolvedBizId,
          businessName: resolvedBizName,
          ownerPhone: resolvedOwnerPhone,
          serviceId: effectiveDraft.serviceId,
          serviceTitle: summary.combinedTitle || 'خدمات زیبایی',
          priceToman: resolvedTotalServicePrice,
          durationMinutes: summary.totalDurationMinutes || 60,
          allowAutoCreateService: true,
          specialistId:
            spc?.id ||
            effectiveDraft.specialistId ||
            `spec-ind-${resolvedBizId}`,
          dateJalali: effectiveDraft.dateJalali,
          timeSlot: effectiveDraft.timeSlot,
          customerName: effectiveDraft.customerName,
          customerPhone: effectiveDraft.customerPhone,
          customerNotes: effectiveDraft.customerNotes,
          depositPaidToman: resolvedBaseDepositToman,
          paymentMethod: paymentMeta?.paymentMethod,
          paymentTrackingCode: paymentMeta?.paymentTrackingCode,
        })
        .then((res) => {
          const pendingItem: AppointmentItem = {
            ...res.item,
            specialistName:
              res.item.specialistName &&
              res.item.specialistName.trim() !== 'مریم فرهادی'
                ? res.item.specialistName
                : resolvedSpecialistName,
            depositPaidToman: resolvedBaseDepositToman,
            platformCommissionToman: financialBreakdown.platformCommissionToman,
            customerGatewayAndTaxFeeToman:
              financialBreakdown.customerGatewayAndTaxFeeToman,
            salonNetDepositCreditedToman:
              financialBreakdown.salonNetDepositCreditedToman,
            paymentMethod: paymentMeta?.paymentMethod,
            paymentTrackingCode: paymentMeta?.paymentTrackingCode,
            createdAtMs: Date.now(),
            status: AppointmentStatus.Pending,
          };
          setAppointments((prev) => {
            const next = [
              pendingItem,
              ...prev.filter((a) => a.id !== pendingItem.id),
            ];
            persistSavedAppointments(next);
            return next;
          });
          setBookingDraft((prev) => ({
            ...prev,
            lastReferenceCode: res.item.referenceCode,
          }));
          triggerBookingNotification(res.item.referenceCode);
          showToast(
            'پرداخت بیعانه تایید شد، نوبت شما ثبت گردید و پیامک اطلاع‌رسانی برای مدیر سالن ارسال شد ✓'
          );
        })
        .catch(() => {
          setAppointments((prev) => {
            const next = [optimisticApt, ...prev];
            persistSavedAppointments(next);
            return next;
          });
          triggerBookingNotification();
          showToast(
            'پرداخت بیعانه تایید شد و نوبت شما در پنل سالن ثبت گردید ✓'
          );
        });
      return optimisticApt;
    }

    setAppointments((prev) => {
      const next = [optimisticApt, ...prev];
      persistSavedAppointments(next);
      return next;
    });
    setBookingDraft((prev) => ({ ...prev, lastReferenceCode: refCode }));
    triggerBookingNotification();
    showToast(
      'پرداخت بیعانه تایید شد و نوبت شما برای تایید به پنل صاحب سالن ارسال گردید ✓'
    );
    return optimisticApt;
  };

  const submitBooking = async (
    paymentMeta?: {
      depositPaidToman: number;
      paymentMethod: 'GATEWAY' | 'WALLET';
      paymentTrackingCode: string;
    },
    overrideDraft?: Partial<BookingDraft> & {
      businessId?: string;
      businessName?: string;
    }
  ): Promise<AppointmentItem> => {
    const effectiveDraft: BookingDraft = {
      ...bookingDraft,
      ...(overrideDraft || {}),
    };
    const targetSlug = String(effectiveDraft.businessSlug || '').trim();
    const targetBizId = String(overrideDraft?.businessId || '').trim();

    const biz = businesses.find(
      (b) =>
        (targetSlug && (b.slug === targetSlug || b.id === targetSlug)) ||
        (targetBizId && b.id === targetBizId)
    );
    if (!biz && !targetSlug && !targetBizId) {
      const msg =
        'اطلاعات سالن یا متخصص انتخاب‌شده یافت نشد. لطفاً مجدداً از صفحه پروفایل سالن اقدام به رزرو نمایید.';
      showToast(msg, 'danger');
      throw new Error(msg);
    }
    if (biz?.isSampleShowcase || /^biz-[1-8]$/.test(biz?.id || '')) {
      const msg =
        'این سالن یک نمونه نمایشی جهت آشنایی با پلتفرم تایم تو است و امکان ثبت رزرو واقعی روی آن وجود ندارد.';
      showToast(msg, 'warning');
      throw new Error(msg);
    }

    const resolvedBizId = biz?.id || targetBizId || targetSlug;
    const resolvedBizSlug = biz?.slug || targetSlug || targetBizId;
    const resolvedBizName =
      biz?.name || overrideDraft?.businessName || 'سالن زیبایی';
    const resolvedOwnerPhone =
      biz?.ownerPhone || biz?.phoneDisplay || undefined;

    const bizServices = services.filter(
      (s) =>
        s.businessId === resolvedBizId ||
        s.businessId === resolvedBizSlug ||
        (biz?.id && s.businessId === biz.id)
    );
    const summary = computeSelectedServicesSummary(
      bizServices.length > 0 ? bizServices : services,
      effectiveDraft.serviceIds ?? [],
      effectiveDraft.serviceId
    );
    const resolvedSubmitServicePrice =
      summary.totalPriceToman ||
      bizServices[0]?.priceToman ||
      biz?.startingPriceToman ||
      400000;

    const bizSpecs = mergedSpecialists.filter(
      (sp) =>
        sp.businessId === resolvedBizId ||
        sp.businessId === resolvedBizSlug ||
        (biz?.id && sp.businessId === biz.id)
    );
    const spc =
      bizSpecs.find((sp) => sp.id === effectiveDraft.specialistId) ??
      mergedSpecialists.find((sp) => sp.id === effectiveDraft.specialistId) ??
      bizSpecs[0];
    const resolvedSpecialistName =
      spc?.fullName && spc.fullName.trim() !== 'مریم فرهادی'
        ? spc.fullName.trim()
        : biz?.ownerName && biz.ownerName.trim() !== 'مریم فرهادی'
          ? biz.ownerName.trim()
          : resolvedBizName;

    const submitBreakdown = calculateBookingFinancialBreakdown({
      totalServicePriceToman: resolvedSubmitServicePrice,
      depositPercent: biz?.depositPercent,
      business: biz,
      commissionConfig: {
        maleCommissionPercent: paymentConfig.maleCommissionPercent,
        laserCommissionPercent: paymentConfig.laserCommissionPercent,
        femaleCommissionPercent:
          paymentConfig.femaleCommissionPercent ||
          paymentConfig.platformCommissionPercent,
      },
    });
    const resolvedSubmitDeposit =
      paymentMeta?.depositPaidToman && paymentMeta.depositPaidToman > 0
        ? paymentMeta.depositPaidToman
        : submitBreakdown.baseDepositToman;

    if (dataMode === 'real') {
      try {
        const res = await realApiClient.createAppointment({
          businessSlug: resolvedBizSlug,
          businessId: resolvedBizId,
          businessName: resolvedBizName,
          ownerPhone: resolvedOwnerPhone,
          serviceId: effectiveDraft.serviceId,
          serviceTitle: summary.combinedTitle || 'خدمات زیبایی',
          priceToman: resolvedSubmitServicePrice,
          durationMinutes: summary.totalDurationMinutes || 60,
          allowAutoCreateService: true,
          specialistId:
            spc?.id ||
            effectiveDraft.specialistId ||
            `spec-ind-${resolvedBizId}`,
          dateJalali: effectiveDraft.dateJalali,
          timeSlot: effectiveDraft.timeSlot,
          customerName: effectiveDraft.customerName,
          customerPhone: effectiveDraft.customerPhone,
          customerNotes: effectiveDraft.customerNotes,
          depositPaidToman: resolvedSubmitDeposit,
          paymentMethod: paymentMeta?.paymentMethod,
          paymentTrackingCode: paymentMeta?.paymentTrackingCode,
        });
        const pendingItem: AppointmentItem = {
          ...res.item,
          specialistName:
            res.item.specialistName &&
            res.item.specialistName.trim() !== 'مریم فرهادی'
              ? res.item.specialistName
              : resolvedSpecialistName,
          depositPaidToman: resolvedSubmitDeposit,
          platformCommissionToman: submitBreakdown.platformCommissionToman,
          customerGatewayAndTaxFeeToman:
            submitBreakdown.customerGatewayAndTaxFeeToman,
          salonNetDepositCreditedToman:
            submitBreakdown.salonNetDepositCreditedToman,
          paymentMethod: paymentMeta?.paymentMethod,
          paymentTrackingCode: paymentMeta?.paymentTrackingCode,
          createdAtMs: Date.now(),
          status: AppointmentStatus.Pending,
        };
        setAppointments((prev) => {
          const next = [
            pendingItem,
            ...prev.filter((a) => a.id !== pendingItem.id),
          ];
          persistSavedAppointments(next);
          return next;
        });
        setBookingDraft((prev) => ({
          ...prev,
          lastReferenceCode: res.item.referenceCode,
        }));
        void fetch('/api/v1/appointments/notify-booking', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            businessSlug: resolvedBizSlug,
            businessId: resolvedBizId,
            businessName: resolvedBizName,
            ownerPhone: resolvedOwnerPhone,
            customerName:
              effectiveDraft.customerName ||
              authUser?.fullName ||
              'مراجع تایم‌تو',
            customerPhone:
              effectiveDraft.customerPhone || authUser?.phone || '',
            serviceTitle: summary.combinedTitle || 'خدمات زیبایی',
            priceToman: summary.totalPriceToman || 450000,
            durationMinutes: summary.totalDurationMinutes || 60,
            dateJalali: effectiveDraft.dateJalali,
            timeSlot: effectiveDraft.timeSlot,
            depositPaidToman: resolvedSubmitDeposit,
            referenceCode: res.item.referenceCode,
          }),
        }).catch(() => {});
        showToast(
          'پرداخت بیعانه تایید شد، نوبت شما ثبت گردید و پیامک اطلاع‌رسانی برای تایید به مدیر سالن ارسال شد ✓'
        );
        return pendingItem;
      } catch {
        // اگر سالن تازه ثبت شده و در حافظه محلی است، نوبت به صورت محلی روی همان سالن ثبت و برای سالن‌دار ارسال شود
        return completeSimulatedBooking(paymentMeta, overrideDraft);
      }
    }

    return completeSimulatedBooking(paymentMeta, overrideDraft);
  };

  const adminUsers: AdminUserRecord[] = React.useMemo(() => {
    void accountsRevision;
    const byPhone = new Map<string, AdminUserRecord>();
    let deletedPhones = new Set<string>();
    let overrides: Record<
      string,
      {
        fullName?: string;
        city?: string;
        roleLabel?: string;
        phone?: string;
      }
    > = {};
    let savedJoinDates: Record<string, string> = {};

    try {
      const delRaw =
        window.localStorage.getItem('timeto_deleted_admin_phones_v1') || '[]';
      deletedPhones = new Set<string>(JSON.parse(delRaw));
      const ovRaw =
        window.localStorage.getItem('timeto_admin_user_overrides_v1') || '{}';
      overrides = JSON.parse(ovRaw);
      const jdRaw =
        window.localStorage.getItem('timeto_user_joined_dates_v1') || '{}';
      savedJoinDates = JSON.parse(jdRaw);
    } catch {
      // ignore
    }

    const formatTimestampToJalali = (ms: number): string => {
      try {
        const fmt = new Intl.DateTimeFormat('en-US-u-ca-persian', {
          timeZone: 'Asia/Tehran',
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
        });
        const parts = Object.fromEntries(
          fmt.formatToParts(new Date(ms)).map((p) => [p.type, p.value])
        );
        return toPersianDigits(`${parts.year}/${parts.month}/${parts.day}`);
      } catch {
        return getUpcomingJalaliDays(1)[0]?.dateJalali || '۱۴۰۵/۰۸/۲۰';
      }
    };

    let joinDatesChanged = false;
    const isFakeOrInvalidJalali = (val?: string): boolean => {
      if (!val) return true;
      const eng = toEnglishDigitsClient(String(val)).trim();
      if (
        !eng.includes('/') ||
        eng === 'امروز' ||
        eng === 'ثبت‌شده' ||
        eng === 'فعال' ||
        eng.startsWith('1405/08/05') ||
        eng.startsWith('1405/08/01') ||
        eng.startsWith('1405/07/') ||
        eng.startsWith('1405/') ||
        eng.startsWith('202')
      ) {
        return true;
      }
      return false;
    };

    const resolveUserJoinedJalali = (
      cleanPhone: string,
      rawCandidate?: string,
      timestampMs?: number,
      indexSeed = 0
    ): string => {
      void indexSeed;
      if (rawCandidate && !isFakeOrInvalidJalali(rawCandidate)) {
        const normalized = toPersianDigits(rawCandidate.trim());
        if (savedJoinDates[cleanPhone] !== normalized) {
          savedJoinDates[cleanPhone] = normalized;
          joinDatesChanged = true;
        }
        return normalized;
      }
      if (
        savedJoinDates[cleanPhone] &&
        !isFakeOrInvalidJalali(savedJoinDates[cleanPhone])
      ) {
        return savedJoinDates[cleanPhone];
      }
      if (timestampMs && timestampMs > 1700000000000) {
        const formatted = formatTimestampToJalali(timestampMs);
        savedJoinDates[cleanPhone] = formatted;
        joinDatesChanged = true;
        return formatted;
      }
      const todayFormatted = formatTimestampToJalali(Date.now());
      savedJoinDates[cleanPhone] = todayFormatted;
      joinDatesChanged = true;
      return todayFormatted;
    };

    // ۰. نقشه نام‌های واقعی مشتریان از نوبت‌ها و باشگاه مشتریان برای جلوگیری از نمایش «کاربر BeautyHub / beutyhub» یا «کاربر تایم تو»
    const isLegacyOrGenericName = (raw?: unknown): boolean => {
      const s = String(raw || '').trim();
      if (!s) return true;
      const lower = s.toLowerCase().replace(/\s+/g, '');
      return (
        lower.includes('beautyhub') ||
        lower.includes('beutyhub') ||
        lower.includes('beuty') ||
        s.includes('بیوتی') ||
        s.includes('کاربر تایم') ||
        s === 'کاربر Timeto' ||
        s.toLowerCase() === 'کاربر timeto'
      );
    };

    const knownCustomerNameByPhone = new Map<string, string>();
    for (const apt of appointments) {
      const p = normalizeIranMobile(apt.customerPhoneMasked || '');
      const n = (apt.customerName || '').trim();
      if (/^09\d{9}$/.test(p) && n.length >= 2 && !isLegacyOrGenericName(n)) {
        knownCustomerNameByPhone.set(p, n);
      }
    }
    for (const cus of customers) {
      const p = normalizeIranMobile(cus.phone || cus.phoneMasked || '');
      const n = (cus.fullName || '').trim();
      if (/^09\d{9}$/.test(p) && n.length >= 2 && !isLegacyOrGenericName(n)) {
        knownCustomerNameByPhone.set(p, n);
      }
    }

    const sanitizeUserName = (
      rawName: string | undefined,
      cleanPhone: string
    ): string => {
      const trimmed = (rawName || '').trim();
      if (trimmed && !isLegacyOrGenericName(trimmed)) {
        return trimmed;
      }
      return knownCustomerNameByPhone.get(cleanPhone) || 'کاربر تایم تو';
    };

    const sanitizeUserCity = (
      rawCity: string | undefined,
      explicitOverrideCity?: string
    ): string => {
      if (explicitOverrideCity && explicitOverrideCity.trim()) {
        return explicitOverrideCity.trim();
      }
      const c = (rawCity || '').trim();
      if (!c || c === 'تهران') return 'اصفهان';
      return c;
    };

    // ۱. کاربران دریافت‌شده از سرور
    let userIdx = 0;
    for (const u of rawAdminUsers) {
      userIdx += 1;
      const cleanPhone = normalizeIranMobile(u.phone || u.phoneMasked);
      if (!/^09\d{9}$/.test(cleanPhone) || deletedPhones.has(cleanPhone)) {
        continue;
      }
      const ov = overrides[cleanPhone];
      byPhone.set(cleanPhone, {
        ...u,
        id: u.id || `usr-${cleanPhone}`,
        fullName: sanitizeUserName(ov?.fullName || u.fullName, cleanPhone),
        phone: cleanPhone,
        phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
        city: sanitizeUserCity(u.city, ov?.city),
        roleLabel: ov?.roleLabel || u.roleLabel || 'مشتری عادی',
        joinedJalali: resolveUserJoinedJalali(
          cleanPhone,
          u.joinedJalali,
          undefined,
          userIdx
        ),
        isActive: u.isActive !== false,
      });
    }

    // ۲. کسب‌وکارهای واقعی ثبت‌شده (صاحبان سالن‌ها)
    for (const b of businesses) {
      if (b.isSampleShowcase || /^biz-[1-8]$/.test(b.id)) continue;
      userIdx += 1;
      const cleanPhone = normalizeIranMobile(b.ownerPhone || b.phoneDisplay);
      if (!/^09\d{9}$/.test(cleanPhone) || deletedPhones.has(cleanPhone)) {
        continue;
      }
      const existing = byPhone.get(cleanPhone);
      const ov = overrides[cleanPhone];
      byPhone.set(cleanPhone, {
        id: existing?.id || `usr-biz-${b.id}`,
        fullName:
          ov?.fullName || b.ownerName || existing?.fullName || `مدیریت ${b.name}`,
        roleLabel:
          ov?.roleLabel || `صاحب سالن (${b.name})`,
        phone: cleanPhone,
        phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
        city: ov?.city || b.city || existing?.city || 'اصفهان',
        joinedJalali: resolveUserJoinedJalali(
          cleanPhone,
          b.createdAtJalali || existing?.joinedJalali,
          undefined,
          userIdx
        ),
        isActive: true,
      });
    }

    // ۳. تمام حساب‌های ثبت‌نام‌شده در حافظه مرورگر (مشتریان عادی و صاحبان سالن)
    const memoryAccounts = getSavedMemoryAccounts();
    for (const acc of Object.values(memoryAccounts)) {
      userIdx += 1;
      const cleanPhone = normalizeIranMobile(acc.phone);
      if (!/^09\d{9}$/.test(cleanPhone) || deletedPhones.has(cleanPhone)) {
        continue;
      }
      const existing = byPhone.get(cleanPhone);
      const ov = overrides[cleanPhone];
      const matchedBiz = businesses.find(
        (b) =>
          !b.isSampleShowcase &&
          (b.id === acc.businessId ||
            normalizeIranMobile(b.ownerPhone || b.phoneDisplay) === cleanPhone)
      );
      const isBizOwner = acc.role === 'BUSINESS_OWNER' || Boolean(matchedBiz);
      const salonTitle = matchedBiz?.name || acc.businessName;

      byPhone.set(cleanPhone, {
        id: existing?.id || `usr-mem-${cleanPhone}`,
        fullName: sanitizeUserName(
          ov?.fullName || acc.fullName || existing?.fullName,
          cleanPhone
        ),
        roleLabel:
          ov?.roleLabel ||
          (isBizOwner
            ? salonTitle
              ? `صاحب سالن (${salonTitle})`
              : 'صاحب کسب‌وکار (سالن‌دار)'
            : existing?.roleLabel?.includes('سالن')
              ? existing.roleLabel
              : 'مشتری عادی'),
        phone: cleanPhone,
        phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
        city: sanitizeUserCity(
          acc.city || matchedBiz?.city || existing?.city,
          ov?.city
        ),
        joinedJalali: resolveUserJoinedJalali(
          cleanPhone,
          existing?.joinedJalali,
          acc.updatedAt,
          userIdx
        ),
        isActive: true,
      });
    }

    // ۴. کاربر لاگین‌شده فعلی (در صورتی که هنوز در لیست نباشد)
    if (authUser?.phone) {
      const cleanPhone = normalizeIranMobile(authUser.phone);
      if (/^09\d{9}$/.test(cleanPhone) && !deletedPhones.has(cleanPhone)) {
        const existing = byPhone.get(cleanPhone);
        const ov = overrides[cleanPhone];
        const isSuper =
          authUser.isPlatformAdmin ||
          authUser.roles.includes('PLATFORM_ADMIN');
        const isBiz = authUser.roles.includes('BUSINESS_OWNER');
        byPhone.set(cleanPhone, {
          id: existing?.id || authUser.userId || `usr-${cleanPhone}`,
          fullName: sanitizeUserName(
            ov?.fullName || authUser.fullName || existing?.fullName,
            cleanPhone
          ),
          roleLabel:
            ov?.roleLabel ||
            existing?.roleLabel ||
            (isSuper
              ? 'مدیر کل پلتفرم'
              : isBiz
                ? 'صاحب کسب‌وکار (سالن‌دار)'
                : 'مشتری عادی'),
          phone: cleanPhone,
          phoneMasked: formatMaskedPhoneDisplay(cleanPhone),
          city: sanitizeUserCity(
            authUser.defaultCity || existing?.city,
            ov?.city
          ),
          joinedJalali: resolveUserJoinedJalali(
            cleanPhone,
            existing?.joinedJalali,
            Date.now(),
            0
          ),
          isActive: true,
        });
      }
    }

    if (joinDatesChanged) {
      try {
        window.localStorage.setItem(
          'timeto_user_joined_dates_v1',
          JSON.stringify(savedJoinDates)
        );
      } catch {
        // ignore
      }
    }

    return Array.from(byPhone.values());
  }, [rawAdminUsers, businesses, authUser, accountsRevision, appointments, customers]);

  const updateAdminUserRecord = (
    phone: string,
    patch: {
      fullName?: string;
      newPhone?: string;
      city?: string;
      role?: 'CUSTOMER' | 'BUSINESS_OWNER';
    }
  ): boolean => {
    const cleanOldPhone = normalizeIranMobile(phone);
    const cleanNewPhone = patch.newPhone
      ? normalizeIranMobile(patch.newPhone)
      : cleanOldPhone;

    if (!/^09\d{9}$/.test(cleanNewPhone)) {
      showToast(
        'شماره موبایل باید ۱۱ رقم و با پیش‌شماره ۰۹ باشد.',
        'warning'
      );
      return false;
    }

    if (
      cleanNewPhone !== cleanOldPhone &&
      adminUsers.some((u) => normalizeIranMobile(u.phone || '') === cleanNewPhone)
    ) {
      showToast(
        'این شماره موبایل قبلاً برای کاربر دیگری در سامانه ثبت شده است.',
        'warning'
      );
      return false;
    }

    const memRes = updateMemoryAccountPhoneOrProfile(cleanOldPhone, {
      newPhone: cleanNewPhone,
      fullName: patch.fullName,
      city: patch.city,
      role: patch.role,
    });
    if (!memRes.ok) {
      showToast(memRes.error || 'خطا در ویرایش مشخصات کاربر.', 'warning');
      return false;
    }

    try {
      const ovRaw =
        window.localStorage.getItem('timeto_admin_user_overrides_v1') || '{}';
      const ov = JSON.parse(ovRaw);
      const prevOv = ov[cleanOldPhone] || {};
      if (cleanNewPhone !== cleanOldPhone) {
        delete ov[cleanOldPhone];
      }
      ov[cleanNewPhone] = {
        ...prevOv,
        ...(patch.fullName ? { fullName: patch.fullName.trim() } : {}),
        ...(patch.city ? { city: patch.city.trim() } : {}),
        ...(patch.role
          ? {
              roleLabel:
                patch.role === 'BUSINESS_OWNER'
                  ? 'صاحب کسب‌وکار (سالن‌دار)'
                  : 'مشتری عادی',
            }
          : {}),
        phone: cleanNewPhone,
      };
      window.localStorage.setItem(
        'timeto_admin_user_overrides_v1',
        JSON.stringify(ov)
      );
    } catch {
      // ignore
    }

    setAdminUsers((prev) =>
      prev.map((u) => {
        if (normalizeIranMobile(u.phone || u.phoneMasked) !== cleanOldPhone) {
          return u;
        }
        return {
          ...u,
          fullName: patch.fullName?.trim() || u.fullName,
          phone: cleanNewPhone,
          phoneMasked: formatMaskedPhoneDisplay(cleanNewPhone),
          city: patch.city?.trim() || u.city,
          roleLabel: patch.role
            ? patch.role === 'BUSINESS_OWNER'
              ? 'صاحب کسب‌وکار (سالن‌دار)'
              : 'مشتری عادی'
            : u.roleLabel,
        };
      })
    );

    if (authUser && normalizeIranMobile(authUser.phone) === cleanOldPhone) {
      setAuthUser({
        ...authUser,
        fullName: patch.fullName?.trim() || authUser.fullName,
        phone: cleanNewPhone,
        defaultCity: patch.city?.trim() || authUser.defaultCity,
      });
    }

      if (dataMode === 'real') {
        void realApiClient
          .updateAdminUser(cleanOldPhone, {
            fullName: patch.fullName?.trim(),
            city: patch.city?.trim(),
            roleLabel: patch.role
              ? patch.role === 'BUSINESS_OWNER'
                ? 'صاحب کسب‌وکار (سالن‌دار)'
                : 'مشتری عادی'
              : undefined,
          })
          .then((res) => {
            if (Array.isArray(res.users)) setAdminUsers(res.users);
          })
          .catch(() => {});
      }

      setAccountsRevision((r) => r + 1);
      showToast('اطلاعات کاربر با موفقیت ویرایش و ذخیره شد.');
      return true;
    };

    const deleteAdminUserRecord = (phone: string) => {
      const cleanPhone = normalizeIranMobile(phone);
      if (!cleanPhone) return;

      removeMemoryAccount(cleanPhone);

      try {
        const delRaw =
          window.localStorage.getItem('timeto_deleted_admin_phones_v1') || '[]';
        const delList: string[] = JSON.parse(delRaw);
        if (!delList.includes(cleanPhone)) {
          delList.push(cleanPhone);
          window.localStorage.setItem(
            'timeto_deleted_admin_phones_v1',
            JSON.stringify(delList)
          );
        }
        const ovRaw =
          window.localStorage.getItem('timeto_admin_user_overrides_v1') || '{}';
        const ov = JSON.parse(ovRaw);
        if (ov[cleanPhone]) {
          delete ov[cleanPhone];
          window.localStorage.setItem(
            'timeto_admin_user_overrides_v1',
            JSON.stringify(ov)
          );
        }
      } catch {
        // ignore
      }

      if (dataMode === 'real') {
        void realApiClient
          .deleteAdminUser(cleanPhone)
          .then((res) => {
            if (Array.isArray(res.users)) setAdminUsers(res.users);
          })
          .catch(() => {});
      }

      setAdminUsers((prev) =>
        prev.filter(
          (u) => normalizeIranMobile(u.phone || u.phoneMasked) !== cleanPhone
        )
      );
      setAccountsRevision((r) => r + 1);
      showToast('حساب کاربری انتخاب‌شده از فهرست کاربران حذف شد.', 'info');
    };

    const computedCategories: CategoryItem[] = React.useMemo(() => {
      return categories.map((cat) => {
        const matchingServicesCount = services.filter(
          (s) =>
            s.isActive !== false &&
            (s.categorySlug === cat.slug || s.category === cat.title)
        ).length;
        const matchingBizCount = businesses.filter(
          (b) =>
            !b.isSampleShowcase &&
            b.approvalStatus !== 'REJECTED' &&
            b.categorySlug === cat.slug
        ).length;
        return {
          ...cat,
          serviceCount: matchingServicesCount + matchingBizCount,
        };
      });
    }, [categories, services, businesses]);

    return (
      <PrototypeDataContext.Provider
        value={{
          dataMode,
          databaseError,
          isLoadingInitialData,
          authUser,
          ownedBusinessId,
          isAuthModalOpen,
          authModalOptions,
          openAuthModal,
          closeAuthModal,
          completeUnifiedAuthSession,
          requestOtpLogin,
          verifyOtpLogin,
          loginWithPassword,
          setAccountPassword,
          resetPasswordWithOtp,
          logoutUser,
          updateCustomerProfile,
          updateAdminUserRecord,
          deleteAdminUserRecord,
          refreshRealData,
          selectedCity,
          setSelectedCity,
          favoriteBusinessIds,
          toggleFavoriteBusiness,
          favoriteSpecialistIds,
          toggleFavoriteSpecialist,
          businesses,
          currentBusiness,
          updateBusinessProfile,
          updateBusinessWorkingHours,
          updateBusinessApproval,
          adminReviewedBizIds,
          grantBusinessPlanOrAdByAdmin,
          permanentlyDeleteBusiness,
          platformBusinessNotices,
          sendPlatformBusinessNotice,
          markPlatformBusinessNoticeRead,
          services,
          addService,
          updateService,
          deleteService,
          reorderBusinessServices,
          specialists: mergedSpecialists,
          addSpecialist,
          updateSpecialist,
          appointments,
          updateAppointmentStatus,
          customerWalletBalanceToman,
          customerWalletTransactions,
          topUpCustomerWallet,
          payFromCustomerWallet,
          requestCustomerWalletWithdrawal,
          settleAppointmentInPerson,
          dailyIncomeLogs,
          addDailyIncomeLog,
          deleteDailyIncomeLog,
          categories: computedCategories,
          addCategory,
          updateCategory,
          deleteCategory,
          reorderCategory,
          gallery,
          addGalleryItem,
          removeGalleryItem,
          businessStories,
          addBusinessStory,
          deleteBusinessStory,
          campaigns,
          addCampaign,
          customers,
          addCustomer,
          addCustomersBulk,
          updateCustomer,
          deleteCustomer,
          adminUsers,
          reviews,
          addReview,
          replyToReview,
          reportReviewAbuse,
          deleteReviewByAdmin,
          plans,
          updatePlan,
          adPackages,
          updateAdPackage,
          paymentConfig,
          updatePaymentConfig,
          paymentOrders,
          submitPaymentOrder,
          reviewPaymentOrder,
          settlementRequests,
          requestWalletSettlement,
          markSettlementPaid,
          settleBusinessDossierByAdmin,
          runNightlyBatchSettlement,
          recordSponsoredClick,
          sendAppointmentReminders,
          smsLogs,
          sendBusinessCustomerSms,
          adminNotifications,
          markAdminNotificationRead,
          clearAllAdminNotifications,
          adminNotificationSettings,
          updateAdminNotificationSettings,
          supportTickets,
          submitSupportTicket,
          replySupportTicket,
          activePlanId,
          setActivePlanId,
          onboardingDraft,
          updateOnboardingDraft,
          submitBusinessOnboarding,
          bookingDraft,
          updateBookingDraft,
          completeSimulatedBooking,
          submitBooking,
          toast,
          showToast,
          dismissToast,
        }}
      >
        {children}
      </PrototypeDataContext.Provider>
    );
  };

export function usePrototypeData(): PrototypeDataContextValue {
  const ctx = useContext(PrototypeDataContext);
  if (!ctx) {
    throw new Error(
      'usePrototypeData must be used inside a PrototypeDataProvider'
    );
  }
  return ctx;
}
