import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  MapPin,
  Star,
  Calendar,
  Heart,
  ShieldCheck,
  Phone,
  Clock,
  CheckCircle2,
  ArrowLeft,
  ArrowRight,
  Instagram,
  Info,
  Share2,
  MessageCircle,
  Scissors,
  Image as ImageIcon,
  Users,
  Sparkles,
  Trash2,
  Flag,
  MessageSquareReply,
  AlertTriangle,
} from 'lucide-react';
import { usePrototypeData } from '../../context/PrototypeDataContext';
import {
  formatCompactPriceToman,
  formatCustomerWorkingHourMinimal,
  formatPriceToman,
  formatStartingTariff,
  getUpcomingJalaliDays,
  normalizeIranMobileInput,
  toPersianDigits,
} from '../../utils/formatters';
import { validateReviewContent } from '../../utils/reviewModeration';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { FormField } from '../../components/ui/FormField';
import { Input, Textarea } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { Modal } from '../../components/ui/Modal';
import {
  getBeautyPhotoUrl,
  getSpecialistAvatarUrl,
} from '../../components/ui/VisualMediaIllustration';
import { EmptyState } from '../../components/ui/StateViews';
import {
  Avatar,
  ProfessionalCard,
  ServiceCard,
  Tabs,
} from '../../components/ui/MarketplaceComponents';
import { LocationMapPicker } from '../../components/ui/LocationMapPicker';
import { BusinessQrCodeCard } from '../../components/business/BusinessQrCodeCard';

export const BusinessPublicProfileView: React.FC<{
  mode: 'salon' | 'pro';
}> = ({ mode }) => {
  const { slug } = useParams<{ slug: string }>();
  const {
    dataMode,
    authUser,
    ownedBusinessId,
    openAuthModal,
    businesses,
    services,
    specialists,
    appointments,
    customers,
    reviews,
    addReview,
    replyToReview,
    reportReviewAbuse,
    deleteReviewByAdmin,
    gallery,
    businessStories,
    favoriteBusinessIds,
    toggleFavoriteBusiness,
    favoriteSpecialistIds,
    toggleFavoriteSpecialist,
    showToast,
  } = usePrototypeData();

  const [activeTab, setActiveTab] = useState<string>('services');
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);
  const [selectedServiceCategory, setSelectedServiceCategory] =
    useState<string>('ALL');
  const [publicServiceQuery, setPublicServiceQuery] = useState<string>('');
  const [showAllPublicServices, setShowAllPublicServices] =
    useState<boolean>(false);
  const [selectedProfileServiceIds, setSelectedProfileServiceIds] = useState<
    string[]
  >([]);
  const [showFullWeeklyHours, setShowFullWeeklyHours] =
    useState<boolean>(false);
  const [reviewRating, setReviewRating] = useState<number>(0);
  const [reviewHoverRating, setReviewHoverRating] = useState<number>(0);
  const [visibleReviewsCount, setVisibleReviewsCount] = useState<number>(5);
  const [reviewServiceTitle, setReviewServiceTitle] = useState<string>('');
  const [reviewComment, setReviewComment] = useState<string>('');
  const [isSubmittingReview, setIsSubmittingReview] = useState<boolean>(false);
  const [replyingReviewId, setReplyingReviewId] = useState<string | null>(null);
  const [replyDraftText, setReplyDraftText] = useState<string>('');

  const decodedSlug = decodeURIComponent(slug || '').trim();
  const matchedSpecialist = specialists.find(
    (sp) => sp.slug === decodedSlug || sp.id === decodedSlug
  );
  const fallbackSlug = mode === 'pro' ? 'mahsa-kiani' : 'royal-golzar';
  const business =
    businesses.find(
      (b) =>
        b.slug === decodedSlug ||
        b.id === decodedSlug ||
        b.slug.toLowerCase() === decodedSlug.toLowerCase() ||
        b.id.toLowerCase() === decodedSlug.toLowerCase()
    ) ??
    (matchedSpecialist
      ? businesses.find((b) => b.id === matchedSpecialist.businessId)
      : undefined) ??
    (dataMode === 'mock'
      ? (businesses.find((b) => b.slug === fallbackSlug) ?? businesses[0])
      : undefined);

  if (!business) {
    return (
      <div className="my-8">
        <EmptyState
          title="پروفایل مرکز زیبایی یا متخصص یافت نشد"
          description="ممکن است این مرکز در سامانه وجود نداشته باشد یا هنوز در صف بررسی و تایید قرار داشته باشد."
        />
      </div>
    );
  }

  const bizServices = services.filter(
    (s) => s.businessId === business.id && s.isActive !== false
  );
  const pricedServiceValues = bizServices
    .map((s) => Number(s.priceToman) || 0)
    .filter((p) => p > 0);
  const effectiveStartingPriceToman =
    pricedServiceValues.length > 0
      ? Math.min(...pricedServiceValues)
      : Number(business.startingPriceToman) || 0;
  const popularServices = bizServices.filter((s) => s.isPopular).length > 0
    ? bizServices.filter((s) => s.isPopular)
    : bizServices.slice(0, Math.min(3, bizServices.length));
  const popularServiceIdSet = new Set(popularServices.map((s) => s.id));
  const serviceCategories = Array.from(
    new Set(bizServices.map((s) => s.category))
  );
  const normalizedPubSrvQ = publicServiceQuery.trim().toLowerCase();
  const filteredServices = bizServices.filter((s) => {
    const matchCat =
      selectedServiceCategory === 'ALL'
        ? true
        : selectedServiceCategory === 'POPULAR'
          ? popularServiceIdSet.has(s.id)
          : s.category === selectedServiceCategory;
    const matchQ =
      !normalizedPubSrvQ ||
      s.title.toLowerCase().includes(normalizedPubSrvQ) ||
      s.category.toLowerCase().includes(normalizedPubSrvQ) ||
      s.description.toLowerCase().includes(normalizedPubSrvQ);
    return matchCat && matchQ;
  });

  const handleToggleProfileService = (srvId: string) => {
    setSelectedProfileServiceIds((prev) =>
      prev.includes(srvId) ? prev.filter((id) => id !== srvId) : [...prev, srvId]
    );
  };
  const selectedProfileServicesTotal = bizServices
    .filter((s) => selectedProfileServiceIds.includes(s.id))
    .reduce((acc, s) => acc + (Number(s.priceToman) || 0), 0);

  const todayJalaliDayName = getUpcomingJalaliDays(1)[0]?.dayName || 'شنبه';
  const todayWorkingHour =
    business.workingHours.find((w) => w.dayName === todayJalaliDayName) ??
    business.workingHours[0];

  const bizSpecialists = specialists.filter(
    (sp) => sp.businessId === business.id && sp.isActive !== false
  );
  const bizReviews = reviews.filter((r) => r.businessId === business.id);
  const visibleBizReviews = bizReviews.slice(0, visibleReviewsCount);
  const remainingReviewsCount = Math.max(
    0,
    bizReviews.length - visibleReviewsCount
  );

  // بررسی اینکه آیا کاربر لاگین‌شده واقعاً مشتری همین کسب‌وکار است (دارای نوبت ثبت‌شده یا پرونده مشتری در این سالن)
  const isVerifiedCustomerOfBusiness = React.useMemo(() => {
    if (!authUser) return false;
    if (
      authUser.isPlatformAdmin ||
      authUser.roles?.includes('PLATFORM_ADMIN')
    ) {
      return true;
    }
    const cleanUserPhone = normalizeIranMobileInput(authUser.phone || '');
    const cleanUserName = (authUser.fullName || '').trim();

    const hasAppointmentWithBiz = appointments.some((apt) => {
      if (apt.status === 'CANCELLED') return false;
      const matchesBiz =
        apt.businessId === business.id || apt.businessSlug === business.slug;
      if (!matchesBiz) return false;
      const aptPhone = normalizeIranMobileInput(apt.customerPhoneMasked || '');
      if (cleanUserPhone && aptPhone && cleanUserPhone === aptPhone) {
        return true;
      }
      if (
        cleanUserPhone &&
        apt.customerPhoneMasked &&
        cleanUserPhone.length === 11 &&
        apt.customerPhoneMasked.includes('***')
      ) {
        const prefix = cleanUserPhone.slice(0, 4);
        const suffix = cleanUserPhone.slice(7);
        const rawMasked = apt.customerPhoneMasked.replace(
          /[۰-۹]/g,
          (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
        );
        if (rawMasked.startsWith(prefix) && rawMasked.endsWith(suffix)) {
          return true;
        }
      }
      return (
        Boolean(cleanUserName) &&
        cleanUserName !== 'کاربر تایم تو' &&
        apt.customerName.trim() === cleanUserName
      );
    });

    if (hasAppointmentWithBiz) return true;

    const hasCustomerRecordInBiz = customers.some((c) => {
      if (c.businessId && c.businessId !== business.id) return false;
      const cPhone = normalizeIranMobileInput(c.phone || c.phoneMasked || '');
      return Boolean(cleanUserPhone && cPhone && cleanUserPhone === cPhone);
    });

    return hasCustomerRecordInBiz;
  }, [authUser, appointments, customers, business.id, business.slug]);

  const bizGallery = gallery.filter((g) => g.businessId === business.id);
  const isFavorite =
    mode === 'pro' && matchedSpecialist
      ? favoriteSpecialistIds.includes(matchedSpecialist.id)
      : favoriteBusinessIds.includes(business.id);
  const handleToggleProfileFavorite = () => {
    if (!authUser) {
      openAuthModal({
        initialScreen: 'LOGIN',
        defaultRole: 'CUSTOMER',
        promptReason: `برای ذخیره «${business.name}» در علاقه‌مندی‌ها، وارد شوید یا ثبت‌نام کنید`,
      });
      return;
    }
    if (mode === 'pro' && matchedSpecialist) {
      toggleFavoriteSpecialist(matchedSpecialist.id);
    } else {
      toggleFavoriteBusiness(business.id);
    }
  };

  const handleRequireAuthForBooking = (e: React.MouseEvent, targetHref: string) => {
    if (!authUser) {
      e.preventDefault();
      openAuthModal({
        initialScreen: 'LOGIN',
        defaultRole: 'CUSTOMER',
        redirectTo: targetHref,
        promptReason: `برای رزرو آنلاین نوبت در «${business.name}»، وارد شوید یا ثبت‌نام کنید`,
      });
    }
  };

  const displayName =
    mode === 'pro' && matchedSpecialist
      ? `${matchedSpecialist.fullName} — ${matchedSpecialist.roleTitle}`
      : business.name;

  const hasCustomCoverBanner = Boolean(business.coverUrl?.trim());
  const customAvatarOnlyUrl =
    mode === 'pro' && matchedSpecialist
      ? matchedSpecialist.avatarUrl?.trim() || business.avatarUrl?.trim() || ''
      : business.avatarUrl?.trim() || '';

  const heroBannerUrl = hasCustomCoverBanner
    ? business.coverUrl!.trim()
    : customAvatarOnlyUrl ||
      (mode === 'pro' && matchedSpecialist
        ? getBeautyPhotoUrl(displayName, business.typeLabel, 'botanical')
        : getBeautyPhotoUrl(displayName, business.typeLabel));

  const proAvatarUrl =
    mode === 'pro' && matchedSpecialist
      ? matchedSpecialist.avatarUrl?.trim() ||
        business.avatarUrl?.trim() ||
        getSpecialistAvatarUrl(
          matchedSpecialist.fullName,
          matchedSpecialist.roleTitle
        )
      : business.avatarUrl?.trim() ||
        business.coverUrl?.trim() ||
        getBeautyPhotoUrl(business.name, business.typeLabel);

  const [activeActionModal, setActiveActionModal] = useState<
    'INSTAGRAM' | 'CONSULTATION' | 'MAP' | 'QR_SHARE' | null
  >(null);
  const [consultQuestion, setConsultQuestion] = useState('');
  const [consultPhone, setConsultPhone] = useState(authUser?.phone || '');
  const [consultSubmitted, setConsultSubmitted] = useState(false);

  const cleanInstaHandle = (business.instagramHandle || '@timeto.beauty')
    .trim()
    .replace(/^@/, '');
  const instagramUrl = `https://www.instagram.com/${cleanInstaHandle}`;
  const fullManualAddressQuery = [
    business.city || 'اصفهان',
    business.neighborhood,
    business.address,
  ]
    .filter(Boolean)
    .join('، ')
    .trim();
  const googleMapsUrl =
    business.address && business.address.trim().length >= 5
      ? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(fullManualAddressQuery)}`
      : `https://www.google.com/maps?q=${business.mapLat ?? 32.6362},${business.mapLng ?? 51.665}`;

  const quickActions = [
    {
      label: 'اینستاگرام',
      icon: <Instagram className="w-5 h-5 text-[#8B5CF6]" />,
      onClick: () => setActiveActionModal('INSTAGRAM'),
    },
    {
      label: 'مشاوره',
      icon: <MessageCircle className="w-5 h-5 text-[#8B5CF6]" />,
      onClick: () => {
        setConsultSubmitted(false);
        setActiveActionModal('CONSULTATION');
      },
    },
    {
      label: 'مسیریابی',
      icon: <MapPin className="w-5 h-5 text-[#8B5CF6]" />,
      onClick: () => {
        setActiveActionModal('MAP');
        const mapEl = document.getElementById('salon-map-section');
        if (mapEl) {
          mapEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      },
    },
    {
      label: 'اشتراک‌گذاری',
      icon: <Share2 className="w-5 h-5 text-[#8B5CF6]" />,
      onClick: () => setActiveActionModal('QR_SHARE'),
    },
  ];

  // فقط عکس‌های واقعی آپلودشده توسط صاحب کسب‌وکار در گالری نمایش داده می‌شود (بدون هیچ عکس نمونه فیک)
  const portfolioPhotos = bizGallery.map((g) => ({
    id: g.id,
    title: g.title,
    categoryLabel: g.categoryLabel,
    url: g.imageUrl || getBeautyPhotoUrl(g.title, g.categoryLabel),
  }));

  return (
    <div className="space-y-8 pb-24 lg:pb-8">
      {business.isSampleShowcase ? (
        <div className="p-4 rounded-3xl bg-[#FFFBEB] border-2 border-[#F59E0B] text-[#92400E] flex flex-wrap items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-2.5 text-xs sm:text-sm">
            <Sparkles className="w-5 h-5 text-[#D97706] shrink-0 mt-0.5" />
            <div>
              <p className="font-extrabold">
                پروفایل نمونه نمایشی پلتفرم Timeto (صرفاً جهت مشاهده محیط سالن‌ها)
              </p>
              <p className="text-xs text-[#B45309] mt-0.5">
                این سالن یک نمونه نمایشی از امکانات ویترین آنلاین تایم تو است و امکان ثبت رزرو واقعی روی آن غیرفعال است. کسب‌وکارهای واقعی می‌توانند از بخش «ثبت سالن» پروفایل خود را رایگان ایجاد کنند.
              </p>
            </div>
          </div>
          <Link to="/business/register">
            <Button variant="primary" size="sm">
              <span>ثبت سالن واقعی شما ←</span>
            </Button>
          </Link>
        </div>
      ) : null}
      {/* ۱. هدر تصویری تمام‌عرض + کارت سفید روی‌هم‌افتاده (Overlapping Profile Sheet) — با تفکیک هوشمند بنر عریض (coverUrl) از عکس پروفایل ۱:۱ (avatarUrl) */}
      <section className="relative">
        <div className="relative h-64 sm:h-80 lg:h-96 rounded-[32px] overflow-hidden border border-[#E6E0F5] bg-[#0B132B] shadow-md">
          {!hasCustomCoverBanner && customAvatarOnlyUrl ? (
            <>
              <img
                src={heroBannerUrl}
                alt=""
                aria-hidden="true"
                className="w-full h-full object-cover object-center blur-2xl scale-110 opacity-65 select-none pointer-events-none"
              />
              <img
                src={heroBannerUrl}
                alt={displayName}
                className="relative z-[1] w-full h-full object-contain object-center"
              />
            </>
          ) : (
            <img
              src={heroBannerUrl}
              alt={displayName}
              className="w-full h-full object-cover object-center"
            />
          )}
          <div className="absolute inset-0 z-[2] bg-gradient-to-t from-[#1E1B2E]/80 via-[#1E1B2E]/20 to-black/25 pointer-events-none" />

          {/* دکمه‌های دایره‌ای آیکونی بالای تصویر کاور (فقط آیکون بدون نوشته) */}
          <div className="absolute top-4 sm:top-6 inset-x-4 sm:inset-x-6 flex items-center justify-between z-10">
            <Link
              to="/search"
              aria-label="بازگشت به سالن‌ها"
              title="بازگشت به سالن‌ها"
              className="w-10 h-10 rounded-full bg-white/92 hover:bg-white backdrop-blur-md flex items-center justify-center text-[#1E1B2E] shadow-sm transition-transform active:scale-95"
            >
              <ArrowRight className="w-5 h-5 text-[#8B5CF6]" />
            </Link>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={handleToggleProfileFavorite}
                aria-pressed={isFavorite}
                aria-label={
                  isFavorite ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'
                }
                title={
                  isFavorite ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'
                }
                className="w-10 h-10 rounded-full bg-white/92 hover:bg-white backdrop-blur-md flex items-center justify-center shadow-sm cursor-pointer transition-transform active:scale-95"
              >
                <Heart
                  className={`w-5 h-5 ${
                    isFavorite
                      ? 'text-[#8B5CF6] fill-[#8B5CF6]'
                      : 'text-[#1E1B2E]'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* کارت سفید روی‌هم‌افتاده (Bond Beauty Salon در Capture4.PNG + Karikos Julieta در Capture1.PNG) */}
        <div className="relative z-10 -mt-14 sm:-mt-16 mx-3 sm:mx-8 rounded-[32px] bg-white border border-[#E6E0F5] p-5 sm:p-8 shadow-[0_18px_45px_-20px_rgba(139,92,246,0.16)]">
          {/* قرص تیره امتیاز روی لبه بالایی کارت سفید — دقیقاً مطابق Capture4.PNG */}
          <div className="flex justify-center -mt-9 sm:-mt-11 mb-4">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#1E1B2E] text-white text-xs font-extrabold shadow-md border border-white/15 tabular-nums">
              <Star className="w-3.5 h-3.5 text-[#F59E0B] fill-[#F59E0B]" />
              <span>
                {toPersianDigits(business.rating)} از ۵ (
                {toPersianDigits(business.reviewCount)} دیدگاه)
              </span>
              {business.verifiedBadge ? (
                <>
                  <span className="opacity-40">|</span>
                  <span className="inline-flex items-center gap-1 text-[#10B981]">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>تاییدشده</span>
                  </span>
                </>
              ) : null}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-7 flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-right gap-4">
                {/* آواتار دایره‌ای بزرگ متخصص یا سالن + حلقه استوری VIP */}
              {(() => {
                const salonStories = (businessStories || []).filter(
                  (st) => st.businessId === business.id
                );
                const hasStories = salonStories.length > 0;
                return (
                  <button
                    type="button"
                    onClick={() => {
                      if (hasStories) setActiveStoryIndex(0);
                    }}
                    disabled={!hasStories}
                    title={
                      hasStories
                        ? 'مشاهده استوری و پیشنهاد ویژه امروز سالن'
                        : displayName
                    }
                    className={`relative shrink-0 rounded-full ${
                      hasStories
                        ? 'p-1 bg-gradient-to-tr from-[#F59E0B] via-[#EC4899] to-[#8B5CF6] cursor-pointer shadow-lg hover:scale-105 transition-transform'
                        : ''
                    }`}
                  >
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden ring-4 ring-white shadow-md">
                      <img
                        src={proAvatarUrl}
                        alt={displayName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {hasStories ? (
                      <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-gradient-to-r from-[#EC4899] to-[#8B5CF6] text-white text-[9px] font-extrabold whitespace-nowrap shadow-xs">
                        🔥 استوری فعال
                      </span>
                    ) : null}
                  </button>
                );
              })()}

              <div className="space-y-2">
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs text-[#8B5CF6] font-bold">
                  <span>
                    {mode === 'pro' ? 'متخصص مستقل زیبایی' : business.typeLabel}
                  </span>
                  <span>·</span>
                  <span className="inline-flex items-center gap-1 text-[#6B6480]">
                    <MapPin className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    {business.city}، {business.neighborhood}
                  </span>
                </div>

                <h1 className="text-xl sm:text-3xl font-extrabold text-[#1E1B2E]">
                  {displayName}
                </h1>

                <p className="text-xs sm:text-sm text-[#6B6480] leading-relaxed max-w-2xl">
                  {mode === 'pro' && matchedSpecialist
                    ? matchedSpecialist.bio
                    : business.aboutText}
                </p>
              </div>
            </div>

            {/* ۴ دکمه دایره‌ای دسترسی سریع (اینستاگرام، مشاوره، مسیریابی، کیوآرکد) — شماره تماس پس از ثبت نوبت نمایش داده می‌شود */}
            <div className="lg:col-span-5 flex flex-col items-center lg:items-end justify-between gap-4 border-t lg:border-t-0 pt-4 lg:pt-0 border-[#E6E0F5]">
              <div className="grid grid-cols-4 gap-2.5 sm:gap-3.5 w-full max-w-sm">
                {quickActions.map((act) => (
                  <button
                    key={act.label}
                    type="button"
                    onClick={act.onClick}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <span className="w-11 h-11 sm:w-12 sm:h-12 rounded-full border border-[#E6E0F5] bg-[#FAF8FF] group-hover:bg-[#8B5CF6] group-hover:border-[#8B5CF6] flex items-center justify-center transition-colors shadow-2xs">
                      <span className="group-hover:[&_svg]:!text-white transition-colors">
                        {act.icon}
                      </span>
                    </span>
                    <span className="text-[10px] sm:text-[11px] font-bold text-[#6B6480] group-hover:text-[#1E1B2E] whitespace-nowrap">
                      {act.label}
                    </span>
                  </button>
                ))}
              </div>

              <div className="w-full max-w-sm flex items-center justify-between gap-3 pt-2 border-t border-[#E6E0F5]">
                <div className="text-xs">
                  <span className="text-[#6B6480] block">شروع تعرفه خدمات</span>
                  <strong className="text-sm font-extrabold text-[#8B5CF6] tabular-nums">
                    {formatStartingTariff(effectiveStartingPriceToman)}
                  </strong>
                </div>
                {business.isSampleShowcase ? (
                  <button
                    type="button"
                    onClick={() =>
                      showToast(
                        'این سالن یک نمونه نمایشی جهت آشنایی با پلتفرم است و امکان ثبت رزرو روی نمونه‌های نمایشی وجود ندارد.'
                      )
                    }
                    className="px-5 py-2.5 rounded-full bg-[#FEF3C7] text-[#92400E] border border-[#F59E0B] text-xs font-extrabold inline-flex items-center gap-2 cursor-not-allowed"
                  >
                    <Info className="w-4 h-4" />
                    <span>نمونه نمایشی (غیرقابل رزرو)</span>
                  </button>
                ) : (
                  <Link
                    to={`/booking/${business.slug}`}
                    onClick={(e) =>
                      handleRequireAuthForBooking(e, `/booking/${business.slug}`)
                    }
                    className="px-6 py-2.5 rounded-full bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs sm:text-sm font-extrabold inline-flex items-center gap-2 shadow-[0_8px_20px_-6px_rgba(139,92,246,0.45)] transition-colors"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>رزرو آنلاین نوبت</span>
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ۱.۵. ردیف استوری‌ها و هایلایت‌های روزانه سالن (اختصاصی پلن VIP) — جایگاه بالای پروفایل */}
      {(() => {
        const salonStories = (businessStories || []).filter(
          (st) => st.businessId === business.id
        );
        const isCurrentSalonOwner = Boolean(
          authUser && ownedBusinessId === business.id
        );
        if (salonStories.length === 0 && !isCurrentSalonOwner) return null;

        const activeStory =
          activeStoryIndex !== null ? salonStories[activeStoryIndex] : null;

        return (
          <>
            <section className="rounded-3xl bg-gradient-to-l from-[#FFFBEB] via-white to-[#F5F0FF] border border-[#FDE68A] p-4 sm:p-5 shadow-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-[#F59E0B] to-[#EC4899] text-white text-[10px] font-extrabold">
                    ✨ استوری و هایلایت VIP
                  </span>
                  <h2 className="text-xs sm:text-sm font-extrabold text-[#1E1B2E]">
                    استوری‌های روزانه، تخفیف‌ها و ظرفیت‌های ویژه امروز سالن
                  </h2>
                </div>
                {isCurrentSalonOwner ? (
                  <Link
                    to="/app/gallery"
                    className="text-[11px] font-extrabold text-[#7C3AED] hover:underline"
                  >
                    + مدیریت / افزودن استوری جدید در پنل کسب‌وکار ←
                  </Link>
                ) : (
                  <span className="text-[11px] text-[#6B6480] font-semibold">
                    برای مشاهده روی دایره‌ها کلیک کنید
                  </span>
                )}
              </div>

              {salonStories.length === 0 ? (
                <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-white/90 border border-dashed border-[#F59E0B]/50 text-xs text-[#6B6480]">
                  <span>
                    شما صاحب این کسب‌وکار هستید. استوری‌های روزانه و هایلایت‌های VIP شما دقیقاً در همین نوار بالای پروفایل به مراجعین نمایش داده می‌شود.
                  </span>
                  <Link
                    to="/app/gallery"
                    className="px-3.5 py-1.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-extrabold hover:bg-[#7C3AED]"
                  >
                    ثبت اولین استوری VIP
                  </Link>
                </div>
              ) : (
                <div className="flex items-center gap-4 overflow-x-auto pb-1">
                  {salonStories.map((st, idx) => (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => setActiveStoryIndex(idx)}
                      className="flex flex-col items-center gap-1.5 shrink-0 group cursor-pointer"
                    >
                      <div className="p-0.5 rounded-full bg-gradient-to-tr from-[#F59E0B] via-[#EC4899] to-[#8B5CF6] shadow-md group-hover:scale-105 transition-transform">
                        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden border-2 border-white bg-[#FAF8FF]">
                          <img
                            src={st.imageUrl}
                            alt={st.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-[#FEF3C7] text-[#92400E] text-[9px] font-extrabold -mt-3 relative z-10 border border-[#FDE68A]">
                        {st.badgeLabel || 'پیشنهاد ویژه'}
                      </span>
                      <span className="text-[11px] font-extrabold text-[#1E1B2E] max-w-[96px] truncate">
                        {st.title}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </section>

            {/* مودال تمام‌صفحه مشاهده استوری سالن با دکمه رزرو مستقیم */}
            {activeStory ? (
              <div
                className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4"
                onClick={() => setActiveStoryIndex(null)}
              >
                <div
                  className="relative w-full max-w-md rounded-3xl overflow-hidden bg-[#1E1B2E] text-white shadow-2xl border border-white/15"
                  onClick={(e) => e.stopPropagation()}
                >
                  {/* نوار پیشرفت بالای استوری */}
                  <div className="flex gap-1.5 p-3 bg-gradient-to-b from-black/70 to-transparent absolute top-0 inset-x-0 z-20">
                    {salonStories.map((sItem, i) => (
                      <button
                        key={sItem.id}
                        type="button"
                        onClick={() => setActiveStoryIndex(i)}
                        className={`h-1 flex-1 rounded-full transition-all cursor-pointer ${
                          i === activeStoryIndex ? 'bg-white' : 'bg-white/35'
                        }`}
                      />
                    ))}
                  </div>

                  {/* هدر اطلاعات سالن در استوری */}
                  <div className="flex items-center justify-between px-4 pt-6 pb-3 bg-gradient-to-b from-black/80 to-transparent absolute top-2 inset-x-0 z-10">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={proAvatarUrl}
                        alt={displayName}
                        className="w-9 h-9 rounded-full object-cover border-2 border-[#EC4899]"
                      />
                      <div>
                        <p className="text-xs font-extrabold text-white">
                          {displayName}
                        </p>
                        <p className="text-[10px] text-white/75">
                          {activeStory.createdAtJalali} ·{' '}
                          {activeStory.badgeLabel || 'استوری ویژه'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveStoryIndex(null)}
                      className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold flex items-center justify-center cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>

                  {/* تصویر استوری */}
                  <div className="relative aspect-[4/5] w-full bg-black">
                    <img
                      src={activeStory.imageUrl}
                      alt={activeStory.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/70 to-transparent p-5 pt-16 space-y-3">
                      <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#F59E0B] text-[#1E1B2E] text-[10px] font-extrabold">
                        {activeStory.badgeLabel || 'پیشنهاد ویژه'}
                      </span>
                      <h3 className="text-base sm:text-lg font-extrabold text-white">
                        {activeStory.title}
                      </h3>
                      {activeStory.caption ? (
                        <p className="text-xs text-white/90 leading-relaxed">
                          {activeStory.caption}
                        </p>
                      ) : null}

                      <div className="pt-2 flex items-center gap-2">
                        <Link
                          to={`/booking/${business.slug}${
                            activeStory.linkedServiceId
                              ? `?service=${activeStory.linkedServiceId}`
                              : ''
                          }`}
                          onClick={(e) => {
                            setActiveStoryIndex(null);
                            handleRequireAuthForBooking(
                              e,
                              `/booking/${business.slug}${
                                activeStory.linkedServiceId
                                  ? `?service=${activeStory.linkedServiceId}`
                                  : ''
                              }`
                            );
                          }}
                          className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] hover:opacity-95 text-white text-xs sm:text-sm font-extrabold text-center shadow-lg"
                        >
                          {activeStory.ctaLabel || 'رزرو آنلاین این پیشنهاد ←'}
                        </Link>
                        {salonStories.length > 1 ? (
                          <button
                            type="button"
                            onClick={() =>
                              setActiveStoryIndex(
                                ((activeStoryIndex ?? 0) + 1) %
                                  salonStories.length
                              )
                            }
                            className="px-3.5 py-3 rounded-2xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold cursor-pointer"
                          >
                            بعدی
                          </button>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        );
      })()}

      {/* ۲. چیدمان دو ستونی: تب‌های کپسولی آیکون‌دار (با ادغام خدمات پرطرفدار و دسته‌بندی مستقیم داخل تعرفه‌ها) + ماژول چسبان رزرو */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
        <div className="lg:col-span-8 space-y-5">
          <Tabs
            activeTab={activeTab}
            onChange={setActiveTab}
            tabs={[
              {
                id: 'services',
                label: 'خدمات و تعرفه‌ها',
                count: bizServices.length,
                icon: <Scissors className="w-3.5 h-3.5" />,
              },
              {
                id: 'gallery',
                label: 'گالری نمونه‌کارها',
                count: portfolioPhotos.length,
                icon: <ImageIcon className="w-3.5 h-3.5" />,
              },
              {
                id: 'staff',
                label: 'متخصصان سالن',
                count: bizSpecialists.length,
                icon: <Users className="w-3.5 h-3.5" />,
              },
              {
                id: 'reviews',
                label: 'دیدگاه مراجعان',
                count: bizReviews.length,
                icon: <MessageCircle className="w-3.5 h-3.5" />,
              },
              {
                id: 'about',
                label: 'درباره و قوانین',
                icon: <Info className="w-3.5 h-3.5" />,
              },
            ]}
          />

          {activeTab === 'services' ? (
            <Card className="rounded-3xl space-y-3.5">
              {/* هدر راهنمای سریع انتخاب تک یا چند خدمت + فیلتر دسته‌بندی و پرطرفدارها */}
              <div className="space-y-2.5 pb-3 border-b border-[#E6E0F5]">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-xs font-extrabold text-[#1E1B2E]">
                    <Scissors className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    <span>فهرست خدمات و تعرفه‌ها</span>
                    <span className="text-[11px] font-normal text-[#6B6480]">
                      (امکان انتخاب هم‌زمان چند خدمت)
                    </span>
                  </div>
                  {selectedProfileServiceIds.length > 0 ? (
                    <button
                      type="button"
                      onClick={() => setSelectedProfileServiceIds([])}
                      className="text-[11px] font-bold text-rose-600 hover:underline cursor-pointer"
                    >
                      پاک کردن انتخاب ({toPersianDigits(selectedProfileServiceIds.length)})
                    </button>
                  ) : null}
                </div>

                {bizServices.length > 3 ? (
                  <div className="relative">
                    <Input
                      value={publicServiceQuery}
                      onChange={(e) => setPublicServiceQuery(e.target.value)}
                      placeholder="جست‌وجوی سریع خدمت (مثلاً اصلاح، فیشیال، فول‌بادی...)"
                    />
                  </div>
                ) : null}

                {bizServices.length > 1 ? (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedServiceCategory('ALL');
                        setShowAllPublicServices(false);
                      }}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
                        selectedServiceCategory === 'ALL'
                          ? 'bg-[#8B5CF6] text-white'
                          : 'bg-[#FAF8FF] text-[#6B6480] border border-[#E6E0F5] hover:bg-[#EDE9FE]'
                      }`}
                    >
                      همه خدمات ({toPersianDigits(bizServices.length)})
                    </button>

                    {popularServices.length > 0 && bizServices.length > 2 ? (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedServiceCategory('POPULAR');
                          setShowAllPublicServices(false);
                        }}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
                          selectedServiceCategory === 'POPULAR'
                            ? 'bg-[#F59E0B] text-white'
                            : 'bg-[#FFFBEB] text-[#B45309] border border-[#FDE68A] hover:bg-[#FEF3C7]'
                        }`}
                      >
                        ★ پرطرفدارها ({toPersianDigits(popularServices.length)})
                      </button>
                    ) : null}

                    {serviceCategories.map((cat) => {
                      const catCount = bizServices.filter(
                        (s) => s.category === cat
                      ).length;
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => {
                            setSelectedServiceCategory(cat);
                            setShowAllPublicServices(false);
                          }}
                          className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
                            selectedServiceCategory === cat
                              ? 'bg-[#8B5CF6] text-white'
                              : 'bg-[#FAF8FF] text-[#6B6480] border border-[#E6E0F5] hover:bg-[#EDE9FE]'
                          }`}
                        >
                          {cat} ({toPersianDigits(catCount)})
                        </button>
                      );
                    })}
                  </div>
                ) : null}
              </div>

              {filteredServices.length === 0 ? (
                <EmptyState title="خدمتی در این دسته‌بندی ثبت نشده است" />
              ) : (
                <div className="space-y-2.5">
                  <div className="space-y-2">
                    {(showAllPublicServices
                      ? filteredServices
                      : filteredServices.slice(0, 8)
                    ).map((srv) => (
                      <ServiceCard
                        key={srv.id}
                        service={srv}
                        actionLabel="رزرو"
                        isPopularBadge={popularServiceIdSet.has(srv.id)}
                        isSelected={selectedProfileServiceIds.includes(srv.id)}
                        onToggleSelect={(s) => handleToggleProfileService(s.id)}
                        bookingHref={`/booking/${business.slug}?service=${srv.id}`}
                      />
                    ))}
                  </div>

                  {filteredServices.length > 8 ? (
                    <div className="pt-1 text-center">
                      <button
                        type="button"
                        onClick={() => setShowAllPublicServices((p) => !p)}
                        className="px-4 py-2 rounded-full bg-[#F5F3FF] hover:bg-[#EDE9FE] text-[#8B5CF6] text-xs font-extrabold border border-[#DDD6FE] cursor-pointer transition-colors"
                      >
                        {showAllPublicServices
                          ? 'نمایش خلاصه خدمات'
                          : `مشاهده همه ${toPersianDigits(filteredServices.length)} خدمت و تعرفه ↓`}
                      </button>
                    </div>
                  ) : null}

                  {/* نوار جمع‌وجور رزرو گروهی در صورت انتخاب یک یا چند خدمت از روی کارت‌ها */}
                  {selectedProfileServiceIds.length > 0 &&
                  !business.isSampleShowcase ? (
                    <div className="p-3 rounded-2xl bg-[#1E1B2E] text-white flex flex-wrap items-center justify-between gap-2.5 shadow-md">
                      <div className="text-xs">
                        <span className="text-[#C4B5FD] font-semibold">
                          انتخاب شما:{' '}
                        </span>
                        <strong className="font-extrabold tabular-nums">
                          {toPersianDigits(selectedProfileServiceIds.length)}{' '}
                          خدمت ·{' '}
                          {formatCompactPriceToman(selectedProfileServicesTotal)}
                        </strong>
                      </div>
                      <Link
                        to={`/booking/${business.slug}?service=${encodeURIComponent(selectedProfileServiceIds[0])}&services=${encodeURIComponent(selectedProfileServiceIds.join(','))}&step=${bizSpecialists.length <= 1 ? '3' : '2'}`}
                        onClick={(e) =>
                          handleRequireAuthForBooking(
                            e,
                            `/booking/${business.slug}?service=${encodeURIComponent(selectedProfileServiceIds[0])}&services=${encodeURIComponent(selectedProfileServiceIds.join(','))}&step=${bizSpecialists.length <= 1 ? '3' : '2'}`
                          )
                        }
                        className="px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-extrabold inline-flex items-center gap-1.5 transition-colors"
                      >
                        <span>ادامه و انتخاب زمان</span>
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </Link>
                    </div>
                  ) : null}
                </div>
              )}
            </Card>
          ) : activeTab === 'staff' ? (
            bizSpecialists.length === 0 ? (
              <EmptyState title="متخصصی برای این مرکز ثبت نشده است" />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {bizSpecialists.map((sp) => (
                  <ProfessionalCard
                    key={sp.id}
                    specialist={sp}
                    businessSlug={business.slug}
                  />
                ))}
              </div>
            )
          ) : activeTab === 'gallery' ? (
            /* شبکه نمونه‌کارهای واقعی سالن */
            <Card className="rounded-3xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E6E0F5] pb-3">
                <div>
                  <h3 className="text-sm font-extrabold text-[#1E1B2E]">
                    گالری نمونه‌کارهای واقعی سالن
                  </h3>
                  <p className="text-xs text-[#6B6480] mt-0.5">
                    تصاویر واقعی خدمات انجام‌شده در {business.name}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {authUser && ownedBusinessId === business.id ? (
                    <Link
                      to="/app/gallery"
                      className="px-3 py-1.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-extrabold transition-colors"
                    >
                      + آپلود عکس نمونه‌کار در گالری
                    </Link>
                  ) : null}
                  <span className="text-xs font-bold text-[#8B5CF6] tabular-nums">
                    {toPersianDigits(portfolioPhotos.length)} تصویر
                  </span>
                </div>
              </div>

              {portfolioPhotos.length === 0 ? (
                <div className="py-8 text-center space-y-3">
                  <p className="text-sm font-extrabold text-[#1E1B2E]">
                    هنوز عکسی در گالری نمونه‌کارهای این مرکز ثبت نشده است
                  </p>
                  <p className="text-xs text-[#6B6480] max-w-md mx-auto">
                    صاحب این کسب‌وکار می‌تواند از پنل مدیریت خود، تصاویر واقعی نمونه‌کارها را در گالری منتشر کند.
                  </p>
                  {authUser && ownedBusinessId === business.id ? (
                    <div className="pt-1">
                      <Link
                        to="/app/gallery"
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-extrabold"
                      >
                        <span>ورود به بخش گالری و آپلود اولین نمونه‌کار ←</span>
                      </Link>
                    </div>
                  ) : null}
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
                  {portfolioPhotos.map((item) => (
                    <div
                      key={item.id}
                      className="group relative aspect-[4/3] rounded-2xl overflow-hidden bg-[#EDE9FE] border border-[#E6E0F5]"
                    >
                      <img
                        src={item.url}
                        alt={item.title}
                        loading="lazy"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#1E1B2E]/80 via-transparent to-transparent" />
                      <div className="absolute bottom-2.5 inset-x-2.5 text-white">
                        <span className="text-[10px] font-bold text-white/80 block">
                          {item.categoryLabel}
                        </span>
                        <p className="text-xs font-extrabold truncate">
                          {item.title}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          ) : activeTab === 'reviews' ? (
            <div className="space-y-4">
              <Card
                variant="muted"
                className="rounded-3xl grid grid-cols-1 sm:grid-cols-12 gap-4 items-center"
              >
                <div className="sm:col-span-4 text-center sm:border-l sm:border-[#E6E0F5] sm:pl-4 space-y-1">
                  <p className="text-3xl font-extrabold text-[#8B5CF6] tabular-nums">
                    {toPersianDigits(business.rating)}
                  </p>
                  <p className="text-xs font-bold text-[#1E1B2E]">
                    از ۵ امتیاز
                  </p>
                  <p className="text-[11px] text-[#6B6480] tabular-nums">
                    بر اساس {toPersianDigits(bizReviews.length || business.reviewCount)} دیدگاه ثبت‌شده
                  </p>
                </div>
                <div className="sm:col-span-8 space-y-2 text-xs tabular-nums">
                  {[
                    {
                      stars: '۵ ستاره (عالی)',
                      pct:
                        bizReviews.length > 0
                          ? Math.round(
                              (bizReviews.filter((r) => r.rating === 5).length /
                                bizReviews.length) *
                                100
                            )
                          : 86,
                    },
                    {
                      stars: '۴ ستاره (خوب)',
                      pct:
                        bizReviews.length > 0
                          ? Math.round(
                              (bizReviews.filter((r) => r.rating === 4).length /
                                bizReviews.length) *
                                100
                            )
                          : 11,
                    },
                    {
                      stars: '۳ ستاره و کمتر (انتقادی)',
                      pct:
                        bizReviews.length > 0
                          ? Math.round(
                              (bizReviews.filter((r) => r.rating <= 3).length /
                                bizReviews.length) *
                                100
                            )
                          : 3,
                    },
                  ].map((row) => (
                    <div key={row.stars} className="flex items-center gap-3">
                      <span className="w-36 text-[#6B6480] font-medium">
                        {row.stars}
                      </span>
                      <div className="flex-1 h-2 rounded-full bg-white overflow-hidden border border-[#E6E0F5]">
                        <div
                          className="h-full bg-[#8B5CF6] rounded-full transition-all duration-300"
                          style={{ width: `${row.pct}%` }}
                        />
                      </div>
                      <span className="w-10 text-left font-bold text-[#1E1B2E]">
                        {toPersianDigits(row.pct)}٪
                      </span>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="rounded-3xl space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E6E0F5] pb-2.5">
                  <div>
                    <h3 className="text-sm font-extrabold text-[#1E1B2E]">
                      ثبت دیدگاه و امتیاز واقعی مراجعه
                    </h3>
                    <p className="text-[11px] text-[#6B6480] mt-0.5">
                      ثبت نظرات منفی و انتقاد منصفانه (حتی ۱ ستاره) کاملاً آزاد است و بدون سانسور منتشر می‌شود. تنها الفاظ رکیک یا حروف بی‌معنی مسدود می‌شوند.
                    </p>
                  </div>
                </div>

                {!authUser ? (
                  <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#E6E0F5] flex flex-wrap items-center justify-between gap-3 text-xs text-[#6B6480]">
                    <span>
                      برای ثبت امتیاز و دیدگاه درباره «{business.name}»، ابتدا با شماره موبایل خود وارد شوید (ویژه مشتریان این مجموعه).
                    </span>
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() =>
                        openAuthModal({
                          initialScreen: 'LOGIN',
                          defaultRole: 'CUSTOMER',
                          promptReason: `برای ثبت دیدگاه و امتیاز درباره «${business.name}»، وارد شوید`,
                        })
                      }
                    >
                      ورود به حساب و بررسی عضویت مشتری
                    </Button>
                  </div>
                ) : !isVerifiedCustomerOfBusiness ? (
                  <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-amber-900">
                    <div className="space-y-1">
                      <p className="font-extrabold text-amber-950">
                        ثبت امتیاز و نظر فقط مخصوص مشتریان «{business.name}» است
                      </p>
                      <p className="text-[11px] text-amber-800 leading-relaxed">
                        سیستم به صورت هوشمند بررسی می‌کند که فقط مراجعان واقعی این کسب‌وکار (کسانی که نوبت ثبت‌شده یا پرونده مشتری در این مجموعه دارند) بتوانند نظر و امتیاز ثبت کنند. پس از دریافت نوبت از این مرکز، فرم امتیازدهی برای شما فعال خواهد شد.
                      </p>
                    </div>
                    <Link
                      to={`/booking/${business.slug}`}
                      className="shrink-0 inline-flex items-center gap-1.5 rounded-xl bg-[#0057FF] px-3.5 py-2 text-xs font-black text-white shadow-2xs hover:bg-[#0046CC] transition"
                    >
                      <span>رزرو نوبت از این مرکز ←</span>
                    </Link>
                  </div>
                ) : (
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      if (reviewRating < 1 || reviewRating > 5) {
                        showToast(
                          'لطفاً ابتدا روی ستاره‌ها کلیک کنید و از ۱ تا ۵ ستاره امتیاز بدهید.',
                          'warning'
                        );
                        return;
                      }
                      const finalComment =
                        reviewComment.trim() ||
                        `ثبت امتیاز ${toPersianDigits(reviewRating)} ستاره توسط مشتری مجموعه`;
                      setIsSubmittingReview(true);
                      try {
                        const ok = await addReview({
                          businessId: business.id,
                          specialistSlug: matchedSpecialist?.slug,
                          serviceTitle:
                            reviewServiceTitle ||
                            bizServices[0]?.title ||
                            'خدمات زیبایی',
                          rating: reviewRating,
                          comment: finalComment,
                        });
                        if (ok) {
                          setReviewComment('');
                          setReviewRating(0);
                        }
                      } finally {
                        setIsSubmittingReview(false);
                      }
                    }}
                    className="space-y-3.5"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
                      <FormField id="rev-service" label="خدمت دریافت‌شده">
                        <Select
                          id="rev-service"
                          value={
                            reviewServiceTitle ||
                            bizServices[0]?.title ||
                            'خدمات زیبایی'
                          }
                          onChange={(e) =>
                            setReviewServiceTitle(e.target.value)
                          }
                          options={
                            bizServices.length > 0
                              ? bizServices.map((s) => ({
                                  value: s.title,
                                  label: s.title,
                                }))
                              : [
                                  {
                                    value: 'خدمات زیبایی',
                                    label: 'خدمات زیبایی',
                                  },
                                ]
                          }
                        />
                      </FormField>

                      <div className="space-y-1.5">
                        <span className="block text-xs font-extrabold text-[#1E1B2E]">
                          امتیاز ستاره‌ای شما (از ۱ تا ۵ ستاره انتخاب کنید):
                        </span>
                        <div className="flex items-center justify-between gap-2 p-2.5 rounded-2xl bg-[#FAF8FF] border border-[#E6E0F5]">
                          <div
                            className="flex items-center gap-1.5"
                            onMouseLeave={() => setReviewHoverRating(0)}
                          >
                            {[1, 2, 3, 4, 5].map((starVal) => {
                              const activeStars =
                                reviewHoverRating || reviewRating;
                              const isFilled = starVal <= activeStars;
                              return (
                                <button
                                  key={starVal}
                                  type="button"
                                  onMouseEnter={() =>
                                    setReviewHoverRating(starVal)
                                  }
                                  onClick={() => setReviewRating(starVal)}
                                  className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer border ${
                                    isFilled
                                      ? 'bg-amber-400/20 border-amber-400 text-amber-500 scale-105 shadow-2xs'
                                      : 'bg-white border-slate-200 text-slate-300 hover:border-amber-300 hover:text-amber-400'
                                  }`}
                                  title={`ثبت ${toPersianDigits(starVal)} ستاره`}
                                  aria-label={`ثبت ${toPersianDigits(starVal)} ستاره`}
                                >
                                  <Star
                                    className={`w-5 h-5 transition-transform ${
                                      isFilled
                                        ? 'fill-amber-400 text-amber-500'
                                        : 'fill-transparent text-slate-400'
                                    }`}
                                  />
                                </button>
                              );
                            })}
                          </div>
                          <span
                            className={`text-xs font-extrabold px-2.5 py-1 rounded-xl ${
                              reviewRating === 0
                                ? 'bg-slate-100 text-slate-600'
                                : reviewRating >= 4
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : reviewRating === 3
                                    ? 'bg-amber-50 text-amber-700'
                                    : 'bg-rose-50 text-rose-700'
                            }`}
                          >
                            {reviewRating === 0
                              ? '☆ ستاره‌ای انتخاب نشده'
                              : reviewRating === 5
                                ? '۵ ستاره (عالی)'
                                : reviewRating === 4
                                  ? '۴ ستاره (خوب)'
                                  : reviewRating === 3
                                    ? '۳ ستاره (متوسط)'
                                    : reviewRating === 2
                                      ? '۲ ستاره (ضعیف)'
                                      : '۱ ستاره (بسیار ضعیف)'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <FormField
                      id="rev-comment"
                      label="متن دیدگاه یا انتقاد شما (اختیاری — می‌توانید فقط ستاره بدهید یا نظر بنویسید)"
                    >
                      <Textarea
                        id="rev-comment"
                        rows={3}
                        value={reviewComment}
                        onChange={(e) => setReviewComment(e.target.value)}
                        placeholder="تجربه واقعی خود از کیفیت کار، برخورد پرسنل، قیمت یا نظم نوبت‌دهی را بنویسید (یا در صورت تمایل فقط ستاره بالا را انتخاب و ثبت کنید)..."
                      />
                    </FormField>

                    {reviewComment.trim().length > 0 &&
                      !validateReviewContent(reviewComment).valid && (
                        <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 flex items-start gap-2 text-xs text-rose-700 font-bold">
                          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                          <span>{validateReviewContent(reviewComment).reason}</span>
                        </div>
                      )}

                    <div className="flex items-center justify-between gap-3 pt-1">
                      <span className="text-[11px] text-emerald-700 font-bold">
                        ✓ مشتری تاییدشده مجموعه: <strong className="text-[#1E1B2E]">{authUser.fullName}</strong>
                      </span>
                      <Button
                        type="submit"
                        variant="primary"
                        size="sm"
                        disabled={
                          isSubmittingReview ||
                          reviewRating < 1 ||
                          (reviewComment.trim().length > 0 &&
                            !validateReviewContent(reviewComment).valid)
                        }
                      >
                        {isSubmittingReview
                          ? 'در حال ثبت...'
                          : reviewComment.trim().length === 0
                            ? `ثبت امتیاز ${reviewRating > 0 ? toPersianDigits(reviewRating) + ' ستاره' : ''}`
                            : 'ثبت امتیاز و انتشار دیدگاه'}
                      </Button>
                    </div>
                  </form>
                )}
              </Card>

              {bizReviews.length === 0 ? (
                <EmptyState title="هنوز دیدگاهی برای این مرکز ثبت نشده است" />
              ) : (
                <>
                  {visibleBizReviews.map((rev) => {
                  const isSuperAdmin =
                    Boolean(authUser?.isPlatformAdmin) ||
                    Boolean(authUser?.roles?.includes('PLATFORM_ADMIN'));
                  const isOwnerOfThisSalon =
                    ownedBusinessId === business.id ||
                    Boolean(
                      authUser?.businessMemberships?.some(
                        (m) =>
                          m.businessId === business.id ||
                          m.businessSlug === business.slug
                      )
                    );

                  return (
                    <Card key={rev.id} className="rounded-3xl space-y-3">
                      <div className="flex items-center justify-between text-xs gap-2 flex-wrap">
                        <div className="flex items-center gap-2">
                          <Avatar
                            name={rev.authorName}
                            size="sm"
                            showPhoto={false}
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-[#1E1B2E]">
                                {rev.authorName}
                              </span>
                              {rev.rating <= 2 && (
                                <span className="px-2 py-0.5 rounded-md bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-bold">
                                  دیدگاه انتقادی مشتری
                                </span>
                              )}
                              {rev.isReportedBySalon && isSuperAdmin && (
                                <span className="px-2 py-0.5 rounded-md bg-rose-50 border border-rose-200 text-rose-700 text-[10px] font-bold">
                                  گزارش‌شده توسط سالن
                                </span>
                              )}
                            </div>
                            <span className="font-medium text-[#6B6480] text-[11px]">
                              {rev.serviceTitle}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span
                            className={`tabular-nums font-extrabold px-2.5 py-1 rounded-xl ${
                              rev.rating >= 4
                                ? 'bg-amber-50 text-amber-600'
                                : rev.rating === 3
                                  ? 'bg-slate-100 text-slate-700'
                                  : 'bg-rose-50 text-rose-600'
                            }`}
                          >
                            ★ {toPersianDigits(rev.rating)} · {rev.dateJalali}
                          </span>

                          {isSuperAdmin && (
                            <button
                              type="button"
                              onClick={() => void deleteReviewByAdmin(rev.id)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-bold cursor-pointer transition-colors"
                              title="حذف دیدگاه حاوی فحاشی یا متن جفنگ توسط مدیر کل"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>حذف (فحاشی/جفنگ)</span>
                            </button>
                          )}
                        </div>
                      </div>

                      <p className="text-xs sm:text-sm text-[#1E1B2E] leading-relaxed">
                        {rev.comment}
                      </p>

                      {rev.salonReply && (
                        <div className="p-3 rounded-2xl bg-[#FAF8FF] border-r-4 border-[#8B5CF6] space-y-1 text-xs">
                          <div className="flex items-center justify-between text-[11px] text-[#8B5CF6] font-extrabold">
                            <span>پاسخ مدیریت {business.name}</span>
                            {rev.salonReplyDateJalali && (
                              <span className="text-[#6B6480] font-normal">
                                {rev.salonReplyDateJalali}
                              </span>
                            )}
                          </div>
                          <p className="text-[#1E1B2E] leading-relaxed">
                            {rev.salonReply}
                          </p>
                        </div>
                      )}

                      {(isOwnerOfThisSalon || isSuperAdmin) && (
                        <div className="pt-2 border-t border-[#F3EEFF] flex flex-wrap items-center justify-between gap-2 text-[11px]">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                if (replyingReviewId === rev.id) {
                                  setReplyingReviewId(null);
                                } else {
                                  setReplyingReviewId(rev.id);
                                  setReplyDraftText(rev.salonReply || '');
                                }
                              }}
                              className="inline-flex items-center gap-1 text-[#8B5CF6] hover:underline font-bold cursor-pointer"
                            >
                              <MessageSquareReply className="w-3.5 h-3.5" />
                              <span>
                                {rev.salonReply
                                  ? 'ویرایش پاسخ سالن'
                                  : 'پاسخ رسمی سالن به این دیدگاه'}
                              </span>
                            </button>
                          </div>

                          {!rev.isReportedBySalon ? (
                            <button
                              type="button"
                              onClick={() =>
                                void reportReviewAbuse(
                                  rev.id,
                                  'گزارش فحاشی یا عبارات نامفهوم (جفنگ) جهت بررسی مدیر کل'
                                )
                              }
                              className="inline-flex items-center gap-1 text-slate-500 hover:text-rose-600 font-semibold cursor-pointer"
                            >
                              <Flag className="w-3.5 h-3.5" />
                              <span>گزارش فحاشی یا جفنگ به مدیر کل</span>
                            </button>
                          ) : (
                            <span className="text-amber-700 font-semibold">
                              گزارش تخلف برای بررسی مدیر کل ارسال شده است
                            </span>
                          )}
                        </div>
                      )}

                      {replyingReviewId === rev.id && (
                        <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                          <Textarea
                            rows={2}
                            value={replyDraftText}
                            onChange={(e) => setReplyDraftText(e.target.value)}
                            placeholder="پاسخ محترمانه مدیریت سالن به دیدگاه یا انتقاد مشتری..."
                          />
                          <div className="flex justify-end gap-2">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => setReplyingReviewId(null)}
                            >
                              انصراف
                            </Button>
                            <Button
                              type="button"
                              variant="primary"
                              size="sm"
                              onClick={async () => {
                                const ok = await replyToReview(
                                  rev.id,
                                  replyDraftText
                                );
                                if (ok) {
                                  setReplyingReviewId(null);
                                }
                              }}
                            >
                              ثبت پاسخ سالن
                            </Button>
                          </div>
                        </div>
                      )}
                    </Card>
                  );
                })}

                {remainingReviewsCount > 0 ? (
                  <div className="pt-2 text-center">
                    <button
                      type="button"
                      onClick={() =>
                        setVisibleReviewsCount((prev) => prev + 5)
                      }
                      className="inline-flex items-center justify-center gap-2 rounded-2xl border-2 border-[#0057FF]/30 bg-[#EFF6FF] px-5 py-3 text-xs sm:text-sm font-black text-[#0057FF] hover:bg-[#0057FF] hover:text-white transition-all cursor-pointer shadow-2xs"
                    >
                      <span>
                        مشاهده نظرات بیشتر (نمایش{' '}
                        {toPersianDigits(Math.min(5, remainingReviewsCount))}{' '}
                        دیدگاه بعدی از {toPersianDigits(remainingReviewsCount)}{' '}
                        دیدگاه باقی‌مانده)
                      </span>
                    </button>
                  </div>
                ) : bizReviews.length > 5 ? (
                  <div className="pt-1 text-center">
                    <button
                      type="button"
                      onClick={() => setVisibleReviewsCount(5)}
                      className="text-xs font-bold text-slate-500 hover:text-[#061138] underline cursor-pointer"
                    >
                      بستن نظرات اضافی و نمایش ۵ نظر اول
                    </button>
                  </div>
                ) : null}
                </>
              )}
            </div>
          ) : (
            <Card className="rounded-3xl space-y-5">
              <div className="space-y-2">
                <h3 className="text-sm font-extrabold text-[#1E1B2E] inline-flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-[#8B5CF6]" />
                  <span>درباره {displayName}</span>
                </h3>
                <p className="text-xs sm:text-sm text-[#6B6480] leading-relaxed">
                  {business.aboutText}
                </p>
              </div>

              <div className="pt-4 border-t border-[#E6E0F5] space-y-2.5 text-xs text-[#6B6480]">
                <h4 className="font-extrabold text-[#1E1B2E]">
                  قوانین پذیرش، بیعانه و لغو نوبت
                </h4>
                <ul className="space-y-2 list-disc list-inside leading-relaxed">
                  <li>
                    لطفاً ۱۰ دقیقه پیش از ساعت شروع نوبت در سالن حضور داشته
                    باشید.
                  </li>
                  <li>
                    امکان لغو یا جابه‌جایی نوبت تا حداقل ۴ ساعت پیش از زمان
                    مراجعه از طریق بخش «نوبت‌های من» فراهم است.
                  </li>
                  <li>
                    در صورت فعال بودن بیعانه برای خدمت انتخابی، مبلغ بیعانه از
                    هزینه نهایی شما در سالن کسر خواهد شد.
                  </li>
                </ul>
              </div>
            </Card>
          )}
        </div>

        {/* ستون چسبان کناری: ماژول رزرو، پیش‌نمایش گالری ۳ ستونی و ساعات کاری */}
        <div className="lg:col-span-4 space-y-5 lg:sticky lg:top-20">
          <Card variant="dark" className="rounded-3xl space-y-4">
            <div className="space-y-1">
              <p className="text-xs font-semibold text-[#EDE9FE]">
                تقویم آنلاین ۲۴ ساعته
              </p>
              <h3 className="text-base font-extrabold text-white">
                رزرو نوبت در {business.name}
              </h3>
            </div>

            <div className="space-y-2 text-xs text-[#EDE9FE]/90 border-y border-white/10 py-3">
              <div className="flex items-center justify-between">
                <span>شروع تعرفه خدمات:</span>
                <span className="font-bold text-white tabular-nums">
                  {formatStartingTariff(effectiveStartingPriceToman)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>خدمات قابل رزرو:</span>
                <span className="font-bold text-white tabular-nums">
                  {toPersianDigits(bizServices.length)} خدمت فعال
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-[#10B981] pt-1">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>ثبت آنی و اطلاع‌رسانی فوری به سالن</span>
              </div>
            </div>

            {business.isSampleShowcase ? (
              <div className="p-3 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-200 text-xs font-bold text-center">
                پروفایل نمونه نمایشی (رزرو غیرفعال)
              </div>
            ) : (
              <Link
                to={`/booking/${business.slug}`}
                onClick={(e) =>
                  handleRequireAuthForBooking(e, `/booking/${business.slug}`)
                }
                className="block"
              >
                <Button variant="accent" size="lg" fullWidth>
                  <span>انتخاب خدمت و ساعت مراجعه</span>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
            )}
          </Card>

          {/* ویترین ۳ ستونی نمونه‌کارها در ستون کناری — مطابق Capture1.PNG و Capture4.PNG */}
          <Card className="rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-[#1E1B2E]">
                ویترین نمونه‌کارها
              </h3>
              <button
                type="button"
                onClick={() => setActiveTab('gallery')}
                className="text-xs font-bold text-[#8B5CF6] hover:underline cursor-pointer"
              >
                مشاهده همه ({toPersianDigits(portfolioPhotos.length)})
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {portfolioPhotos.slice(0, 6).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab('gallery')}
                  className="aspect-square rounded-xl overflow-hidden bg-[#EDE9FE] border border-[#E6E0F5] cursor-pointer group"
                >
                  <img
                    src={item.url}
                    alt={item.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </button>
              ))}
            </div>
          </Card>

          <Card className="rounded-3xl space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <Clock className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                <h3 className="text-xs sm:text-sm font-extrabold text-[#1E1B2E] truncate">
                  ساعات کاری
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowFullWeeklyHours((prev) => !prev)}
                className="text-[11px] font-extrabold text-[#8B5CF6] hover:underline cursor-pointer shrink-0"
              >
                {showFullWeeklyHours ? 'بستن برنامه هفتگی ▴' : 'مشاهده همه روزها ▾'}
              </button>
            </div>

            {/* نمایش خلاصه و مینیمال وضعیت امروز */}
            <div className="p-2.5 rounded-2xl bg-[#FAF8FF] border border-[#E6E0F5] flex items-center justify-between gap-2 text-xs">
              <span className="font-bold text-[#6B6480]">
                امروز ({todayWorkingHour?.dayName || todayJalaliDayName}):
              </span>
              <span
                className={`font-extrabold tabular-nums ${
                  todayWorkingHour?.isOpen ? 'text-[#10B981]' : 'text-rose-500'
                }`}
              >
                {formatCustomerWorkingHourMinimal(todayWorkingHour)}
              </span>
            </div>

            {showFullWeeklyHours ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-1.5 pt-1 text-xs">
                {business.workingHours.map((wh, index) => {
                  const isToday = wh.dayName === todayJalaliDayName;
                  return (
                    <div
                      key={index}
                      className={`flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-xl ${
                        isToday
                          ? 'bg-[#EDE9FE]/60 font-extrabold text-[#1E1B2E]'
                          : 'bg-[#FAF8FF] text-[#6B6480]'
                      }`}
                    >
                      <span className="shrink-0">{wh.dayName}</span>
                      <span
                        className={`tabular-nums text-left ${
                          wh.isOpen
                            ? 'text-[#1E1B2E] font-bold'
                            : 'text-rose-500 font-semibold'
                        }`}
                      >
                        {formatCustomerWorkingHourMinimal(wh)}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : null}
          </Card>

          <div id="salon-map-section">
            <Card padding="sm" className="rounded-3xl space-y-2.5">
              <LocationMapPicker
                city={business.city}
                neighborhood={business.neighborhood}
                address={business.address}
                lat={business.mapLat}
                lng={business.mapLng}
                readOnly
              />
            </Card>
          </div>
        </div>
      </div>

      {/* مودال‌های عملیاتی دکمه‌های ۵گانه پروفایل سالن (اینستاگرام، مشاوره، تماس، مسیریابی) */}
      <Modal
        isOpen={activeActionModal === 'INSTAGRAM'}
        onClose={() => setActiveActionModal(null)}
        title={`صفحه اینستاگرام ${business.name}`}
      >
        <div className="space-y-4 text-xs">
          <div className="p-4 rounded-2xl bg-[#FAF8FF] border border-[#E6E0F5] flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Instagram className="w-5 h-5 text-[#8B5CF6]" />
              <span className="font-bold text-[#1E1B2E]">آیدی اینستاگرام سالن:</span>
            </div>
            <span dir="ltr" className="font-mono text-sm font-black text-[#8B5CF6]">
              @{cleanInstaHandle}
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <a
              href={instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2.5 px-4 rounded-full bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-extrabold text-center transition-colors"
            >
              مشاهده صفحه در اینستاگرام ↗
            </a>
            <button
              type="button"
              onClick={() => {
                try {
                  void navigator.clipboard.writeText(`@${cleanInstaHandle}`);
                } catch {
                  // ignore
                }
                showToast('آیدی اینستاگرام کپی شد.', 'success');
              }}
              className="py-2.5 px-4 rounded-full bg-slate-100 hover:bg-slate-200 text-[#1E1B2E] font-bold text-center cursor-pointer transition-colors"
            >
              کپی آیدی اینستاگرام
            </button>
          </div>
        </div>
      </Modal>

      <Modal
        isOpen={activeActionModal === 'MAP'}
        onClose={() => setActiveActionModal(null)}
        title={`نشانی و مسیریابی ${business.name}`}
      >
        <div className="space-y-4 text-xs">
          <LocationMapPicker
            city={business.city}
            neighborhood={business.neighborhood}
            address={business.address}
            lat={business.mapLat}
            lng={business.mapLng}
            readOnly
          />
          <div className="flex justify-end gap-2">
            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-4 rounded-full bg-[#0057FF] hover:bg-[#0044CC] text-white font-extrabold text-center transition-colors"
            >
              باز کردن مستقیم در Google Maps و مسیریابی ↗
            </a>
          </div>
        </div>
      </Modal>

      <Modal
        isOpen={activeActionModal === 'CONSULTATION'}
        onClose={() => setActiveActionModal(null)}
        title={`درخواست مشاوره رایگان با ${business.name}`}
      >
        {consultSubmitted ? (
          <div className="p-4 rounded-2xl bg-[#ECFDF5] border border-[#A7F3D0] text-center space-y-2 text-xs">
            <CheckCircle2 className="w-8 h-8 text-[#10B981] mx-auto" />
            <p className="font-extrabold text-[#065F46] text-sm">
              درخواست مشاوره شما برای پذیرش سالن ارسال شد
            </p>
            <p className="text-[#047857]">
              کارشناسان «{business.name}» در ساعات کاری با شماره شما تماس خواهند گرفت. همچنین با ثبت نوبت آنلاین، شماره تماس مستقیم سالن در رسید نهایی شما نمایش داده می‌شود.
            </p>
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!consultQuestion.trim()) {
                showToast('لطفاً سوال یا خدمت مورد نظر خود را برای مشاوره بنویسید.', 'warning');
                return;
              }
              setConsultSubmitted(true);
              showToast('درخواست مشاوره شما با موفقیت ثبت شد.', 'success');
            }}
            className="space-y-3.5 text-xs"
          >
            <FormField id="cons-phone" label="شماره تماس شما جهت پاسخگویی" required>
              <Input
                id="cons-phone"
                dir="ltr"
                value={consultPhone}
                onChange={(e) => setConsultPhone(e.target.value)}
                placeholder="09131234567"
              />
            </FormField>
            <FormField id="cons-msg" label="موضوع مشاوره (مثلاً رنگ و لایت، خدمات عروس، فیشیال...)" required>
              <Textarea
                id="cons-msg"
                rows={3}
                value={consultQuestion}
                onChange={(e) => setConsultQuestion(e.target.value)}
                placeholder="سوال خود درباره تعرفه، ترکیب رنگ یا زمان‌بندی خدمت را بنویسید..."
              />
            </FormField>
            <div className="flex items-center justify-between gap-2 pt-1">
              <span className="text-[11px] text-[#64748B]">
                شماره تماس مستقیم سالن پس از ثبت نوبت آنلاین نمایش داده می‌شود
              </span>
              <Button type="submit" variant="primary" size="sm">
                ارسال درخواست مشاوره
              </Button>
            </div>
          </form>
        )}
      </Modal>

      <Modal
        isOpen={activeActionModal === 'QR_SHARE'}
        onClose={() => setActiveActionModal(null)}
        title={`اشتراک‌گذاری پروفایل ${business.name}`}
      >
        <BusinessQrCodeCard
          businessName={business.name}
          slug={business.slug}
          city={business.city}
          neighborhood={business.neighborhood}
          compact
        />
      </Modal>

      {/* نوار چسبان پایین موبایل برای رزرو سریع — مطابق دکمه کپسولی تیره Capture4.PNG */}
      <div className="lg:hidden fixed bottom-16 inset-x-0 z-30 bg-white/95 backdrop-blur-md border-t border-[#E6E0F5] px-4 py-3 flex items-center justify-between gap-3 shadow-[0_-4px_20px_-4px_rgba(30,27,46,0.10)]">
        <div className="min-w-0">
          <p className="text-xs font-extrabold text-[#1E1B2E] truncate">
            {business.name}
          </p>
          <p className="text-[11px] text-[#6B6480] tabular-nums">
            شروع از {formatStartingTariff(effectiveStartingPriceToman)}
          </p>
        </div>
        {business.isSampleShowcase ? (
          <span className="px-4 py-2 rounded-full bg-[#FEF3C7] text-[#92400E] border border-[#F59E0B] text-xs font-extrabold shrink-0">
            نمونه نمایشی
          </span>
        ) : (
          <Link
            to={`/booking/${business.slug}`}
            onClick={(e) =>
              handleRequireAuthForBooking(e, `/booking/${business.slug}`)
            }
            className="px-6 py-2.5 rounded-full bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-extrabold inline-flex items-center gap-2 shrink-0 shadow-[0_8px_20px_-6px_rgba(139,92,246,0.45)]"
          >
            <span>رزرو آنلاین نوبت</span>
            <ArrowLeft className="w-4 h-4" />
          </Link>
        )}
      </div>
    </div>
  );
};
