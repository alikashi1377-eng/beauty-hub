import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  Search,
  ArrowLeft,
  Check,
  Sparkles,
  Gem,
  Scissors,
  Droplets,
  Eye,
  UserCheck,
  Award,
  HeartHandshake,
  CalendarCheck,
  ShieldCheck,
  SlidersHorizontal,
  TrendingUp,
  Star,
  ChevronDown,
  ChevronLeft,
  ChevronsDown,
  ArrowUpDown,
  Zap,
  MapPin,
  Clock,
  Percent,
  Heart,
  X,
} from 'lucide-react';
const TIMETO_HERO_SPA_WEBP_URL = '/assets/beauty/timeto-hero-spa.webp';
import { IRAN_CITIES, ISFAHAN_NEIGHBORHOODS } from '../../mocks/sampleData';
import { BusinessType } from '../../types';
import {
  computeFairRotationScore,
  filterBusinesses,
  formatPriceToman,
  SortOption,
  toPersianDigits,
} from '../../utils/formatters';
import { usePrototypeData } from '../../context/PrototypeDataContext';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Input, Textarea } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { FormField } from '../../components/ui/FormField';
import { PageHeader } from '../../components/ui/PageHeader';
import { StatusBadge } from '../../components/ui/StatusBadge';
import {
  VisualMediaIllustration,
  getBeautyPhotoUrl,
  getSpecialistAvatarUrl,
} from '../../components/ui/VisualMediaIllustration';
import { EmptyState } from '../../components/ui/StateViews';
import {
  BusinessCard,
  ProfessionalCard,
} from '../../components/ui/MarketplaceComponents';
import { isBusinessReadyForPublicDisplay } from '../../components/business/BusinessProfileCompletionWidget';

const CATEGORY_ICON_MAP: Record<string, React.ReactNode> = {
  Sparkles: <Sparkles className="w-4 h-4 text-[#0057FF]" />,
  Gem: <Gem className="w-4 h-4 text-[#0057FF]" />,
  Scissors: <Scissors className="w-4 h-4 text-[#0057FF]" />,
  Droplets: <Droplets className="w-4 h-4 text-[#10B981]" />,
  Eye: <Eye className="w-4 h-4 text-[#0057FF]" />,
  UserCheck: <UserCheck className="w-4 h-4 text-[#334155]" />,
  Award: <Award className="w-4 h-4 text-[#0057FF]" />,
  HeartHandshake: <HeartHandshake className="w-4 h-4 text-[#10B981]" />,
};

export { HomePage } from './HomePage';


/** ۲. صفحه جست‌وجوی هوشمند سالن و متخصص (/search) */
export const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const {
    businesses,
    services,
    specialists,
    categories,
    favoriteBusinessIds,
    toggleFavoriteBusiness,
    favoriteSpecialistIds,
    toggleFavoriteSpecialist,
  } = usePrototypeData();

  const [query, setQuery] = useState(searchParams.get('q') ?? '');
  const [categoryFilter, setCategoryFilter] = useState<string>(
    searchParams.get('category') ?? 'ALL'
  );
  const [typeFilter, setTypeFilter] = useState<BusinessType | 'ALL'>('ALL');
  const [maxPrice, setMaxPrice] = useState<number>(10000000);
  const [sortBy, setSortBy] = useState<SortOption>('recommended');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  useEffect(() => {
    const qParam = searchParams.get('q');
    const catParam = searchParams.get('category');
    if (qParam !== null) setQuery(qParam);
    if (catParam !== null) setCategoryFilter(catParam);
  }, [searchParams]);

  // جست‌وجوی هوشمند: علاوه بر نام سالن، اگر نام خدمت یا متخصص با عبارت جست‌وجو همخوانی داشت سالن مربوطه هم برگردانده شود
  const normalizedQ = query.trim().toLowerCase();
  const businessIdsMatchingServicesOrStaff = React.useMemo(() => {
    if (!normalizedQ) return new Set<string>();
    const ids = new Set<string>();
    services.forEach((s) => {
      if (
        s.title.toLowerCase().includes(normalizedQ) ||
        s.category.toLowerCase().includes(normalizedQ)
      ) {
        ids.add(s.businessId);
      }
    });
    specialists.forEach((sp) => {
      if (
        sp.fullName.toLowerCase().includes(normalizedQ) ||
        sp.roleTitle.toLowerCase().includes(normalizedQ) ||
        sp.specialties.some((item) => item.toLowerCase().includes(normalizedQ))
      ) {
        ids.add(sp.businessId);
      }
    });
    return ids;
  }, [normalizedQ, services, specialists]);

  // اگر کاربر دسته‌بندی خاصی انتخاب کرد، سالن‌ها و متخصصانی که یا دسته‌شان آن است یا خدمتی/تخصصی در آن دسته دارند نمایش داده شوند
  const businessIdsMatchingSelectedCategory = React.useMemo(() => {
    if (categoryFilter === 'ALL') return null;
    const ids = new Set<string>();
    const isLaserCat = categoryFilter === 'laser-hair-removal';
    services.forEach((s) => {
      if (
        s.categorySlug === categoryFilter ||
        (isLaserCat &&
          (s.title.includes('لیزر') || (s.category || '').includes('لیزر')))
      ) {
        ids.add(s.businessId);
      }
    });
    specialists.forEach((sp) => {
      if (
        isLaserCat &&
        (sp.roleTitle.includes('لیزر') ||
          sp.fullName.includes('لیزر') ||
          sp.specialties.some((item) => item.includes('لیزر')))
      ) {
        ids.add(sp.businessId);
      }
    });
    return ids;
  }, [categoryFilter, services, specialists]);

  const publicReadyBusinesses = React.useMemo(() => {
    return businesses.filter((b) =>
      isBusinessReadyForPublicDisplay({ business: b, services, specialists })
    );
  }, [businesses, services, specialists]);

  const publicReadyBusinessIds = React.useMemo(() => {
    return new Set(publicReadyBusinesses.flatMap((b) => [b.id, b.slug]));
  }, [publicReadyBusinesses]);

  const baseFiltered = filterBusinesses(publicReadyBusinesses, {
    query: '',
    type: typeFilter,
    city: 'ALL',
    neighborhood: 'ALL',
    categorySlug: 'ALL',
    maxPriceToman: maxPrice,
    minRating: 0,
    sortBy,
  }).filter((b) => {
    if (categoryFilter === 'ALL') return true;
    const isLaserCat = categoryFilter === 'laser-hair-removal';
    const hasLaserKeyword =
      isLaserCat &&
      ((b.name || '').includes('لیزر') ||
        (b.typeLabel || '').includes('لیزر') ||
        (b.shortDescription || '').includes('لیزر'));
    return (
      b.categorySlug === categoryFilter ||
      hasLaserKeyword ||
      Boolean(businessIdsMatchingSelectedCategory?.has(b.id))
    );
  });

  const filtered = normalizedQ
    ? baseFiltered.filter(
        (b) =>
          (b.name || '').toLowerCase().includes(normalizedQ) ||
          (b.neighborhood || '').toLowerCase().includes(normalizedQ) ||
          (b.shortDescription || '').toLowerCase().includes(normalizedQ) ||
          (b.typeLabel || '').toLowerCase().includes(normalizedQ) ||
          businessIdsMatchingServicesOrStaff.has(b.id)
      )
    : baseFiltered;

  const matchedSpecialistsInSearch = React.useMemo(() => {
    if (!normalizedQ && categoryFilter === 'ALL') return [];
    const isLaserCat = categoryFilter === 'laser-hair-removal';
    return specialists.filter((sp) => {
      if (sp.isActive === false || !publicReadyBusinessIds.has(sp.businessId)) {
        return false;
      }
      const matchesQ =
        !normalizedQ ||
        sp.fullName.toLowerCase().includes(normalizedQ) ||
        sp.roleTitle.toLowerCase().includes(normalizedQ) ||
        sp.specialties.some((s) => s.toLowerCase().includes(normalizedQ));
      if (!matchesQ) return false;
      if (categoryFilter === 'ALL') return true;
      if (isLaserCat) {
        return (
          sp.roleTitle.includes('لیزر') ||
          sp.fullName.includes('لیزر') ||
          sp.specialties.some((s) => s.includes('لیزر')) ||
          Boolean(businessIdsMatchingSelectedCategory?.has(sp.businessId))
        );
      }
      return Boolean(businessIdsMatchingSelectedCategory?.has(sp.businessId));
    });
  }, [
    normalizedQ,
    categoryFilter,
    specialists,
    publicReadyBusinessIds,
    businessIdsMatchingSelectedCategory,
  ]);

  const handleResetFilters = () => {
    setQuery('');
    setTypeFilter('ALL');
    setCategoryFilter('ALL');
    setMaxPrice(10000000);
    setSortBy('recommended');
    setSearchParams({});
  };

  const finalFiltered = filtered;
  const hasActiveFilters =
    Boolean(query.trim()) ||
    categoryFilter !== 'ALL' ||
    typeFilter !== 'ALL' ||
    maxPrice < 10000000;

  return (
    <div className="space-y-4">
      {/* ۱. باکس جست‌وجوی بالا با آیکون مینیمال فیلتر در کنار آن */}
      <div className="bg-white p-3 sm:p-3.5 rounded-3xl border border-[#CBD5E1] shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3.5 py-2.5 rounded-2xl bg-[#F3F6FC] border border-[#CBD5E1] focus-within:border-[#0057FF] focus-within:bg-white transition-colors">
            <Search className="w-4 h-4 text-[#0057FF] shrink-0" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="جست‌وجوی سالن، مرکز لیزر، متخصص یا خدمت..."
              aria-label="جست‌وجوی سالن، متخصص یا خدمت"
              className="w-full text-xs sm:text-sm font-medium text-[#061138] placeholder:text-[#64748B] bg-transparent focus:outline-none"
            />
            {query ? (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="پاک کردن جست‌وجو"
                className="p-1 rounded-full hover:bg-[#E2E8F0] text-[#64748B] cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : null}
          </div>

          {/* دکمه آیکونی فیلتر قیمت و نوع مرکز */}
          <button
            type="button"
            onClick={() => setMobileFilterOpen((p) => !p)}
            aria-label="فیلتر نتایج"
            title="فیلتر سقف تعرفه و نوع مرکز"
            className={`w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0 transition-all cursor-pointer ${
              mobileFilterOpen || maxPrice < 10000000 || typeFilter !== 'ALL'
                ? 'bg-[#0057FF] text-white border-[#0057FF] shadow-2xs'
                : 'bg-[#F8FAFC] text-[#061138] border-[#CBD5E1] hover:border-[#0057FF]'
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>

        {/* پنل تاشو و مینیمال فیلتر (بدون امتیاز و بدون نام محله) */}
        {mobileFilterOpen ? (
          <div className="pt-3 border-t border-[#E2E8F0] grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-bold text-[#475569] ml-1">
                مخاطب:
              </span>
              {[
                { id: 'ALL', label: 'همه مراکز' },
                { id: BusinessType.WomenSalon, label: 'بانوان' },
                { id: BusinessType.MenBarbershop, label: 'آقایان' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTypeFilter(item.id as BusinessType | 'ALL')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer transition-colors ${
                    typeFilter === item.id
                      ? 'bg-[#0057FF] text-white'
                      : 'bg-[#F8FAFC] text-[#334155] border border-[#CBD5E1]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#475569]">سقف تعرفه پایه:</span>
                <span className="font-extrabold text-[#0057FF] tabular-nums">
                  {maxPrice >= 10000000
                    ? 'بدون محدودیت قیمت'
                    : `تا ${formatPriceToman(maxPrice)}`}
                </span>
              </div>
              <input
                id="filter-price"
                type="range"
                min={250000}
                max={10000000}
                step={250000}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#0057FF] cursor-pointer"
              />
            </div>
          </div>
        ) : null}
      </div>

      {/* ۲. نوار افقی و مینیمال دسته‌بندی خدمات (با آیکون و نوشته و اسکرول افقی، بالای کارت‌ها و پروفایل‌ها) */}
      <div className="flex items-center gap-2 overflow-x-auto py-1 no-scrollbar">
        <button
          type="button"
          onClick={() => {
            setCategoryFilter('ALL');
            setTypeFilter('ALL');
          }}
          className={`px-3.5 py-2 rounded-2xl text-xs font-extrabold whitespace-nowrap cursor-pointer transition-all inline-flex items-center gap-1.5 border shrink-0 ${
            categoryFilter === 'ALL'
              ? 'bg-[#0057FF] text-white border-[#0057FF] shadow-2xs'
              : 'bg-white border-[#CBD5E1] text-[#334155] hover:border-[#0057FF]'
          }`}
        >
          <Sparkles
            className={`w-3.5 h-3.5 ${
              categoryFilter === 'ALL' ? 'text-white' : 'text-[#0057FF]'
            }`}
          />
          <span>همه خدمات</span>
        </button>

        {categories.map((cat) => {
          const isSelected = categoryFilter === cat.slug;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoryFilter(cat.slug)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-extrabold whitespace-nowrap cursor-pointer transition-all inline-flex items-center gap-1.5 border shrink-0 ${
                isSelected
                  ? 'bg-[#0057FF] text-white border-[#0057FF] shadow-2xs'
                  : 'bg-white border-[#CBD5E1] text-[#334155] hover:border-[#0057FF]'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-white/95 flex items-center justify-center shrink-0">
                {CATEGORY_ICON_MAP[cat.iconName] ?? (
                  <Sparkles className="w-3 h-3 text-[#0057FF]" />
                )}
              </span>
              <span>{cat.title}</span>
            </button>
          );
        })}
      </div>

      {/* ۳. نمایش تعداد مراکز فعال (سمت راست) و آیکون کوچک مرتب‌سازی (سمت چپ) + لیست کارت‌ها */}
      <div className="space-y-4">
        <div className="flex items-center justify-between gap-2 px-1 text-xs text-[#64748B]">
          <div className="flex items-center gap-2">
            <span>
              نمایش{' '}
              <strong className="font-extrabold text-[#061138] tabular-nums">
                {toPersianDigits(finalFiltered.length)}
              </strong>{' '}
              مرکز فعال
            </span>
            {hasActiveFilters ? (
              <button
                type="button"
                onClick={handleResetFilters}
                className="font-extrabold text-[#0057FF] hover:underline cursor-pointer"
              >
                پاک کردن فیلترها ✕
              </button>
            ) : null}
          </div>

          {/* آیکون کوچک و انتخابگر مینیمال مرتب‌سازی در سمت چپ */}
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white border border-[#CBD5E1] text-[#061138] shadow-2xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-[#0057FF] shrink-0" />
            <select
              id="sort-select"
              aria-label="مرتب‌سازی نتایج"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="bg-transparent text-[11px] sm:text-xs font-extrabold text-[#061138] focus:outline-none cursor-pointer"
            >
              <option value="recommended">پیشنهادی</option>
              <option value="rating_desc">محبوب‌ترین</option>
              <option value="price_asc">مناسب‌ترین قیمت</option>
            </select>
          </div>
        </div>

        {matchedSpecialistsInSearch.length > 0 ? (
          <div className="space-y-3">
            <h3 className="text-sm font-extrabold text-[#1E1B2E]">
              متخصصان مرتبط با جست‌وجوی شما (
              {toPersianDigits(matchedSpecialistsInSearch.length)})
            </h3>
            <div className="flex overflow-x-auto snap-x snap-mandatory gap-3.5 pb-2 -mx-4 px-4 sm:mx-0 sm:px-0 sm:grid sm:grid-cols-3 lg:grid-cols-4 no-scrollbar">
              {matchedSpecialistsInSearch.map((sp) => (
                <div
                  key={sp.id}
                  className="w-[215px] sm:w-auto shrink-0 snap-start"
                >
                  <ProfessionalCard
                    specialist={sp}
                    isFavorite={favoriteSpecialistIds.includes(sp.id)}
                    onToggleFavorite={toggleFavoriteSpecialist}
                  />
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {finalFiltered.length === 0 ? (
          <EmptyState
            title="مرکزی مطابق با فیلترهای انتخابی شما یافت نشد"
            description="پیشنهاد می‌کنیم روی «همه خدمات» کلیک کنید تا تمام مراکز فعال نمایش داده شوند."
            actionLabel="نمایش همه مراکز"
            onAction={handleResetFilters}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {finalFiltered.map((biz) => (
              <BusinessCard
                key={biz.id}
                business={biz}
                compact
                isFavorite={favoriteBusinessIds.includes(biz.id)}
                onToggleFavorite={toggleFavoriteBusiness}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

/** ۳. صفحه دسته‌بندی خدمات (/categories) — طراحی جمع‌وجور ۲ ستونه در موبایل */
export const CategoriesPage: React.FC = () => {
  const { categories } = usePrototypeData();

  return (
    <div className="space-y-5 sm:space-y-7">
      <PageHeader
        kicker="طبقه‌بندی خدمات زیبایی"
        title="دسته‌بندی‌های خدمات زیبایی، عروس، داماد و پیرایش"
        subtitle="لاین خدمتی مورد نظر خود را انتخاب کنید تا سالن‌ها و متخصصان فعال آن حوزه را ببینید."
        breadcrumbs={[
          { label: 'صفحه اصلی', href: '/' },
          { label: 'دسته‌بندی خدمات' },
        ]}
      />

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
        {categories.map((category) => {
          const catImg = getBeautyPhotoUrl(category.title, category.subtitle);
          return (
            <Link
              key={category.id}
              to={`/search?category=${category.slug}`}
              className="group rounded-2xl sm:rounded-3xl bg-white border border-[#CBD5E1] hover:border-[#0057FF] shadow-2xs hover:shadow-md overflow-hidden flex flex-col justify-between transition-all"
            >
              {/* تصویر تمیز بدون شلوغی نوشته روی عکس */}
              <div className="relative h-24 sm:h-32 overflow-hidden bg-[#E0ECFF]">
                <img
                  src={catImg}
                  alt={category.title}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-white/95 backdrop-blur-xs text-[10px] font-extrabold text-[#0057FF] tabular-nums shadow-2xs">
                  {toPersianDigits(category.serviceCount)} خدمت
                </span>
              </div>

              {/* عنوان و آیکون خوانا روی پس‌زمینه سفید پایین کارت */}
              <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between gap-2 bg-white">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-6 h-6 rounded-full bg-[#EFF6FF] border border-[#CBD5E1] text-[#0057FF] flex items-center justify-center shrink-0">
                      {CATEGORY_ICON_MAP[category.iconName] ?? (
                        <Sparkles className="w-3.5 h-3.5 text-[#0057FF]" />
                      )}
                    </span>
                    <h2 className="text-xs sm:text-sm font-black text-[#061138] group-hover:text-[#0057FF] transition-colors leading-snug">
                      {category.title}
                    </h2>
                  </div>
                  <p className="hidden sm:block text-xs text-[#475569] line-clamp-2 leading-relaxed">
                    {category.subtitle}
                  </p>
                </div>

                <div className="pt-1.5 border-t border-[#F1F5F9] flex items-center justify-between text-[11px] font-extrabold text-[#0057FF]">
                  <span>مشاهده سالن‌ها</span>
                  <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-0.5" />
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

/** ۴. صفحه شرایط همکاری ویژه سالن‌داران (/pricing) */
export const PricingPage: React.FC = () => {
  const commissionTiers = [
    {
      id: 'tier-men',
      title: 'آرایشگاه و پیرایش آقایان',
      percent: 3,
      badge: '۳٪ از کل مبلغ خدمت',
      description:
        'مناسب آرایشگاه‌های مردانه، استایل مو و گریم داماد با ثبت نامحدود آرایشگر و تقویم نوبت‌دهی اختصاصی.',
      features: [
        'پنل مدیریت، تقویم نوبت‌دهی و حسابداری دخل روزانه ۱۰۰٪ رایگان همیشگی',
        'دریافت بیعانه آنلاین الزامی (۲۰٪، ۳۰٪، ۵۰٪ یا ۱۰۰٪) جهت تضمین حضور مشتری',
        'کسر تنها ۳٪ کارمزد از کل مبلغ خدمت از محل بیعانه دریافتی',
        'تسویه منظم در سیکل هفتگی شبا (پایا — شنبه‌ها) پس از انجام نوبت',
      ],
    },
    {
      id: 'tier-laser',
      title: 'مراکز لیزر موهای زائد',
      percent: 4,
      badge: '۴٪ از کل مبلغ خدمت',
      isRecommended: true,
      description:
        'ویژه مراکز تخصصی لیزر بانوان و آقایان با کیت‌های آماده نواحی بدن و پکیج‌های فول‌بادی.',
      features: [
        'پنل مدیریت، پرونده جلسات لیزر و حسابداری ۱۰۰٪ رایگان همیشگی',
        'کیت‌های آماده خدمات لیزر بر اساس مدل دستگاه و نواحی کاربردی',
        'کسر تنها ۴٪ کارمزد از کل مبلغ خدمت از محل بیعانه آنلاین',
        'تسویه منظم در سیکل هفتگی شبا (پایا — شنبه‌ها) پس از انجام نوبت',
      ],
    },
    {
      id: 'tier-women',
      title: 'سالن‌های زیبایی و متخصصان بانوان',
      percent: 5,
      badge: '۵٪ از کل مبلغ خدمت',
      description:
        'ویژه سالن‌های زیبایی بانوان، رنگ و لایت، ناخن، مژه، فیشیال و میکاپ عروس با پرسنل نامحدود.',
      features: [
        'تقویم چندمتخصصه، گالری نمونه‌کار و حسابداری دوحالته ۱۰۰٪ رایگان همیشگی',
        'پیامک دوطرفه خودکار ثبت نوبت برای مشتری و مدیر سالن',
        'کسر تنها ۵٪ کارمزد از کل مبلغ خدمت از محل بیعانه آنلاین',
        'تسویه منظم در سیکل هفتگی شبا (پایا — شنبه‌ها) پس از انجام نوبت',
      ],
    },
  ];

  return (
    <div className="space-y-10">
      <PageHeader
        kicker="ویژه مدیران سالن، مراکز لیزر و متخصصان زیبایی"
        title="پنل مدیریت ۱۰۰٪ رایگان همیشگی — بدون حق اشتراک ماهانه"
        subtitle="در تایم تو هیچ هزینه اشتراک ماهانه‌ای پرداخت نمی‌کنید! تمامی امکانات نرم‌افزاری پنل (تقویم نوبت‌دهی، حسابداری دخل روزانه، پرسنل نامحدود و پرونده مشتریان) کاملاً رایگان است و تنها زمانی که ما برای شما مشتری بیاوریم، درصد کارمزد توافقی از محل بیعانه کسر می‌شود."
        breadcrumbs={[
          { label: 'صفحه اصلی', href: '/' },
          { label: 'شرایط همکاری سالن‌داران' },
        ]}
      />

      {/* بخش ارزش همکاری بدون ریسک برای سالن‌دار */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-white border border-[#CBD5E1] shadow-2xs space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#ECFDF5] text-[#059669] text-xs font-extrabold">
            <CalendarCheck className="w-4 h-4" />
            <span>صفر تومان هزینه ثابت ماهانه</span>
          </div>
          <h2 className="text-sm sm:text-base font-extrabold text-[#061138]">
            همه امکانات پنل از روز اول باز و رایگان است
          </h2>
          <p className="text-xs text-[#334155] leading-relaxed">
            برخلاف نرم‌افزارهای اشتراکی، نیازی به خرید پلن ماهانه ندارید؛ تقویم نامحدود پرسنل، حسابداری دخل روزانه و پرونده مشتریان برای همیشه رایگان است.
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-[#CBD5E1] shadow-2xs space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E0ECFF] text-[#0057FF] text-xs font-extrabold">
            <TrendingUp className="w-4 h-4" />
            <span>تضمین حضور مشتری با بیعانه آنلاین</span>
          </div>
          <h2 className="text-sm sm:text-base font-extrabold text-[#061138]">
            بیعانه استاندارد ۲۰٪، ۳۰٪، ۵۰٪ یا ۱۰۰٪
          </h2>
          <p className="text-xs text-[#334155] leading-relaxed">
            مشتری هنگام رزرو نوبت، بیعانه انتخابی شما را آنلاین پرداخت می‌کند تا وقت سالن شما هرگز با کنسلی‌های لحظه آخری نسوزد.
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-white border border-[#CBD5E1] shadow-2xs space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FEF3C7] text-[#D97706] text-xs font-extrabold">
            <ShieldCheck className="w-4 h-4" />
            <span>تسویه منظم هفتگی شبا (پایا)</span>
          </div>
          <h2 className="text-sm sm:text-base font-extrabold text-[#061138]">
            واریز خالص بیعانه‌ها در سیکل هفتگی شنبه‌ها
          </h2>
          <p className="text-xs text-[#334155] leading-relaxed">
            پس از انجام نوبت مشتری، خالص بیعانه‌های جمع‌شده در کیف پول شما در سیکل هفتگی پایا (شنبه‌ها) مستقیماً به شماره شبای ثبت‌شده شما واریز می‌گردد.
          </p>
        </div>
      </div>

      {/* کارت‌های نرخ کمیسیون ۳ دسته کسب‌وکار به جای پلن‌های ماهانه */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
        {commissionTiers.map((tier) => (
          <Card
            key={tier.id}
            className={`rounded-3xl flex flex-col justify-between space-y-6 ${
              tier.isRecommended
                ? 'border-[#0057FF] ring-2 ring-[#0057FF]/15'
                : ''
            }`}
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-lg font-extrabold text-[#061138]">
                  {tier.title}
                </h2>
                <span className="px-3 py-1 rounded-full bg-[#E0ECFF] text-xs font-black text-[#0057FF] shrink-0">
                  {tier.badge}
                </span>
              </div>
              <p className="text-xs text-[#475569] leading-relaxed">
                {tier.description}
              </p>

              <div className="pt-2 pb-4 border-b border-[#E2E8F0]">
                <span className="text-2xl sm:text-3xl font-extrabold text-[#059669] tabular-nums">
                  پنل رایگان
                </span>
                <span className="text-xs font-bold text-[#64748B] mr-1.5">
                  + {toPersianDigits(tier.percent)}٪ کارمزد از رزرو موفق
                </span>
              </div>

              <ul className="space-y-2.5 pt-2">
                {tier.features.map((feat, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2 text-xs text-[#061138]"
                  >
                    <Check className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Link to="/business/register">
              <Button
                variant={tier.isRecommended ? 'primary' : 'outline'}
                fullWidth
              >
                ثبت رایگان {tier.title}
              </Button>
            </Link>
          </Card>
        ))}
      </div>

      {/* بخش جایگاه‌های تبلیغاتی و ارتقای جایگاه سالن‌ها */}
      <div className="rounded-3xl bg-[#061138] text-white p-6 sm:p-8 space-y-5 border border-[#1E293B]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-1">
            <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#00E5FF]">
              <Sparkles className="w-4 h-4" />
              <span>خدمات تبلیغاتی اختیاری (صدرنشینی در جست‌وجو، بنر صفحه اول و بسته پیامک)</span>
            </span>
            <h2 className="text-lg sm:text-xl font-extrabold text-white">
              چگونه سالن خود را بالاتر از همه رقبا در صفحه اول و صدر جست‌وجوی اصفهان نمایش دهید؟
            </h2>
          </div>
          <Link to="/app/marketing">
            <Button variant="accent" size="sm">
              <span>ورود به پنل تبلیغات سالن ←</span>
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2">
            <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#00E5FF]/20 text-[#00E5FF] font-extrabold">
              ★ صدرنشینی در جست‌وجو
            </span>
            <h3 className="text-sm font-extrabold text-white">
              پین در ردیف اول نتایج جست‌وجو (/search)
            </h3>
            <p className="text-slate-200 leading-relaxed">
              نمایش تضمینی سالن شما در بالای فهرست جست‌وجوی خدمات و محله‌ها به همراه نشان «★ آگهی ویژه».
            </p>
            <p className="font-extrabold text-[#00E5FF] pt-1 tabular-nums">
              ۴۹۰,۰۰۰ تومان / ماهانه (یا ۱۹۰,۰۰۰ هفتگی)
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2">
            <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#00E5FF]/20 text-[#00E5FF] font-extrabold">
              ویترین صفحه اول
            </span>
            <h3 className="text-sm font-extrabold text-white">
              بنر اختصاصی در صفحه اول تایم تو
            </h3>
            <p className="text-slate-200 leading-relaxed">
              قرارگیری بنر تصویری بزرگ سالن شما در بخش «پیشنهادهای ویژه رزرو آنلاین» صفحه اصلی با ۳.۵ برابر بازدید بیشتر.
            </p>
            <p className="font-extrabold text-[#00E5FF] pt-1 tabular-nums">
              ۸۹۰,۰۰۰ تومان / ماهانه (یا ۳۵۰,۰۰۰ هفتگی)
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2">
            <span className="inline-block px-2.5 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 font-extrabold">
              بسته افزونه پیامک
            </span>
            <h3 className="text-sm font-extrabold text-white">
              بسته ۲۰۰ پیامک خدماتی و یادآور اضافه
            </h3>
            <p className="text-slate-200 leading-relaxed">
              شارژ فوری اعتبار پیامک سالن در هر زمان که سهمیه ماهانه پلن شما به پایان رسید.
            </p>
            <p className="font-extrabold text-emerald-300 pt-1 tabular-nums">
              ۱۸۰,۰۰۰ تومان / بسته ۲۰۰ عددی
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

/** ۵. صفحه درباره ما (/about) */
export const AboutPage: React.FC = () => {
  return (
    <div className="space-y-10">
      <PageHeader
        kicker="معرفی پلتفرم"
        title="درباره Timeto (تایم تو)"
        subtitle="پلتفرم تخصصی رزرو آنلاین خدمات زیبایی و مدیریت یکپارچه سالن‌ها، آرایشگاه‌ها و متخصصان در ایران"
        breadcrumbs={[{ label: 'صفحه اصلی', href: '/' }, { label: 'درباره ما' }]}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <Card className="lg:col-span-7 rounded-3xl space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <p className="text-xs font-bold text-[#0057FF]">
              ماموریت Timeto (تایم تو)
            </p>
            <h2 className="text-lg sm:text-xl font-extrabold text-[#061138]">
              ساده‌سازی رزرو نوبت برای مراجعان و نظم‌بخشی به تقویم سالن‌ها
            </h2>
            <p className="text-xs sm:text-sm text-[#334155] leading-relaxed">
              پیدا کردن یک سالن زیبایی، آرایشگاه مردانه یا متخصص پوست مطمئن با
              تعرفه‌های شفاف و زمان‌های آزاد واقعی، نباید نیازمند تماس‌های مکرر
              تلفنی باشد. Timeto به مراجعان کمک می‌کند در هر ساعت از شبانه‌روز
              نوبت خود را رزرو کنند و به صاحبان سالن‌ها ابزارهای حرفه‌ای برای
              مدیریت تقویم، بیعانه و پرونده مشتریان می‌دهد.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-4 border-t border-[#E6E0F5] text-xs">
            <div>
              <p className="text-base font-extrabold text-[#8B5CF6]">تقویم شمسی</p>
              <p className="text-[#6B6480]">محاسبه دقیق ساعات کاری</p>
            </div>
            <div>
              <p className="text-base font-extrabold text-[#8B5CF6]">تعرفه شفاف</p>
              <p className="text-[#6B6480]">نمایش قیمت و زمان هر خدمت</p>
            </div>
            <div>
              <p className="text-base font-extrabold text-[#8B5CF6]">یادآور پیامکی</p>
              <p className="text-[#6B6480]">کاهش عدم حضور در نوبت‌ها</p>
            </div>
          </div>
        </Card>

        <div className="lg:col-span-5">
          <VisualMediaIllustration
            theme="rose"
            composition="mirror"
            categoryLabel="تجربه مدرن رزرو"
            title="طراحی‌شده برای صنعت زیبایی ایران"
            subtitle="ترکیب ویترین آنلاین سالن و تقویم هوشمند"
            city="سراسر ایران"
            className="h-full min-h-[240px]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="rounded-3xl space-y-2.5">
          <h3 className="text-base font-extrabold text-[#1E1B2E]">
            برای مشتریان و مراجعان
          </h3>
          <p className="text-xs text-[#6B6480] leading-relaxed">
            مشاهده فهرست کامل خدمات، تعرفه به تومان، نمونه‌کارها و ثبت نوبت
            آنلاین با دریافت کد رهگیری.
          </p>
        </Card>

        <Card className="rounded-3xl space-y-2.5">
          <h3 className="text-base font-extrabold text-[#1E1B2E]">
            برای سالن‌های زیبایی
          </h3>
          <p className="text-xs text-[#6B6480] leading-relaxed">
            مدیریت تقویم چندین متخصص، تعریف ساعات کاری و استثنائات، و ثبت
            پرونده مراجعان در یک محیط ساده.
          </p>
        </Card>

        <Card className="rounded-3xl space-y-2.5">
          <h3 className="text-base font-extrabold text-[#1E1B2E]">
            برای متخصصان مستقل
          </h3>
          <p className="text-xs text-[#6B6480] leading-relaxed">
            صفحه پروفایل اختصاصی برای معرفی تخصص‌ها، نمایش نمونه‌کارها و پذیرش
            مستقیم نوبت از مراجعان.
          </p>
        </Card>
      </div>

      {/* نماد اعتماد الکترونیکی (اینماد) — فقط در صفحه درباره ما */}
      <Card className="rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-6 border border-[#E2E8F0] bg-white">
        <div className="space-y-1.5 text-center sm:text-right">
          <p className="text-xs font-extrabold text-[#0057FF]">
            مجوز رسمی و نماد اعتماد الکترونیکی
          </p>
          <h3 className="text-base font-extrabold text-[#061138]">
            دارای نماد اعتماد الکترونیکی (اینماد) از مرکز توسعه تجارت الکترونیکی
          </h3>
          <p className="text-xs text-[#64748B] leading-relaxed max-w-xl">
            جهت استعلام اصالت و مشاهده شناسنامه نماد اعتماد الکترونیکی پلتفرم تایم تو (timeto24.ir)، روی لوگوی اینماد کلیک فرمایید.
          </p>
        </div>

        <div
          className="shrink-0 rounded-2xl border border-[#E2E8F0] bg-[#F8FAFC] p-3 flex items-center justify-center min-w-[110px] min-h-[110px]"
          dangerouslySetInnerHTML={{
            __html: `<a referrerpolicy='origin' target='_blank' href='https://trustseal.enamad.ir/?id=8562558&Code=FIEVb8zLbqQlmNhZBm2EBXcZrZw4NCcp'><img referrerpolicy='origin' src='https://trustseal.enamad.ir/logo.aspx?id=8562558&Code=FIEVb8zLbqQlmNhZBm2EBXcZrZw4NCcp' alt='' style='cursor:pointer' code='FIEVb8zLbqQlmNhZBm2EBXcZrZw4NCcp'></a>`,
          }}
        />
      </Card>
    </div>
  );
};

/** ۶. صفحه راهنما و پشتیبانی (/help) */
export const HelpPage: React.FC = () => {
  const {
    authUser,
    currentBusiness,
    ownedBusinessId,
    supportTickets,
    submitSupportTicket,
  } = usePrototypeData();
  const [senderRole, setSenderRole] = useState<'CUSTOMER' | 'BUSINESS_OWNER'>(
    ownedBusinessId || authUser?.roles?.includes('BUSINESS_OWNER')
      ? 'BUSINESS_OWNER'
      : 'CUSTOMER'
  );
  const [senderName, setSenderName] = useState(
    authUser?.fullName || currentBusiness?.ownerName || ''
  );
  const [senderPhone, setSenderPhone] = useState(
    authUser?.phone || currentBusiness?.ownerPhone || ''
  );
  const [businessNameInput, setBusinessNameInput] = useState(
    currentBusiness?.name || ''
  );
  const [ticketTitle, setTicketTitle] = useState('');
  const [ticketCategory, setTicketCategory] = useState('پیگیری نوبت و رزرو مشتری');
  const [ticketMessage, setTicketMessage] = useState('');
  const [formError, setFormError] = useState('');

  const faqs = [
    {
      q: 'چگونه نوبت خود را در سالن یا نزد متخصص رزرو کنم؟',
      a: 'در صفحه جست‌وجو مرکز مورد نظر را انتخاب کنید، وارد پروفایل شوید و با کلیک روی «رزرو نوبت»، خدمت، متخصص، تاریخ و ساعت مراجعه را انتخاب نمایید.',
    },
    {
      q: 'قوانین پرداخت بیعانه و لغو نوبت به چه صورت است؟',
      a: 'در صورت فعال بودن بیعانه برای سالن، مبلغ بیعانه پیش از نهایی‌سازی نوبت به صورت شفاف نمایش داده می‌شود و مهلت لغو مجاز نیز در صفحه تایید درج می‌گردد.',
    },
    {
      q: 'چطور سالن زیبایی یا آرایشگاه خود را ثبت کنم؟',
      a: 'از طریق دکمه «ثبت سالن زیبایی» در بالای سایت، مشخصات سالن، خدمات، متخصصان و ساعات کاری خود را ثبت کنید تا صفحه اختصاصی شما پس از تایید منتشر شود.',
    },
  ];

  const handleSupportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderPhone.trim() || !/^09\d{9}$/.test(senderPhone.trim())) {
      setFormError('لطفاً شماره موبایل ۱۱ رقمی خود را جهت دریافت پاسخ وارد کنید.');
      return;
    }
    if (!ticketTitle.trim() || !ticketMessage.trim()) {
      setFormError('لطفاً موضوع و شرح پیام خود را کامل وارد کنید.');
      return;
    }
    setFormError('');
    submitSupportTicket({
      senderRole,
      senderName: senderName.trim() || 'کاربر تایم تو',
      senderPhone: senderPhone.trim(),
      businessName:
        senderRole === 'BUSINESS_OWNER'
          ? businessNameInput.trim() || currentBusiness?.name || 'کسب‌وکار عضو'
          : undefined,
      categoryLabel: ticketCategory,
      subject: ticketTitle.trim(),
      message: ticketMessage.trim(),
    });
    setTicketTitle('');
    setTicketMessage('');
  };

  return (
    <div className="space-y-8">
      <PageHeader
        kicker="پشتیبانی مستقیم و راهنمای کاربری"
        title="مرکز پشتیبانی، ثبت تیکت و پرسش‌های متداول"
        subtitle="ارتباط مستقیم با مدیریت پلتفرم Timeto، ثبت تیکت برای مشتریان و صاحبان سالن‌ها و دریافت پاسخ مستقیم"
        breadcrumbs={[{ label: 'صفحه اصلی', href: '/' }, { label: 'پشتیبانی و راهنما' }]}
      />

      {/* نوار ارتباط مستقیم تلفنی و اینستاگرام */}
      <div className="rounded-3xl bg-[#061138] text-white p-5 sm:p-6 border border-[#1E293B] flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <span className="text-xs font-extrabold text-[#00E5FF]">
            پشتیبانی تلفنی و صفحه رسمی اینستاگرام Timeto
          </span>
          <h2 className="text-base sm:text-lg font-extrabold text-white">
            نیاز به راهنمایی فوری برای ثبت سالن، ارتقای پلن یا پیگیری نوبت دارید؟
          </h2>
          <p className="text-xs text-slate-300">
            می‌توانید مستقیم با شماره پشتیبانی تماس بگیرید یا در تیکت زیر پیام بگذارید تا پاسخ مدیر را همین‌جا مشاهده کنید.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <a
            href="tel:09138201042"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-[#0057FF] hover:bg-[#0046CC] text-white text-xs sm:text-sm font-extrabold transition-colors"
          >
            <span>تماس با پشتیبانی:</span>
            <span dir="ltr" className="font-mono text-[#00E5FF]">
              09138201042
            </span>
          </a>
          <a
            href="https://www.instagram.com/timeto24_app?srtk=bTUwbmx6NTRnMThk"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#E1306C] to-[#833AB4] text-white text-xs sm:text-sm font-extrabold hover:opacity-95 transition-opacity"
          >
            <span>پیج اینستاگرام:</span>
            <span dir="ltr" className="font-mono">
              @timeto24_app
            </span>
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-6">
          <div className="space-y-4">
            <h2 className="text-base font-extrabold text-[#1E1B2E]">
              پرسش‌های پرتکرار
            </h2>
            {faqs.map((item, index) => (
              <Card key={index} className="rounded-3xl space-y-2">
                <h3 className="text-sm font-extrabold text-[#1E1B2E]">{item.q}</h3>
                <p className="text-xs sm:text-sm text-[#6B6480] leading-relaxed">
                  {item.a}
                </p>
              </Card>
            ))}
          </div>

          {/* نمایش تیکت‌های ثبت‌شده کاربر فعلی و پاسخ پشتیبانی */}
          {(() => {
            const isPlatformAdmin = Boolean(
              authUser?.isPlatformAdmin &&
                authUser?.roles?.includes('PLATFORM_ADMIN')
            );
            const activeUserPhone = (
              authUser?.phone ||
              senderPhone ||
              ''
            ).trim();
            const myTickets = isPlatformAdmin
              ? supportTickets
              : activeUserPhone
                ? supportTickets.filter(
                    (tck) => tck.senderPhone === activeUserPhone
                  )
                : [];

            if (myTickets.length === 0) return null;

            return (
              <div className="space-y-3 pt-2">
                <h2 className="text-base font-extrabold text-[#061138]">
                  پیگیری تیکت‌های ارسالی شما و پاسخ پشتیبانی (
                  {toPersianDigits(myTickets.length)} مورد)
                </h2>
                {myTickets.map((tck) => (
                  <Card
                    key={tck.id}
                    className="space-y-3 border-2 border-[#E2E8F0]"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E2E8F0] pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-extrabold text-[#0057FF]">
                          {tck.id}
                        </span>
                        <span className="text-xs font-extrabold text-[#061138]">
                          {tck.subject}
                        </span>
                      </div>
                      <StatusBadge
                        label={
                          tck.status === 'ANSWERED'
                            ? 'پاسخ داده شده توسط پشتیبانی'
                            : tck.status === 'CLOSED'
                              ? 'بسته شده'
                              : 'در انتظار پاسخ پشتیبانی'
                        }
                        tone={tck.status === 'ANSWERED' ? 'success' : 'warning'}
                      />
                    </div>
                    <p className="text-xs text-[#334155] leading-relaxed">
                      {tck.message}
                    </p>
                    {tck.adminReply ? (
                      <div className="p-3.5 rounded-2xl bg-[#ECFDF5] border border-[#10B981]/40 space-y-1 text-xs">
                        <p className="font-extrabold text-[#047857]">
                          پاسخ پشتیبانی تایم تو ({tck.repliedAtJalali || 'امروز'}):
                        </p>
                        <p className="text-[#065F46] leading-relaxed font-medium">
                          {tck.adminReply}
                        </p>
                      </div>
                    ) : null}
                  </Card>
                ))}
              </div>
            );
          })()}
        </div>

        <div className="lg:col-span-5">
          <Card className="rounded-3xl space-y-4 border-2 border-[#0057FF]/25">
            <div className="space-y-1 border-b border-[#E6E0F5] pb-3">
              <h2 className="text-base font-extrabold text-[#1E1B2E]">
                ثبت تیکت و پیام مستقیم به پشتیبانی
              </h2>
              <p className="text-xs text-[#6B648B]">
                مشخص کنید مشتری هستید یا صاحب کسب‌وکار؛ پاسخ پشتیبانی در همین صفحه برای شما نمایش داده می‌شود.
              </p>
            </div>

            <form
              onSubmit={handleSupportSubmit}
              className="space-y-3.5"
              noValidate
            >
              <div className="space-y-1.5">
                <label className="block text-xs font-extrabold text-[#061138]">
                  ارسال‌کننده پیام:
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-[#F3F6FC] border border-[#CBD5E1]">
                  <button
                    type="button"
                    onClick={() => setSenderRole('CUSTOMER')}
                    className={`py-2 px-3 rounded-xl text-xs font-extrabold cursor-pointer transition-colors ${
                      senderRole === 'CUSTOMER'
                        ? 'bg-[#0057FF] text-white'
                        : 'text-[#334155] hover:text-[#061138]'
                    }`}
                  >
                    مشتری / مراجعه‌کننده
                  </button>
                  <button
                    type="button"
                    onClick={() => setSenderRole('BUSINESS_OWNER')}
                    className={`py-2 px-3 rounded-xl text-xs font-extrabold cursor-pointer transition-colors ${
                      senderRole === 'BUSINESS_OWNER'
                        ? 'bg-[#0057FF] text-white'
                        : 'text-[#334155] hover:text-[#061138]'
                    }`}
                  >
                    صاحب کسب‌وکار / سالن
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <FormField id="help-sender-name" label="نام و نام خانوادگی" required>
                  <Input
                    id="help-sender-name"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    placeholder="نام شما..."
                  />
                </FormField>
                <FormField id="help-sender-phone" label="شماره موبایل (۱۱ رقمی)" required>
                  <Input
                    id="help-sender-phone"
                    dir="ltr"
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    placeholder="09131234567"
                  />
                </FormField>
              </div>

              {senderRole === 'BUSINESS_OWNER' ? (
                <FormField id="help-biz-name" label="نام سالن یا کسب‌وکار شما" required>
                  <Input
                    id="help-biz-name"
                    value={businessNameInput}
                    onChange={(e) => setBusinessNameInput(e.target.value)}
                    placeholder="مثلاً سالن زیبایی ارکیده"
                  />
                </FormField>
              ) : null}

              <FormField id="help-cat" label="دسته موضوعی تیکت">
                <Select
                  id="help-cat"
                  value={ticketCategory}
                  onChange={(e) => setTicketCategory(e.target.value)}
                  options={[
                    { value: 'پیگیری نوبت و رزرو مشتری', label: 'پیگیری نوبت و رزرو مشتری' },
                    { value: 'راه‌اندازی و تایید پنل کسب‌وکار', label: 'راه‌اندازی و تایید پنل کسب‌وکار' },
                    { value: 'پلن‌های اشتراک، تبلیغات و مالی', label: 'پلن‌های اشتراک، تبلیغات و مالی' },
                    { value: 'سایر موارد و پیشنهادات', label: 'سایر موارد و پیشنهادات' },
                  ]}
                />
              </FormField>

              <FormField
                id="help-title"
                label="عنوان تیکت / سوال"
                required
                error={formError}
              >
                <Input
                  id="help-title"
                  value={ticketTitle}
                  hasError={Boolean(formError)}
                  onChange={(e) => setTicketTitle(e.target.value)}
                  placeholder="مثلاً درخواست بررسی و تایید سالن یا سوال درباره پلن..."
                />
              </FormField>

              <FormField id="help-msg" label="شرح کامل پیام" required>
                <Textarea
                  id="help-msg"
                  rows={4}
                  value={ticketMessage}
                  hasError={Boolean(formError)}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  placeholder="جزئیات سوال یا درخواست خود را بنویسید..."
                />
              </FormField>

              <Button type="submit" variant="primary" fullWidth>
                ارسال تیکت به پشتیبانی تایم تو
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
};
