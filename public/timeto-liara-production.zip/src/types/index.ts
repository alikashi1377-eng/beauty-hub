export enum BusinessType {
  WomenSalon = 'WOMEN_SALON',
  MenBarbershop = 'MEN_BARBERSHOP',
  IndependentSpecialist = 'INDEPENDENT_SPECIALIST',
}

export enum AppointmentStatus {
  Confirmed = 'CONFIRMED',
  Pending = 'PENDING',
  Completed = 'COMPLETED',
  Cancelled = 'CANCELLED',
  NoShow = 'NO_SHOW',
}

export enum SubscriptionStatus {
  Active = 'ACTIVE',
  Trial = 'TRIAL',
  ExpiringSoon = 'EXPIRING_SOON',
  Expired = 'EXPIRED',
}

export type ApprovalStatus = 'APPROVED' | 'PENDING_REVIEW' | 'REJECTED';

export type UIStateMode =
  | 'normal'
  | 'loading'
  | 'empty'
  | 'error'
  | 'success'
  | 'incomplete_form';

export type RouteEnvironment =
  | 'public'
  | 'business_public'
  | 'business_onboarding'
  | 'business_panel'
  | 'customer'
  | 'admin';

export interface RouteItem {
  path: string;
  samplePath: string;
  title: string;
  environment: RouteEnvironment;
  description: string;
}

export interface ServiceItem {
  id: string;
  businessId: string;
  categorySlug: string;
  title: string;
  category: string;
  durationMinutes: number;
  priceToman: number;
  pricingType?: 'FIXED' | 'RANGE' | 'STARTING_FROM';
  maxPriceToman?: number;
  packageIncludes?: string[];
  description: string;
  isPopular?: boolean;
  isActive?: boolean;
  sortOrder?: number;
}

export interface SpecialistItem {
  id: string;
  businessId: string;
  slug: string;
  fullName: string;
  roleTitle: string;
  experienceYears: number;
  rating: number;
  reviewCount: number;
  specialties: string[];
  bio: string;
  isIndependent: boolean;
  isActive?: boolean;
  city?: string;
  startingPriceToman?: number;
  avatarUrl?: string;
}

export interface WorkingHourItem {
  dayName: string;
  isOpen: boolean;
  openTime: string;
  closeTime: string;
  hasBreak?: boolean;
  secondOpenTime?: string;
  secondCloseTime?: string;
}

export interface ReviewItem {
  id: string;
  businessId: string;
  specialistSlug?: string;
  authorName: string;
  authorPhone?: string;
  serviceTitle: string;
  rating: number;
  dateJalali: string;
  comment: string;
  salonReply?: string;
  salonReplyDateJalali?: string;
  isReportedBySalon?: boolean;
  reportReason?: string;
}

export interface GalleryItem {
  id: string;
  businessId: string;
  title: string;
  categoryLabel: string;
  theme: 'rose' | 'slate' | 'emerald' | 'violet';
  imageUrl?: string;
  compressedSizeKb?: number;
}

export interface BusinessItem {
  id: string;
  slug: string;
  name: string;
  type: BusinessType;
  typeLabel: string;
  categorySlug: string;
  city: string;
  neighborhood: string;
  address: string;
  phoneDisplay: string;
  rating: number;
  reviewCount: number;
  startingPriceToman: number;
  shortDescription: string;
  aboutText: string;
  verifiedBadge: boolean;
  approvalStatus: ApprovalStatus;
  subscriptionPlan: string;
  subscriptionStatus: SubscriptionStatus;
  workingHours: WorkingHourItem[];
  visualTheme: 'rose' | 'slate' | 'emerald' | 'violet';
  featured?: boolean;
  isSponsored?: boolean;
  sponsoredLabel?: string;
  sponsoredPlacement?: SponsoredPlacementSlot;
  sponsoredOrder?: number;
  sponsoredDaysRemaining?: number;
  sponsoredExpiresJalali?: string;
  sponsoredExpiresAtMs?: number;
  sponsoredCategorySlug?: string;
  sponsoredNeighborhood?: string;
  sponsoredImpressions?: number;
  sponsoredClicks?: number;
  trialDaysRemaining?: number;
  planExpiresAtMs?: number;
  extraSmsBalance?: number;
  smsSentCount?: number;
  instagramHandle?: string;
  mapLat?: number;
  mapLng?: number;
  avatarUrl?: string;
  coverUrl?: string;
  isSampleShowcase?: boolean;
  workingHoursConfigured?: boolean;
  bankCardNumber?: string;
  bankShebaNumber?: string;
  bankAccountHolder?: string;
  depositEnabled?: boolean;
  depositPercent?: number;
  cancellationDeadlineHours?: number;
  lateCancellationPenaltyPercent?: number;
  walletBalanceToman?: number;
  autoNightlySettlement?: boolean;
  ownerName?: string;
  ownerPhone?: string;
  createdAtJalali?: string;
  targetGender?: 'FEMALE' | 'MALE' | 'BOTH';
  laserDeviceModel?: string;
  contractAccepted?: boolean;
  contractAcceptedAtJalali?: string;
  isVipPartner?: boolean;
  vipCommissionPercent?: number;
}

export interface CustomerWalletTransactionItem {
  id: string;
  customerPhone: string;
  customerName: string;
  type: 'TOPUP' | 'BOOKING_PAYMENT' | 'REFUND_CANCEL' | 'WITHDRAWAL_REQUEST';
  amountToman: number;
  title: string;
  description: string;
  trackingCode: string;
  bankCardOrSheba?: string;
  withdrawalStatus?: 'PENDING' | 'PAID';
  createdAtJalali: string;
  createdAtMs: number;
}

export interface SmsMessageLogItem {
  id: string;
  businessId: string;
  businessName?: string;
  recipientsCount: number;
  recipientPhones: string[];
  messageText: string;
  templateTitle?: string;
  createdAtJalali: string;
  status: 'SENT' | 'DELIVERED' | 'SIMULATED';
}

export interface SupportTicketItem {
  id: string;
  senderRole: 'CUSTOMER' | 'BUSINESS_OWNER';
  senderName: string;
  senderPhone: string;
  businessId?: string;
  businessName?: string;
  categoryLabel: string;
  subject: string;
  message: string;
  createdAtJalali: string;
  status: 'OPEN' | 'ANSWERED' | 'CLOSED';
  adminReply?: string;
  repliedAtJalali?: string;
}

export interface AdminNotificationItem {
  id: string;
  type:
    | 'NEW_BUSINESS'
    | 'NEW_PAYMENT_ORDER'
    | 'SMS_TOPUP_REQUEST'
    | 'NEW_BOOKING'
    | 'NEW_SUPPORT_TICKET';
  title: string;
  message: string;
  businessId?: string;
  businessName?: string;
  ownerName?: string;
  ownerPhone?: string;
  city?: string;
  amountToman?: number;
  orderId?: string;
  ticketId?: string;
  createdAtJalali: string;
  isRead: boolean;
}

export interface AdminNotificationSettings {
  adminPhone: string;
  adminUsername?: string;
  adminDisplayName?: string;
  smsOnNewBusiness: boolean;
  smsOnNewPaymentOrder: boolean;
  smsOnNewBooking: boolean;
  inAppNotificationsEnabled: boolean;
}

export type SponsoredPlacementSlot =
  | 'SEARCH_TOP'
  | 'HOME_BANNER'
  | 'HERO_SPOTLIGHT';

export interface AdPackageItem {
  id: string;
  title: string;
  slot: SponsoredPlacementSlot | 'SMS_ADDON';
  durationDays: number;
  priceToman: number;
  weeklyPriceToman?: number;
  smsCount?: number;
  badge: string;
  description: string;
}

export interface PaymentGatewayConfig {
  activeMethod: 'ZIBAL' | 'BALEPAY_AND_CARD' | 'BALEPAY_ONLY' | 'CARD_ONLY';
  balePayId: string;
  balePayLink: string;
  cardNumber: string;
  cardHolderName: string;
  shebaNumber: string;
  bankName: string;
  supportTelegramOrBale: string;
  instructions: string;
  zibalMerchantId?: string;
  zarinpalMerchantId?: string;
  platformCommissionPercent?: number;
  maleCommissionPercent?: number;
  laserCommissionPercent?: number;
  femaleCommissionPercent?: number;
  settlementCycle?: 'WEEKLY' | 'BIWEEKLY';
}

export interface PaymentOrderItem {
  id: string;
  businessId: string;
  businessName: string;
  itemType: 'PLAN' | 'AD_PACKAGE' | 'SMS_PACK';
  itemId: string;
  itemTitle: string;
  amountToman: number;
  paymentMethod: 'ZIBAL' | 'BALEPAY' | 'CARD_TO_CARD';
  trackingCode: string;
  createdAtJalali: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requestedPlacement?: SponsoredPlacementSlot;
  requestedDurationDays?: number;
  requestedLabel?: string;
  requestedCategorySlug?: string;
  requestedNeighborhood?: string;
  requestedSmsCount?: number;
}

export interface SettlementRequestItem {
  id: string;
  businessId: string;
  businessName: string;
  ownerName: string;
  ownerPhone: string;
  shebaNumber: string;
  cardNumber?: string;
  amountToman: number;
  commissionToman: number;
  netPayoutToman: number;
  bookingsCount?: number;
  totalServiceAmountToman?: number;
  totalDepositCollectedToman?: number;
  createdAtJalali: string;
  status: 'PENDING' | 'PAID';
  paidTrackingCode?: string;
  paidAtJalali?: string;
}

export interface AppointmentItem {
  id: string;
  referenceCode: string;
  businessId: string;
  businessSlug: string;
  businessName: string;
  customerName: string;
  customerPhoneMasked: string;
  serviceId: string;
  serviceTitle: string;
  specialistId: string;
  specialistName: string;
  dateJalali: string;
  timeSlot: string;
  durationMinutes: number;
  priceToman: number;
  depositPaidToman?: number;
  platformCommissionToman?: number;
  customerGatewayAndTaxFeeToman?: number;
  salonNetDepositCreditedToman?: number;
  paymentMethod?: 'GATEWAY' | 'WALLET';
  paymentTrackingCode?: string;
  refundedToWalletToman?: number;
  createdAtMs?: number;
  status: AppointmentStatus;
  notes?: string;
  inPersonSettled?: boolean;
  inPersonSettledAmountToman?: number;
  inPersonSettledAtJalali?: string;
}

export interface DailyIncomeLogItem {
  id: string;
  businessId: string;
  dateJalali: string;
  amountToman: number;
  paymentMethod: 'POS_CARD' | 'CASH' | 'CARD_TO_CARD' | 'APPOINTMENT_SETTLEMENT';
  entryType: 'DAILY_BULK' | 'SINGLE_APPOINTMENT';
  appointmentId?: string;
  customerName?: string;
  serviceTitle?: string;
  specialistName?: string;
  note?: string;
  createdAtJalali: string;
}

export interface CustomerRecord {
  id: string;
  businessId?: string;
  fullName: string;
  phoneMasked: string;
  phone?: string;
  city: string;
  totalVisits: number;
  lastVisitJalali: string;
  totalSpentToman: number;
  favoriteService: string;
  notes: string;
  sourceLabel?: 'MANUAL' | 'BULK_IMPORT' | 'ONLINE_BOOKING';
}

export interface CategoryItem {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  serviceCount: number;
  targetAudience: string;
  iconName: string;
}

export interface SubscriptionPlanItem {
  id: string;
  name: string;
  audience: string;
  monthlyPriceToman: number;
  staffLimit: string;
  smsQuotaMonthly: number;
  features: string[];
  comparison: {
    onlineBooking: string;
    smsReminders: string;
    analyticsLevel: string;
    supportType: string;
  };
  isRecommended?: boolean;
}

export interface MarketingCampaignItem {
  id: string;
  title: string;
  targetSegment: string;
  discountPercent: number;
  channel: string;
  statusLabel: string;
  createdAtJalali: string;
}

export interface OnboardingDraft {
  businessType: BusinessType;
  businessName: string;
  categorySlug: string;
  slug: string;
  ownerName: string;
  phone: string;
  instagramHandle?: string;
  avatarUrl?: string;
  city: string;
  neighborhood: string;
  address: string;
  mapLat?: number;
  mapLng?: number;
  shortDescription: string;
  services: Array<{
    id: string;
    title: string;
    category: string;
    durationMinutes: number;
    priceToman: number;
    pricingType?: 'FIXED' | 'RANGE' | 'STARTING_FROM';
    maxPriceToman?: number;
    packageIncludes?: string[];
  }>;
  staff: Array<{
    id: string;
    fullName: string;
    roleTitle: string;
  }>;
  workingHours: WorkingHourItem[];
  licenseCode: string;
  nationalIdNumber: string;
  selectedPlanId?: string;
}

export interface BookingDraft {
  businessSlug: string;
  serviceId: string;
  serviceIds?: string[];
  specialistId: string;
  dateJalali: string;
  timeSlot: string;
  customerName: string;
  customerPhone: string;
  customerNotes: string;
  lastReferenceCode?: string;
}

export interface TimeSlotAvailabilityItem {
  time: string;
  available: boolean;
  reason?: string;
}

export interface AdminUserRecord {
  id: string;
  fullName: string;
  phoneMasked: string;
  phone?: string;
  roleLabel: string;
  city: string;
  joinedJalali: string;
  isActive: boolean;
}

export interface PlatformBusinessNoticeItem {
  id: string;
  targetBusinessId: 'ALL' | string;
  targetBusinessName?: string;
  title: string;
  message: string;
  createdAtJalali: string;
  readByBusinessIds: string[];
}

export interface BusinessStoryItem {
  id: string;
  businessId: string;
  title: string;
  badgeLabel: string;
  caption: string;
  imageUrl?: string;
  ctaLabel?: string;
  linkedServiceId?: string;
  createdAtJalali: string;
  createdAtMs?: number;
}




